/* ================================================================
   Nexio — Resume builder: skills, experience, education, file upload
   ES module — imports shared utilities from modules/utils.js
   Reads config from window.nexioPage (set by PHP template).
   Public functions exposed on window for PHP onclick handlers.
   ================================================================ */

import { escHtml, debounce } from '../modules/utils.js';

const cfg  = window.nexioPage || {};
const BASE = cfg.base  || '';
const i18n = cfg.i18n  || {};

/* ── Skills ──────────────────────────────────────────────────── */

function addSkill() {
    const inp = document.getElementById('skillInput');
    const val = inp.value.trim().replace(/,$/, '');
    if (!val) return;

    const tag = document.createElement('span');
    tag.className = 'skill-tag';
    tag.innerHTML = `${escHtml(val)}<button class="skill-tag__del" type="button" onclick="removeSkill(this)" title="${escHtml(i18n.delete || '')}">
        <i data-lucide="x" width="12" height="12"></i>
    </button>`;
    document.getElementById('skillsWrap').appendChild(tag);
    window.refreshIcons?.();
    inp.value = '';
    syncPreviewSkills();
}

function removeSkill(btn) {
    btn.closest('.skill-tag').remove();
    syncPreviewSkills();
}

function getSkills() {
    return [...document.querySelectorAll('#skillsWrap .skill-tag')]
        .map(t => t.childNodes[0].textContent.trim());
}

function syncPreviewSkills() {
    const skills = getSkills();
    const sec    = document.getElementById('prevSkillsSection');
    const wrap   = document.getElementById('prevSkills');
    sec.style.display = skills.length ? '' : 'none';
    wrap.innerHTML    = skills.map(s => `<span class="preview-skill">${escHtml(s)}</span>`).join('');
}

/* ── About live preview ─────────────────────────────────────── */

document.getElementById('aboutText')?.addEventListener('input', function () {
    const sec = document.getElementById('prevAboutSection');
    const el  = document.getElementById('prevAbout');
    sec.style.display = this.value.trim() ? '' : 'none';
    el.innerHTML      = escHtml(this.value.trim()).replace(/\n/g, '<br>');
});

/* ── Toggle add-record panels ───────────────────────────────── */

function toggleAddBlock(id) {
    document.getElementById(id)?.classList.toggle('open');
}

/* ── Experience ─────────────────────────────────────────────── */

async function saveExp() {
    const pos  = document.getElementById('exp_position').value.trim();
    const comp = document.getElementById('exp_company').value.trim();
    if (!pos || !comp) { alert(i18n.expRequired || ''); return; }

    const body = new URLSearchParams({
        type:        'exp',
        position:    pos,
        company:     comp,
        date_from:   document.getElementById('exp_from').value.trim(),
        date_to:     document.getElementById('exp_to').value.trim(),
        is_current:  document.getElementById('exp_current').checked ? 1 : 0,
        description: document.getElementById('exp_desc').value.trim(),
    });
    const data = await postJson('/pages/api/save_resume.php', body);

    if (data.id) {
        const isCurrent = document.getElementById('exp_current').checked;
        const dateTo    = isCurrent
            ? (i18n.present || '')
            : (document.getElementById('exp_to').value.trim() || '');

        document.getElementById('expList').insertAdjacentHTML('afterbegin', `
            <div class="exp-item" data-id="${data.id}">
                <button class="exp-item__del" type="button" onclick="deleteRecord('exp',${data.id},this)">
                    <i data-lucide="trash-2" width="14" height="14"></i>
                </button>
                <div class="exp-item__head">
                    <div class="exp-item__dot" style="background:rgba(139,92,246,.1)">
                        <i data-lucide="briefcase" width="16" height="16" style="color:#8b5cf6"></i>
                    </div>
                    <div>
                        <div class="exp-item__title">${escHtml(pos)}</div>
                        <div class="exp-item__sub">
                            ${escHtml(comp)} &nbsp;·&nbsp;
                            ${escHtml(document.getElementById('exp_from').value.trim())} — ${escHtml(dateTo)}
                        </div>
                    </div>
                </div>
            </div>`);

        window.refreshIcons?.();
        ['exp_position','exp_company','exp_from','exp_to','exp_desc']
            .forEach(id => { document.getElementById(id).value = ''; });
        document.getElementById('exp_current').checked = false;
        toggleAddBlock('expBlock');
    }
}

/* ── Education ──────────────────────────────────────────────── */

async function saveEdu() {
    const inst = document.getElementById('edu_inst').value.trim();
    if (!inst) { alert(i18n.eduRequired || ''); return; }

    const body = new URLSearchParams({
        type:        'edu',
        institution: inst,
        degree:      document.getElementById('edu_degree').value.trim(),
        year_from:   document.getElementById('edu_from').value.trim(),
        year_to:     document.getElementById('edu_to').value.trim(),
    });
    const data = await postJson('/pages/api/save_resume.php', body);

    if (data.id) {
        const deg  = document.getElementById('edu_degree').value.trim();
        const yr   = document.getElementById('edu_from').value.trim();
        const yrTo = document.getElementById('edu_to').value.trim();

        document.getElementById('eduList').insertAdjacentHTML('afterbegin', `
            <div class="exp-item" data-id="${data.id}">
                <button class="exp-item__del" type="button" onclick="deleteRecord('edu',${data.id},this)">
                    <i data-lucide="trash-2" width="14" height="14"></i>
                </button>
                <div class="exp-item__head">
                    <div class="exp-item__dot" style="background:rgba(245,158,11,.1)">
                        <i data-lucide="graduation-cap" width="16" height="16" style="color:#f59e0b"></i>
                    </div>
                    <div>
                        <div class="exp-item__title">${escHtml(deg || inst)}</div>
                        <div class="exp-item__sub">
                            ${escHtml(inst)} &nbsp;·&nbsp; ${escHtml(yr)}${yrTo ? ' — ' + escHtml(yrTo) : ''}
                        </div>
                    </div>
                </div>
            </div>`);

        window.refreshIcons?.();
        ['edu_inst','edu_degree','edu_from','edu_to']
            .forEach(id => { document.getElementById(id).value = ''; });
        toggleAddBlock('eduBlock');
    }
}

/* ── Delete experience / education record ───────────────────── */

async function deleteRecord(type, id, btn) {
    if (!confirm(i18n.confirmDelete || '')) return;
    const body = new URLSearchParams({ type: 'delete_' + type, id });
    const data = await postJson('/pages/api/save_resume.php', body);
    if (data.ok) btn.closest('.exp-item').remove();
}

/* ── Save main resume (about + skills) ─────────────────────── */

async function saveResume() {
    const btn = document.getElementById('saveBtn');
    const st  = document.getElementById('saveStatus');
    btn.disabled     = true;
    st.className     = 'save-status';
    st.textContent   = i18n.saving || '…';
    st.style.display = 'inline';
    try {
        const body = new URLSearchParams({
            type:   'main',
            about:  document.getElementById('aboutText').value.trim(),
            skills: getSkills().join(','),
        });
        const data = await postJson('/pages/api/save_resume.php', body);
        st.className   = data.ok ? 'save-status ok' : 'save-status err';
        st.textContent = data.ok ? (i18n.saved || '✓') : (i18n.error || '✗');
        setTimeout(() => { st.className = 'save-status'; st.textContent = ''; }, 2500);
    } finally {
        btn.disabled = false;
    }
}

/* ── File upload ────────────────────────────────────────────── */

async function uploadFiles(files) {
    const typeLabels = {
        diploma:     i18n.diploma      || 'Диплом',
        certificate: i18n.certificate  || 'Сертификат',
        other:       i18n.other        || 'Документ',
    };

    for (const file of files) {
        const fd = new FormData();
        fd.append('file',      file);
        fd.append('file_type', guessType(file.name));

        const res  = await fetch(BASE + '/pages/api/upload_resume_file.php', { method: 'POST', body: fd });
        const data = await res.json();

        if (data.id) {
            const icon  = { diploma: '🎓', certificate: '📜', other: '📄' }[data.file_type] || '📄';
            const label = typeLabels[data.file_type] || typeLabels.other;

            document.getElementById('fileList').insertAdjacentHTML('afterbegin', `
                <div class="file-item" data-id="${data.id}">
                    <div class="file-item__icon" style="background:rgba(239,68,68,.08)">${icon}</div>
                    <div style="flex:1;min-width:0">
                        <div class="file-item__name">${escHtml(data.original_name)}</div>
                        <div class="file-item__type">${label}</div>
                    </div>
                    <a href="${BASE}/assets/uploads/resume/${escHtml(data.filename)}" target="_blank"
                       class="file-item__del" style="color:var(--primary)">
                        <i data-lucide="external-link" width="15" height="15"></i>
                    </a>
                    <button class="file-item__del" type="button" onclick="deleteFile(${data.id},this)">
                        <i data-lucide="trash-2" width="15" height="15"></i>
                    </button>
                </div>`);
            window.refreshIcons?.();
        }
    }
    const fi = document.getElementById('fileInput');
    if (fi) fi.value = '';
}

function guessType(name) {
    const n = name.toLowerCase();
    if (n.includes('диплом') || n.includes('diploma'))  return 'diploma';
    if (n.includes('серт')   || n.includes('cert'))     return 'certificate';
    return 'other';
}

async function deleteFile(id, btn) {
    if (!confirm(i18n.confirmDeleteFile || '')) return;
    const body = new URLSearchParams({ type: 'delete_file', id });
    const data = await postJson('/pages/api/save_resume.php', body);
    if (data.ok) btn.closest('.file-item').remove();
}

/* ── Drag & drop ────────────────────────────────────────────── */

const drop = document.getElementById('fileDrop');
if (drop) {
    drop.addEventListener('dragover',  e  => { e.preventDefault(); drop.classList.add('drag'); });
    drop.addEventListener('dragleave', ()  => drop.classList.remove('drag'));
    drop.addEventListener('drop',      e  => {
        e.preventDefault();
        drop.classList.remove('drag');
        uploadFiles(e.dataTransfer.files);
    });
}

/* ── Auto-save (debounced 2 s after last keystroke) ─────────── */

document.getElementById('aboutText')?.addEventListener(
    'input',
    debounce(saveResume, 2000)
);

/* ── Internal helpers ───────────────────────────────────────── */

async function postJson(path, body) {
    const res = await fetch(BASE + path, { method: 'POST', body });
    return res.json();
}

/* ── Expose for PHP onclick attributes ─────────────────────── */

window.addSkill      = addSkill;
window.removeSkill   = removeSkill;
window.toggleAddBlock = toggleAddBlock;
window.saveExp       = saveExp;
window.saveEdu       = saveEdu;
window.deleteRecord  = deleteRecord;
window.saveResume    = saveResume;
window.uploadFiles   = uploadFiles;
window.deleteFile    = deleteFile;
