/* ================================================================
   Nexio — Employees list: rating URL filter
   ================================================================ */

window.applyRating = function applyRating(val) {
    const url = new URL(window.location.href);
    if (val > 0) url.searchParams.set('rating', val);
    else         url.searchParams.delete('rating');
    url.searchParams.delete('page');
    window.location.href = url.toString();
};
