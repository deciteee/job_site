/* ================================================================
   Nexio — Profile page: edit modal, avatar upload, password meter
   Reads config from window.nexioPage (set by PHP template).
   Functions exposed on window for PHP onclick/oninput handlers.
   ================================================================ */

(function () {
    const cfg  = window.nexioPage || {};
    const i18n = cfg.i18n         || {};

    /* ── Edit modal ── */
    function openProfileModal() {
        const m = document.getElementById('profileModal');
        if (!m) return;
        m.classList.add('open');
        document.body.style.overflow = 'hidden';
    }

    function closeProfileModal() {
        const m = document.getElementById('profileModal');
        if (!m) return;
        m.classList.remove('open');
        document.body.style.overflow = '';
    }

    const modal = document.getElementById('profileModal');
    if (modal) {
        modal.addEventListener('click', e => { if (e.target === modal) closeProfileModal(); });
    }
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeProfileModal(); });

    if (cfg.reopenModal) {
        document.addEventListener('DOMContentLoaded', openProfileModal);
    }

    /* ── Avatar click-to-upload ── */
    const avatarWrap = document.getElementById('avatarWrap');
    if (avatarWrap) {
        avatarWrap.addEventListener('click', () => {
            document.getElementById('avatarFileInput')?.click();
        });

        document.getElementById('avatarFileInput')?.addEventListener('change', function () {
            if (!this.files.length) return;
            const reader = new FileReader();
            reader.onload = ev => {
                const el = document.getElementById('previewAvatar');
                if (!el) return;
                if (el.tagName === 'IMG') {
                    el.src = ev.target.result;
                } else {
                    const img       = document.createElement('img');
                    img.id          = 'previewAvatar';
                    img.className   = 'pcard__avatar pcard__avatar--img';
                    img.src         = ev.target.result;
                    el.replaceWith(img);
                }
            };
            reader.readAsDataURL(this.files[0]);
            this.closest('form').submit();
        });
    }

    /* ── Password strength meter ── */
    function checkPassStrength(val) {
        const bar   = document.getElementById('strengthBar');
        const label = document.getElementById('passStrength');
        if (!bar) return;

        let score = 0;
        if (val.length >= 6)            score++;
        if (val.length >= 10)           score++;
        if (/[A-Z]/.test(val))          score++;
        if (/[0-9]/.test(val))          score++;
        if (/[^A-Za-z0-9]/.test(val))   score++;

        const levels = [
            { w: '0%',   c: 'var(--danger)',  t: '' },
            { w: '25%',  c: 'var(--danger)',  t: i18n.weak       || '' },
            { w: '50%',  c: 'var(--warning)', t: i18n.medium     || '' },
            { w: '75%',  c: '#22c55e',        t: i18n.good       || '' },
            { w: '90%',  c: '#16a34a',        t: i18n.strong     || '' },
            { w: '100%', c: '#15803d',        t: i18n.veryStrong || '' },
        ];
        const lvl            = levels[Math.min(score, 5)];
        bar.style.width      = lvl.w;
        bar.style.background = lvl.c;
        label.textContent    = lvl.t;
        label.style.color    = lvl.c;
    }

    /* Expose for PHP template onclick / oninput handlers */
    window.openProfileModal  = openProfileModal;
    window.closeProfileModal = closeProfileModal;
    window.checkPassStrength = checkPassStrength;
})();
