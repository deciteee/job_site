/* ================================================================
   Nexio — Vacancy detail: application status updates & letter toggle
   Reads config from window.nexioPage (set by PHP template).
   Functions exposed on window for PHP onclick handlers.
   ================================================================ */

(function () {
    const cfg  = window.nexioPage || {};
    const BASE = cfg.base  || '';
    const i18n = cfg.i18n  || {};

    const STATUS_ICONS = { accepted: '✓', rejected: '✗', reviewed: '👁', pending: '●' };

    async function setStatus(appId, newStatus, btn) {
        const card   = document.getElementById('appcard-' + appId);
        const badge  = document.getElementById('badge-'   + appId);
        const saving = document.getElementById('saving-'  + appId);

        const actionBtns = card.querySelectorAll(
            '.app-action-btn--accept, .app-action-btn--review, .app-action-btn--reject'
        );
        actionBtns.forEach(b => b.disabled = true);
        saving.classList.add('show');

        try {
            const res  = await fetch(BASE + '/pages/api/update_app_status.php', {
                method:  'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body:    'app_id=' + appId + '&new_status=' + newStatus,
            });
            const data = await res.json();

            if (data.ok) {
                card.className = card.className.replace(/app-card--\w+/, 'app-card--' + newStatus);

                badge.className   = 'app-status-badge app-status-badge--' + newStatus;
                badge.textContent = (STATUS_ICONS[newStatus] || '●') + ' ' + (i18n[newStatus] || newStatus);

                actionBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
            }
        } finally {
            actionBtns.forEach(b => b.disabled = false);
            saving.classList.remove('show');
        }
    }

    function toggleLetter(btn, appId) {
        const body = document.getElementById('letter-' + appId);
        const open = body.classList.toggle('open');
        btn.classList.toggle('open', open);
    }

    /* Expose for PHP onclick attributes */
    window.setStatus    = setStatus;
    window.toggleLetter = toggleLetter;
})();
