/* ================================================================
   Nexio — Vacancies list: filter checkboxes, hide/show, favorites
   Reads config from window.nexioPage (set by PHP template).
   ================================================================ */

(function () {
    const BASE = (window.nexioPage || {}).base || '';

    const TYPE_COLORS = {
        'full-time': '#10b981',
        'part-time': '#f59e0b',
        'remote':    '#3b82f6',
        'contract':  '#8b5cf6',
    };

    /* ── Colored filter checkboxes ── */
    document.querySelectorAll('.filter-check input[type=checkbox]').forEach(cb => {
        cb.addEventListener('change', function () {
            const box = this.nextElementSibling;
            const c   = TYPE_COLORS[this.value] || 'var(--primary)';
            box.style.background  = this.checked ? c : '';
            box.style.borderColor = this.checked ? c : '';
            const svg = box.querySelector('svg');
            if (svg) svg.style.display = this.checked ? 'block' : 'none';
        });
    });

    /* ── Hide / show vacancy card ── */
    document.querySelectorAll('.vac-hide-btn').forEach(btn => {
        btn.addEventListener('click', async function () {
            const { id, action } = this.dataset;
            this.disabled = true;
            try {
                const res  = await fetch(BASE + '/pages/api/hide_vacancy.php', {
                    method:  'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body:    'vacancy_id=' + id + '&action=' + action,
                });
                const data = await res.json();
                if (data.status) {
                    const card = this.closest('.vac-card');
                    card.style.transition = 'opacity .3s, transform .3s';
                    card.style.opacity    = '0';
                    card.style.transform  = 'scale(.97)';
                    setTimeout(() => card.remove(), 300);
                }
            } finally {
                this.disabled = false;
            }
        });
    });

    /* ── Favorite toggle ── */
    document.querySelectorAll('.vac-card__fav').forEach(btn => {
        btn.addEventListener('click', async function (e) {
            e.stopPropagation();
            const { id } = this.dataset;
            this.style.pointerEvents = 'none';
            try {
                const res  = await fetch(BASE + '/pages/api/toggle_favorite.php', {
                    method:  'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body:    'vacancy_id=' + id,
                });
                const data = await res.json();
                this.classList.toggle('saved', data.saved);
                this.querySelector('svg').setAttribute('fill', data.saved ? '#f43f5e' : 'none');
            } finally {
                this.style.pointerEvents = '';
            }
        });
    });
})();
