/* ================================================================
   Nexio — Dashboard activity chart
   ES module — imports chart factory from modules/chart-factory.js
   Reads config from window.nexioPage (set by PHP template).
   ================================================================ */

import { createChart, makeGradient } from '../modules/chart-factory.js';

const cfg    = window.nexioPage || {};
const canvas = document.getElementById('activityChart');

if (canvas) {
    const ctx = canvas.getContext('2d');

    const datasets = [
        {
            label:           (cfg.labels || {}).apps || '',
            data:            cfg.appsData || [],
            backgroundColor: 'rgba(59,130,246,0.85)',
            hoverBackgroundColor: '#3b82f6',
            borderRadius:    10,
            borderSkipped:   false,
            maxBarThickness: 30,
        },
    ];

    if (cfg.vacsData) {
        datasets.push({
            label:           (cfg.labels || {}).vacs || '',
            data:            cfg.vacsData,
            backgroundColor: 'rgba(34,197,94,0.75)',
            hoverBackgroundColor: '#22c55e',
            borderRadius:    10,
            borderSkipped:   false,
            maxBarThickness: 30,
        });
    }

    createChart('activityChart', { type: 'bar', labels: cfg.chartLabels || [], datasets, maintainAspectRatio: false });
}
