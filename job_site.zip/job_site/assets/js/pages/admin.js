/* ================================================================
   Nexio — Admin panel chart
   ES module — imports chart factory from modules/chart-factory.js
   Reads config from window.nexioPage (set by PHP template).
   ================================================================ */

import { createLineChart } from '../modules/chart-factory.js';

const cfg = window.nexioPage || {};

createLineChart('adminChart', {
    labels: cfg.chartLabels || [],
    datasets: [
        {
            label:                cfg.i18n?.registrations || 'Регистрации',
            data:                 cfg.chartReg || [],
            borderColor:          '#2563eb',
            backgroundColor:      'rgba(37,99,235,0.10)',
            borderWidth:          2.5,
            pointRadius:          4,
            pointBackgroundColor: '#2563eb',
            pointHoverRadius:     6,
            tension:              0.35,
            fill:                 true,
        },
        {
            label:                cfg.i18n?.applications || 'Отклики',
            data:                 cfg.chartApp || [],
            borderColor:          '#16a34a',
            backgroundColor:      'rgba(22,163,74,0.08)',
            borderWidth:          2.5,
            pointRadius:          4,
            pointBackgroundColor: '#16a34a',
            pointHoverRadius:     6,
            tension:              0.35,
            fill:                 true,
        },
    ],
});
