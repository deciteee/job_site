/* ================================================================
   Nexio — Register page: role-based form field switcher
   Reads config from window.nexioPage (set by PHP template).
   ================================================================ */

(function () {
    const cfg    = window.nexioPage  || {};
    const labels = cfg.roleLabels    || {};

    function applyRole(role) {
        const config       = labels[role] || labels.employee || {};
        const companyGroup = document.getElementById('companyGroup');
        const posLabel     = document.getElementById('positionLabel');
        const posInput     = document.getElementById('position');

        if (companyGroup) {
            companyGroup.style.display = config.showCompany ? '' : 'none';
            if (!config.showCompany) {
                const companyEl = document.getElementById('company');
                if (companyEl) companyEl.value = '';
            }
        }
        if (posLabel) posLabel.textContent = config.positionLabel || '';
        if (posInput) posInput.placeholder = config.positionPh    || '';
    }

    document.querySelectorAll('input[name="role"]').forEach(radio => {
        radio.addEventListener('change', () => applyRole(radio.value));
    });

    applyRole(cfg.selectedRole || 'employee');
})();
