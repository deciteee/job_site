/* ================================================================
   Nexio — Shared utilities
   ================================================================ */

/**
 * Escapes HTML special characters for safe DOM insertion.
 * @param {*} s
 * @returns {string}
 */
export function escHtml(s) {
    return String(s)
        .replace(/&/g,  '&amp;')
        .replace(/</g,  '&lt;')
        .replace(/>/g,  '&gt;')
        .replace(/"/g,  '&quot;');
}

/**
 * Returns a debounced version of fn that delays invocation by
 * delay ms after the last call.
 * @param {Function} fn
 * @param {number}   delay
 * @returns {Function}
 */
export function debounce(fn, delay) {
    let timer;
    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => fn(...args), delay);
    };
}

/**
 * Updates a URL search param and navigates. Removes 'page' to
 * reset pagination. Pass value <= 0 to remove the param entirely.
 * @param {string} key
 * @param {number} value
 */
export function applyUrlFilter(key, value) {
    const url = new URL(window.location.href);
    if (value > 0) url.searchParams.set(key, value);
    else           url.searchParams.delete(key);
    url.searchParams.delete('page');
    window.location.href = url.toString();
}
