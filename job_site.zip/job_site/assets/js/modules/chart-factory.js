/* ================================================================
   Nexio — Chart.js factory helpers
   Requires Chart.js to be present on window before this module runs.
   ================================================================ */

function getThemeColors() {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    return {
        gridColor:     isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)',
        textColor:     isDark ? '#5c6370'  : '#94a3b8',
        tooltipBg:     isDark ? '#1e2028'  : '#fff',
        tooltipBorder: isDark ? '#2d2e38'  : '#e2e8f0',
        tooltipTitle:  isDark ? '#e8eaf0'  : '#1a202c',
        tooltipBody:   isDark ? '#8b929e'  : '#4a5568',
    };
}

/**
 * Creates a vertical linear gradient fill for a dataset.
 * @param {CanvasRenderingContext2D} ctx
 * @param {[number, number, number]}  rgb      - RGB colour tuple
 * @param {number}                    maxAlpha - opacity at top (0–1)
 * @returns {CanvasGradient}
 */
export function makeGradient(ctx, [r, g, b], maxAlpha = 0.22) {
    const grad = ctx.createLinearGradient(0, 0, 0, 200);
    grad.addColorStop(0, `rgba(${r},${g},${b},${maxAlpha})`);
    grad.addColorStop(1, `rgba(${r},${g},${b},0)`);
    return grad;
}

/**
 * Renders a Nexio-styled responsive chart.
 * @param {string}   canvasId
 * @param {{ type?: string, labels: string[], datasets: object[] }} config
 * @returns {Chart|null}
 */
export function createChart(canvasId, { type = 'line', labels, datasets, maintainAspectRatio = true }) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return null;

    const c = getThemeColors();
    const scaleBase = {
        grid:   { color: c.gridColor },
        ticks:  { color: c.textColor, font: { size: 11 } },
        border: { color: c.gridColor },
    };

    return new Chart(canvas, {
        type,
        data: { labels, datasets },
        options: {
            responsive: true,
            maintainAspectRatio,
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: c.tooltipBg,
                    borderColor:     c.tooltipBorder,
                    borderWidth:     1,
                    titleColor:      c.tooltipTitle,
                    bodyColor:       c.tooltipBody,
                    padding:         10,
                    cornerRadius:    8,
                },
            },
            scales: {
                x: scaleBase,
                y: {
                    ...scaleBase,
                    ticks:       { ...scaleBase.ticks, stepSize: 1, precision: 0 },
                    beginAtZero: true,
                },
            },
        },
    });
}

/** Backwards-compatible alias */
export const createLineChart = (id, cfg) => createChart(id, { type: 'line', ...cfg });
