/* ================================================================
   Nexio — Application JavaScript
   Features: theme toggle, language switcher, sidebar, chat, misc
   ================================================================ */

(function () {
  'use strict';

  /* ── Theme system ──────────────────────────────────────────── */
  const THEME_KEY = 'nexio-theme';
  const SUN_SVG  = '<i data-lucide="sun" width="15" height="15"></i>';
  const MOON_SVG = '<i data-lucide="moon" width="15" height="15"></i>';

  // Upgrade any <i data-lucide> placeholders into SVGs (safe to call repeatedly).
  function refreshIcons() {
    if (window.lucide && typeof window.lucide.createIcons === 'function') {
      window.lucide.createIcons();
    }
  }
  window.refreshIcons = refreshIcons;

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem(THEME_KEY, theme);
    document.querySelectorAll('.theme-btn').forEach(btn => {
      btn.innerHTML = theme === 'dark' ? SUN_SVG + ' Светло' : MOON_SVG + ' Темно';
    });
    document.querySelectorAll('.lp-theme-btn').forEach(btn => {
      btn.innerHTML = theme === 'dark' ? SUN_SVG : MOON_SVG;
    });
    refreshIcons();
  }

  function toggleTheme() {
    const current = localStorage.getItem(THEME_KEY) || 'light';
    applyTheme(current === 'dark' ? 'light' : 'dark');
  }

  const savedTheme = localStorage.getItem(THEME_KEY) || 'light';
  applyTheme(savedTheme);

  document.addEventListener('click', (e) => {
    if (e.target.closest('.theme-btn') || e.target.closest('[data-action="theme"]') || e.target.closest('.lp-theme-btn')) {
      toggleTheme();
    }
  });

  /* ── Landing header scroll shadow ──────────────────────────── */
  const lpHeader = document.getElementById('lpHeader');
  if (lpHeader) {
    const onScroll = () => lpHeader.classList.toggle('lp-header--scrolled', window.scrollY > 24);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ── Smooth scroll for anchor links ────────────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', (e) => {
      const id = link.getAttribute('href').slice(1);
      const el = document.getElementById(id);
      if (el) { e.preventDefault(); el.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
  });

  /* ── Mobile sidebar toggle ────────────────────────────────── */
  const menuBtn = document.getElementById('menuToggle');
  const sidebar = document.getElementById('sidebar');

  if (menuBtn && sidebar) {
    menuBtn.addEventListener('click', () => sidebar.classList.toggle('open'));
    document.addEventListener('click', (e) => {
      if (sidebar.classList.contains('open') &&
          !sidebar.contains(e.target) && !menuBtn.contains(e.target)) {
        sidebar.classList.remove('open');
      }
    });
  }

  /* ── Desktop sidebar collapse / pin ─────────────────────── */
  const sidebarPin = document.getElementById('sidebarPin');
  if (sidebarPin && sidebar) {
    const iconC = sidebarPin.querySelector('.sb-icon-collapse');
    const iconE = sidebarPin.querySelector('.sb-icon-expand');

    function syncPinIcons() {
      const c = sidebar.classList.contains('collapsed');
      if (iconC) iconC.style.display = c ? 'none' : '';
      if (iconE) iconE.style.display = c ? '' : 'none';
    }

    syncPinIcons(); // sync icons with state set by anti-flash script

    sidebarPin.addEventListener('click', function () {
      const collapsed = !sidebar.classList.contains('collapsed');
      sidebar.classList.toggle('collapsed', collapsed);
      localStorage.setItem('nexio-sb-pinned', collapsed ? '0' : '1');
      syncPinIcons();
    });
  }

  /* ── Auto-grow textarea ───────────────────────────────────── */
  document.querySelectorAll('textarea').forEach((el) => {
    const resize = () => {
      el.style.height = 'auto';
      el.style.height = Math.min(el.scrollHeight, 200) + 'px';
    };
    el.addEventListener('input', resize);
    resize();
  });

  /* ── Chat: scroll to bottom ───────────────────────────────── */
  const chatMessages = document.getElementById('chatMessages');
  if (chatMessages) chatMessages.scrollTop = chatMessages.scrollHeight;

  /* ── Chat: Ctrl+Enter to send ─────────────────────────────── */
  const chatInput = document.getElementById('chatInput');
  if (chatInput) {
    chatInput.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        chatInput.closest('form').submit();
      }
    });
  }

  /* ── Dropdown panels ─────────────────────────────────────── */
  document.addEventListener('click', (e) => {
    document.querySelectorAll('.dropdown-panel:not(.hidden)').forEach((panel) => {
      const trigger = panel.previousElementSibling;
      if (!panel.contains(e.target) && (!trigger || !trigger.contains(e.target))) {
        panel.classList.add('hidden');
      }
    });
  });

  /* ── Role option selector ─────────────────────────────────── */
  document.querySelectorAll('.role-option input[type="radio"]').forEach((radio) => {
    const update = () => {
      document.querySelectorAll('.role-option').forEach(o => o.classList.remove('selected'));
      if (radio.checked) radio.closest('.role-option').classList.add('selected');
    };
    radio.addEventListener('change', update);
    if (radio.checked) radio.closest('.role-option').classList.add('selected');
  });

  /* ── Alert auto-dismiss ───────────────────────────────────── */
  document.querySelectorAll('.alert').forEach((alert) => {
    setTimeout(() => {
      alert.style.transition = 'opacity 0.4s ease';
      alert.style.opacity = '0';
      setTimeout(() => alert.remove(), 400);
    }, 5000);
  });

  /* ── Close language dropdown on outside click ────────────── */
  document.addEventListener('click', (e) => {
    document.querySelectorAll('.lang-dropdown.open').forEach((dd) => {
      if (!dd.contains(e.target)) dd.classList.remove('open');
    });
  });

  /* ── Floating chat widget ─────────────────────────────────── */
  const fchatBtn   = document.getElementById('fchatBtn');
  const fchatPanel = document.getElementById('fchatPanel');
  const fchatClose = document.getElementById('fchatClose');

  if (fchatBtn && fchatPanel) {
    fchatBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      fchatPanel.classList.toggle('fchat__panel--open');
    });

    if (fchatClose) {
      fchatClose.addEventListener('click', (e) => {
        e.stopPropagation();
        fchatPanel.classList.remove('fchat__panel--open');
      });
    }

    document.addEventListener('click', (e) => {
      if (!e.target.closest('#fchatWidget')) {
        fchatPanel.classList.remove('fchat__panel--open');
      }
    });
  }

  /* ── Dashboard stat counter animation ────────────────────── */
  function animateCounters() {
    document.querySelectorAll('.stat-card__value').forEach((el) => {
      const raw = el.childNodes[0] ? el.childNodes[0].textContent.trim() : '';
      const num = parseFloat(raw);
      if (!raw || isNaN(num) || num === 0) return;
      const isFloat = raw.includes('.');
      const duration = 700;
      const start = performance.now();
      function step(now) {
        const p = Math.min((now - start) / duration, 1);
        const ease = 1 - Math.pow(1 - p, 3);
        const val = isFloat ? (num * ease).toFixed(1) : Math.round(num * ease);
        el.childNodes[0].textContent = val;
        if (p < 1) requestAnimationFrame(step);
      }
      requestAnimationFrame(step);
    });
  }
  if (document.querySelector('.stat-cards')) animateCounters();

  /* ── Upgrade all static Lucide icon placeholders ─────────────── */
  refreshIcons();

})();
