<?php
// ================================================================
// Database & Application Configuration
// ================================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'hr_platform');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    http_response_code(500);
    die('
    <!DOCTYPE html><html><head><meta charset="UTF-8">
    <style>body{font-family:system-ui;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;background:#0f172a;}
    .err{background:#1e293b;border-left:4px solid #dc2626;padding:32px 40px;border-radius:8px;box-shadow:0 4px 24px rgba(0,0,0,.4);max-width:480px;}
    h2{margin:0 0 8px;color:#f1f5f9;}p{color:#94a3b8;margin:4px 0;}</style>
    </head><body><div class="err"><h2>Database Connection Failed</h2>
    <p>' . htmlspecialchars($conn->connect_error) . '</p>
    <p style="margin-top:16px;font-size:13px;">Check <strong>config.php</strong> and make sure XAMPP MySQL is running.</p>
    </div></body></html>');
}

$conn->set_charset('utf8mb4');
$conn->options(MYSQLI_OPT_INT_AND_FLOAT_NATIVE, true);

// Schema migrations (run once, idempotent)
foreach ([
    "ALTER TABLE users ADD COLUMN status       ENUM('active','pending') NOT NULL DEFAULT 'active' AFTER email",
    "ALTER TABLE users ADD COLUMN verify_token VARCHAR(64) DEFAULT NULL AFTER status",
    "ALTER TABLE vacancies ADD COLUMN expires_at DATE NULL AFTER status",
    "ALTER TABLE applications MODIFY COLUMN status ENUM('pending','reviewed','accepted','rejected','withdrawn') DEFAULT 'pending'",
    "ALTER TABLE vacancies ADD COLUMN cover_image VARCHAR(255) NOT NULL DEFAULT 'default' AFTER employer_id",
    "ALTER TABLE vacancies MODIFY COLUMN cover_image VARCHAR(255) NOT NULL DEFAULT 'default'",
] as $_m) { try { $conn->query($_m); } catch (\mysqli_sql_exception $_e) {} }
unset($_m, $_e);

// Fix vacancies with clearly wrong expiry years (typos like 0121, 0012, 1111)
$conn->query("UPDATE vacancies SET expires_at = NULL WHERE expires_at IS NOT NULL AND YEAR(expires_at) < 2000");

$conn->query("CREATE TABLE IF NOT EXISTS password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(150) NOT NULL,
    token VARCHAR(64) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_email (email),
    UNIQUE KEY uk_token (token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS saved_vacancies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    vacancy_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uv (user_id, vacancy_id),
    KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS resumes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    headline VARCHAR(120) DEFAULT NULL,
    about TEXT DEFAULT NULL,
    skills TEXT DEFAULT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS resume_experiences (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    company VARCHAR(120) NOT NULL,
    position VARCHAR(120) NOT NULL,
    date_from VARCHAR(20) DEFAULT NULL,
    date_to VARCHAR(20) DEFAULT NULL,
    is_current TINYINT(1) DEFAULT 0,
    description TEXT DEFAULT NULL,
    sort_order INT DEFAULT 0,
    KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS resume_educations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    institution VARCHAR(150) NOT NULL,
    degree VARCHAR(120) DEFAULT NULL,
    year_from YEAR DEFAULT NULL,
    year_to YEAR DEFAULT NULL,
    description TEXT DEFAULT NULL,
    sort_order INT DEFAULT 0,
    KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS resume_files (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    filename VARCHAR(255) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    file_type ENUM('diploma','certificate','other') DEFAULT 'other',
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// App constants
define('BASE_URL',     'http://localhost/job_site');
define('SITE_NAME',    'Nexio');
define('SITE_TAGLINE', 'Найди работу. Создай будущее.');
define('VERSION',      '1.0.0');

// Cache-busting helper: appends the file's mtime so browsers re-fetch on change.
// $relPath is relative to the project root (where this config.php lives).
function asset_ver(string $relPath): string {
    $file = __DIR__ . '/' . ltrim($relPath, '/');
    return is_file($file) ? (string) filemtime($file) : VERSION;
}

// Mailer credentials (Gmail SMTP)
define('MAIL_FROM',      'emirdiushembiev21.05.2008@gmail.com');
define('MAIL_FROM_NAME', 'Nexio HR Platform');
define('GMAIL_USER',     'emirdiushembiev21.05.2008@gmail.com');
define('GMAIL_PASS',     'msxxhsunpamysfmt');
