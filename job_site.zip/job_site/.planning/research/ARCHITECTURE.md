# Architecture Research — CSS Design System

**Project:** Nexio Dashboard Redesign
**Confidence:** HIGH

## CSS Organization Strategy

Use a **single `style.css`** organized into clearly-commented ITCSS-inspired sections. One file is correct for this project — no build tools, HTTP/2 makes it effectively free, and single source-of-truth is easier to reason about.

**Recommended section order (top → bottom, low → high specificity):**

```
1. SETTINGS        — :root tokens, design primitives
2. TOOLS           — @keyframes, @font-face
3. GENERIC         — reset / normalize
4. ELEMENTS        — bare html, body, h1-h6, a, p, button, input
5. OBJECTS         — layout primitives (.l-container, .l-stack, .l-grid)
6. COMPONENTS
   6a. SHARED COMPONENTS  (used by both landing & dashboard)
   6b. LANDING COMPONENTS (.lp-hero, .lp-features)
   6c. DASHBOARD COMPONENTS (.dash-sidebar, .dash-topbar, .dash-card)
7. UTILITIES       — single-purpose helpers (.u-text-center)
8. THEMES          — [data-theme="dark"] overrides
9. RESPONSIVE      — @media blocks co-located per component
```

**Key rule:** Eliminate `<style>` blocks in `dashboard.php`. Move them all into section 6c.

---

## Design Token Architecture

**Two-tier token system** in `:root`:

### Tier 1 — Primitives (raw values, never used directly in components)

```css
:root {
  --color-brand-50:  #eff6ff;
  --color-brand-500: #2563eb;
  --color-brand-700: #1d4ed8;
  --color-neutral-0:   #ffffff;
  --color-neutral-50:  #f7f8fa;
  --color-neutral-100: #eef0f4;
  --color-neutral-900: #0b0d12;

  --space-1: 4px;  --space-2: 8px;  --space-3: 12px;
  --space-4: 16px; --space-5: 24px; --space-6: 32px;

  --font-sans: 'Inter', system-ui, sans-serif;
  --text-xs: 0.75rem; --text-sm: 0.875rem; --text-base: 1rem;
  --text-lg: 1.125rem; --text-xl: 1.25rem; --text-2xl: 1.5rem;

  --radius-sm: 6px; --radius-md: 10px; --radius-lg: 16px; --radius-pill: 999px;
  --shadow-sm: 0 1px 2px rgb(0 0 0 / 0.06);
  --shadow-md: 0 4px 12px rgb(0 0 0 / 0.08);
  --shadow-lg: 0 12px 32px rgb(0 0 0 / 0.12);
  --ease-out: cubic-bezier(0.16, 1, 0.3, 1);
  --duration-fast: 120ms; --duration-base: 200ms;
}
```

### Tier 2 — Semantic tokens (what components actually consume)

```css
:root {
  --surface-page:    var(--color-neutral-50);
  --surface-raised:  var(--color-neutral-0);
  --surface-sunken:  var(--color-neutral-100);

  --text-primary:    var(--color-neutral-900);
  --text-secondary:  #4a5160;
  --text-muted:      #8a93a6;
  --text-on-brand:   var(--color-neutral-0);

  --border-subtle:   var(--color-neutral-100);
  --border-strong:   #d4d9e2;

  --action-primary-bg:       var(--color-brand-500);
  --action-primary-bg-hover: var(--color-brand-700);
  --action-primary-fg:       var(--text-on-brand);

  --dash-sidebar-bg:     var(--surface-raised);
  --dash-sidebar-fg:     var(--text-secondary);
  --dash-sidebar-active: var(--action-primary-bg);
  --dash-topbar-bg:      var(--surface-raised);
  --dash-content-bg:     var(--surface-page);
}
```

### Tier 3 — Theme overrides (only reassign Tier 2)

```css
[data-theme="dark"] {
  --surface-page:   #0b0d12;
  --surface-raised: #161922;
  --surface-sunken: #1d2230;
  --text-primary:   #f0f2f7;
  --text-secondary: #b0b7c8;
  --text-muted:     #6b7388;
  --border-subtle:  #232938;
  --border-strong:  #323a4f;
}
```

---

## Component Naming Convention

**Prefixed BEM** — best fit for vanilla CSS without a build step:

```
l-*    layout objects     (.l-container, .l-stack, .l-grid)
c-*    components         (.c-button, .c-card, .c-modal)
lp-*   landing-page       (.lp-hero, .lp-feature-grid)
dash-* dashboard          (.dash-sidebar, .dash-topbar, .dash-stat-card)
u-*    utilities          (.u-text-center, .u-visually-hidden)
is-*   state              (.is-active, .is-loading, .is-open)
js-*   JS hooks (no styles)
```

Prefixes make the landing-vs-dashboard boundary **visible at the selector level**.

---

## Build Order

Build bottom-up through ITCSS layers:

1. **Token foundation** — Tier 1/2/3, dark mode wired, legacy tokens aliased
2. **Stylesheet restructure** — banner sections + TOC, inline `dashboard.php` styles migrated
3. **Shared component layer (`c-*`)** — buttons, cards, inputs, modals against tokens
4. **Dashboard shell** — `.dash-app`, `.dash-sidebar`, `.dash-topbar`
5. **Dashboard pages** — per-page widgets, tables, empty states
6. **Polish** — responsive QA, dark-mode QA, legacy-token deletion

---

## Landing ↔ Dashboard Boundary

- **Naming prefix is the firewall.** `.lp-*` selectors must not appear in post-login PHP files; `.dash-*` must not appear in landing templates.
- **Section banners are physical walls.** Sections 6b and 6c are clearly separated in the CSS file.
- **Shared logic lives in 6a only.** If needed by both, it goes into `.c-*` consuming Tier 2 tokens.
- Wrapper class on `<body>`: `is-landing` vs `is-dashboard` for emergency escape hatch.

---

## Data Flow

```
:root (Tier 1 + 2)
  → [data-theme="dark"] overrides Tier 2
    → <body class="is-dashboard">
      → .dash-sidebar   uses --dash-sidebar-bg, --dash-sidebar-fg
      → .dash-topbar    uses --dash-topbar-bg
      → .dash-content   uses --surface-page, --text-primary
```

**Theme switch = single attribute toggle:**
```js
document.documentElement.dataset.theme = 'dark';
```

Every component re-resolves token references on next paint. No per-component JS needed.

---

## Confidence Levels

| Area | Level | Reason |
|------|-------|--------|
| CSS organization (ITCSS) | HIGH | Established pattern, ideal for single-file no-build |
| Token architecture (Tier 1/2/3) | HIGH | Standard design-system practice |
| Naming convention (prefixed BEM) | HIGH | Best vanilla-CSS fit |
| Build order | HIGH | Bottom-up ITCSS is the only safe sequence |
| Landing/dashboard boundary | MEDIUM | Strategy sound; actual collision risk depends on current style.css |
| Data flow | HIGH | Native CSS custom-property inheritance |

## Open Questions (verify at implementation)

- Existing token names in `:root` — inventory before defining Tier 2
- Existing class-name collisions — does current CSS already use unprefixed `.button`, `.card`?
- Inline `<style>` blocks in `dashboard.php` — enumerate exact selectors
- Theme-switching mechanism — class-based vs `[data-theme]`?
