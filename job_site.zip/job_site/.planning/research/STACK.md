# Stack Research — SaaS Dashboard CSS/JS 2025

**Project:** Nexio job platform — post-login dashboard redesign
**Constraints:** PHP + MySQL + XAMPP, vanilla CSS/JS, single style.css, no build tools
**Confidence:** HIGH

---

## Recommended CSS Architecture

### Three-tier token system in `:root`

Layer custom properties so dashboard reuses landing's design language without redefining anything. **primitive → semantic → component**.

```css
:root {
  /* ── Tier 1: Primitives (raw values — only place hex lives) ── */
  --c-navy-900: #0f1d31;
  --c-navy-800: #1a2e4a;     /* existing landing dark */
  --c-blue-600: #2563eb;     /* existing primary */
  --c-blue-400: #60a5fa;
  --c-slate-50:  #f8fafc;
  --c-slate-200: #e2e8f0;
  --c-slate-500: #64748b;
  --c-slate-900: #0f172a;

  /* Spacing — 4px base */
  --space-1: 0.25rem;  --space-2: 0.5rem;
  --space-3: 0.75rem;  --space-4: 1rem;
  --space-5: 1.25rem;  --space-6: 1.5rem;
  --space-8: 2rem;     --space-12: 3rem;

  /* Radii */
  --radius-sm: 6px;  --radius-md: 10px;
  --radius-lg: 16px; --radius-xl: 24px;
  --radius-full: 9999px;

  /* Elevation */
  --shadow-xs: 0 1px 2px rgb(15 23 42 / 0.06);
  --shadow-sm: 0 2px 4px rgb(15 23 42 / 0.06), 0 1px 2px rgb(15 23 42 / 0.04);
  --shadow-md: 0 8px 16px rgb(15 23 42 / 0.08), 0 2px 4px rgb(15 23 42 / 0.04);
  --shadow-lg: 0 16px 32px rgb(15 23 42 / 0.10);
  --shadow-glow: 0 0 0 4px rgb(37 99 235 / 0.18);

  /* Motion */
  --ease-out: cubic-bezier(0.22, 1, 0.36, 1);
  --dur-fast: 150ms;
  --dur-base: 220ms;
  --dur-slow: 320ms;
}

/* ── Tier 2: Semantic tokens ── */
:root {
  --bg-app: var(--c-slate-50);
  --bg-surface: #ffffff;
  --bg-surface-2: var(--c-slate-100);
  --bg-glass: rgb(255 255 255 / 0.65);
  --fg-default: var(--c-slate-900);
  --fg-muted: var(--c-slate-500);
  --fg-on-accent: #ffffff;
  --border-subtle: var(--c-slate-200);
  --accent: var(--c-blue-600);
  --accent-hover: var(--c-blue-500);
  --accent-soft: rgb(37 99 235 / 0.10);
  --gradient-cta: linear-gradient(135deg, #2563eb 0%, #1e40af 100%);
  --gradient-hero: linear-gradient(135deg, #1a2e4a 0%, #0f1d31 100%);
}

/* ── Tier 3: Dark theme (only overrides Tier 2) ── */
[data-theme="dark"] {
  --bg-app: var(--c-navy-900);
  --bg-surface: var(--c-navy-800);
  --bg-surface-2: var(--c-navy-700);
  --bg-glass: rgb(26 46 74 / 0.55);
  --fg-default: #f1f5f9;
  --fg-muted: #94a3b8;
  --border-subtle: rgb(255 255 255 / 0.08);
  --accent-soft: rgb(96 165 250 / 0.16);
  --shadow-sm: 0 1px 2px rgb(0 0 0 / 0.5);
  --shadow-md: 0 4px 12px rgb(0 0 0 / 0.45);
  color-scheme: dark;
}
```

### Use `@layer` to organize one big stylesheet

Cascade Layers (Baseline 2022) eliminate specificity wars in a single stylesheet:

```css
@layer reset, tokens, base, layout, components, utilities, overrides;

@layer tokens     { :root { /* design tokens */ } }
@layer base       { body, h1, h2, p { /* typography defaults */ } }
@layer layout     { .app-shell { /* grid frames */ } }
@layer components { .card, .btn, .stat-tile, .nav-rail { /* parts */ } }
@layer utilities  { .u-stack-4 { display: grid; gap: var(--space-4); } }
```

Within layers, specificity is ignored — later layers win. Anything outside layers beats everything inside, useful for page-specific PHP overrides.

---

## Modern Component Patterns

### Card

```css
.card {
  background: var(--bg-surface);
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius-lg);
  padding: var(--space-6);
  box-shadow: var(--shadow-sm);
  transition: box-shadow var(--dur-base) var(--ease-out),
              transform var(--dur-base) var(--ease-out),
              border-color var(--dur-base) var(--ease-out);
}
.card:hover {
  box-shadow: var(--shadow-md);
  transform: translateY(-2px);
  border-color: var(--accent-soft);
}
```

Key 2025 idioms:
- **Subtle border + soft shadow + rounded corners (12-16px)**. Pure shadow-only = dated; pure border-only = admin-panel.
- Border radius scales with size — buttons 6-8px, cards 12-16px, modals 20-24px.
- No heavy gradients on body surfaces — reserve for CTAs and hero areas.

### Glassmorphism (use sparingly)

Valid only on: fixed topbar over content + dropdown/popover panels. Never on scrolling body cards.

```css
.topbar {
  position: sticky; top: 0; z-index: 50;
  background: var(--bg-glass);
  backdrop-filter: blur(14px) saturate(140%);
  -webkit-backdrop-filter: blur(14px) saturate(140%);
  border-bottom: 1px solid var(--border-subtle);
}
@supports not (backdrop-filter: blur(1px)) {
  .topbar { background: var(--bg-surface); }
}
```

**Critical:** any ancestor with `opacity < 1`, `filter`, `mask`, or `mix-blend-mode` becomes a backdrop root and silently disables blur. Keep glass elements close to `<body>`.

### Buttons — scoped custom property variants

```css
.btn {
  --btn-bg: var(--bg-surface);
  --btn-fg: var(--fg-default);
  --btn-border: var(--border-subtle);
  display: inline-flex; align-items: center; gap: var(--space-2);
  padding: var(--space-2) var(--space-4);
  font-weight: 600;
  border-radius: var(--radius-md);
  background: var(--btn-bg);
  color: var(--btn-fg);
  border: 1px solid var(--btn-border);
  transition: transform var(--dur-fast) var(--ease-out),
              box-shadow var(--dur-fast) var(--ease-out),
              background var(--dur-fast) var(--ease-out);
}
.btn:hover  { transform: translateY(-1px); box-shadow: var(--shadow-sm); }
.btn:active { transform: translateY(0); }
.btn:focus-visible { outline: none; box-shadow: var(--shadow-glow); }

.btn--primary {
  --btn-bg: var(--gradient-cta);
  --btn-fg: var(--fg-on-accent);
  --btn-border: transparent;
}
.btn--ghost { --btn-bg: transparent; --btn-border: transparent; }
.btn--ghost:hover { --btn-bg: var(--accent-soft); }
```

---

## Layout Patterns

### App-shell grid

```css
.app-shell {
  display: grid;
  min-height: 100dvh;   /* dvh handles mobile browser chrome */
  grid-template-columns: 1fr;
  grid-template-rows: auto 1fr;
  grid-template-areas:
    "topbar"
    "main";
}
.app-shell > .topbar  { grid-area: topbar; }
.app-shell > .sidebar { grid-area: sidebar; display: none; }
.app-shell > .main    { grid-area: main; padding: var(--space-6); }

@media (min-width: 960px) {
  .app-shell {
    grid-template-columns: 260px 1fr;
    grid-template-areas:
      "sidebar topbar"
      "sidebar main";
  }
  .app-shell > .sidebar { display: block; }
}
```

Use `100dvh` over `100vh` — mobile Safari/Chrome compute vh against largest viewport, overflowing by address-bar height.

### Content layouts

- **Card grids:** `grid-template-columns: repeat(auto-fill, minmax(280px, 1fr))` — use `auto-fill` for dashboards
- **Forms:** `grid-template-columns: minmax(0, 1fr) minmax(0, 2fr)` → single column at <640px
- **List + detail (chat, employees):** `grid-template-columns: 320px 1fr; gap: 0; min-height: 0` — `min-height: 0` makes inner lists scroll inside grid cells
- **Container queries** (`@container`, Baseline 2023) for component-responsive layouts

---

## Micro-interactions

**Only animate: `transform`, `opacity`, `filter`, `box-shadow`, `background-color`** — GPU composited. Never `width`/`height`/`top`/`padding`.

### Recommended timing

| Interaction | Duration | Easing |
|---|---|---|
| Button color/bg | 120-180ms | ease-out |
| Hover lift (card) | 200-260ms | ease-out |
| Modal/drawer enter | 260-320ms | ease-out |
| Modal/drawer exit | 180-220ms | ease-in |

### Focus rings (never remove without replacing)

```css
:where(button, a, input, select, textarea, [tabindex]):focus-visible {
  outline: none;
  box-shadow: var(--shadow-glow);
  border-radius: inherit;
}
```

### Prefers-reduced-motion (free a11y)

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}
```

---

## Typography Scale

### Font stack

```css
:root {
  --font-sans: "Inter", system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  --font-mono: ui-monospace, "JetBrains Mono", Consolas, monospace;
}
body { font-family: var(--font-sans); }
.tabular { font-variant-numeric: tabular-nums; }
```

`system-ui` alone is acceptable (zero network cost, gets Segoe UI Variable on Win11, SF Pro on macOS).

### Scale (1.25 ratio)

```css
:root {
  --fs-12: 0.75rem;   /* labels, badges */
  --fs-14: 0.875rem;  /* body small, table cells */
  --fs-16: 1rem;      /* body base */
  --fs-20: 1.25rem;   /* card title */
  --fs-24: 1.5rem;    /* section heading */
  --fs-30: 1.875rem;  /* page title */
  --fs-display: clamp(2rem, 4vw + 0.5rem, 3.25rem);  /* hero */

  --lh-tight: 1.15;  --lh-snug: 1.35;  --lh-normal: 1.55;
  --fw-regular: 400; --fw-medium: 500; --fw-semibold: 600; --fw-bold: 700;
}
```

Rules: body text 16px min; slight negative letter-spacing on headings (`-0.01em`); slight positive on tiny uppercase labels (`0.04em`); weight contrast 400/500/600/700 only.

---

## Dark/Light Theme Approach

### Pattern: OS preference default + manual `data-theme` override

```css
:root { color-scheme: light dark; }  /* frees native controls/scrollbars */
:root { /* light tokens */ }

@media (prefers-color-scheme: dark) {
  :root:not([data-theme]) { /* dark tokens — only when no user override */ }
}

[data-theme="light"] { /* explicit light */ }
[data-theme="dark"]  { /* explicit dark */ color-scheme: dark; }
```

### JS toggle (inline in `<head>` to prevent FOUC)

```html
<script>
  (function () {
    const saved = localStorage.getItem('theme');
    if (saved) document.documentElement.dataset.theme = saved;
  })();
</script>
```

Place BEFORE the stylesheet link — prevents flash of wrong theme on every PHP page load.

---

## Iconography (no npm)

### SVG sprite + `<use>` + `currentColor` — recommended

One HTTP request, scales perfectly, themes via CSS `color`.

```html
<!-- Once per page, in header.php -->
<svg width="0" height="0" style="position:absolute" aria-hidden="true">
  <symbol id="i-home" viewBox="0 0 24 24" fill="none" stroke="currentColor"
          stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round">
    <path d="M3 12 12 3l9 9"/><path d="M5 10v10h14V10"/>
  </symbol>
  <!-- more symbols -->
</svg>

<!-- Usage anywhere -->
<svg class="icon" aria-hidden="true"><use href="#i-home"/></svg>
```

```css
.icon {
  width: 1.25em; height: 1.25em;
  vertical-align: -0.18em; flex-shrink: 0;
}
.nav-item.is-active .icon { color: var(--accent); }
```

**Free MIT sources:** Lucide (lucide.dev) — first choice for SaaS; Heroicons; Tabler Icons; Phosphor.

**Don't use:** Icon fonts (Font Awesome/Material Icons) — extra HTTP, 80-200KB, inaccessible, can't multi-color. Dead pattern in 2025.

---

## What NOT to use

| Anti-pattern | Why avoid |
|---|---|
| Bootstrap CSS | 200KB, different design language, fights your tokens |
| Tailwind via CDN play script | ~3MB CSS, no JIT |
| Heavy gradients on every surface | Dated 2021 look |
| Neumorphism | Failed 2020 trend, terrible a11y |
| `transition: all` | Use explicit property list |
| Animating `width`/`height`/`top` | Layout-thrashing jank |
| Icon fonts | See Iconography section |
| `opacity: 0.95` on topbar/modal ancestors | Creates backdrop root → disables `backdrop-filter` on children |
| `100vh` for full-screen shells | Breaks on mobile Safari/Chrome — use `100dvh` |
| Focus outline removed without replacement | WCAG violation |

---

## Migration Approach for Existing style.css

1. Add `@layer` declaration at very top — wraps existing rules, no visual change
2. Audit existing custom properties — map to three-tier model, alias rather than delete
3. Build dashboard components in isolation in `assets/components.html`
4. Roll out page by page: sidebar/topbar → dashboard → list pages → form pages → chat/admin
5. Add `prefers-reduced-motion` global block once — free a11y

---

## Confidence Levels

| Recommendation | Confidence |
|---|---|
| Three-tier token system | HIGH |
| `@layer` cascade architecture | HIGH — MDN, Baseline 2022 |
| Card pattern (border + soft shadow) | HIGH |
| Glassmorphism with `backdrop-filter` | HIGH — MDN, Baseline 2024 |
| App-shell grid with `grid-template-areas` | HIGH |
| `100dvh` over `100vh` | HIGH — mobile viewport bug well-documented |
| Animate `transform`/`opacity` only | HIGH |
| `:focus-visible` + box-shadow ring | HIGH |
| `prefers-reduced-motion` global override | HIGH |
| OS-preference + manual `data-theme` | HIGH |
| SVG sprite + `<use>` + `currentColor` | HIGH |
| Inter / system-ui font stack | HIGH |
| Avoiding Font Awesome icon font | HIGH |
