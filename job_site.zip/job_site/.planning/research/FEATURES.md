# Features Research — SaaS Dashboard Components 2025

**Project:** Nexio (PHP + MySQL + vanilla CSS/JS job platform)
**Confidence:** MEDIUM-HIGH

---

## Table Stakes (must have)

### Layout & Navigation

| Component | 2025 Baseline | Nexio |
|-----------|---------------|-------|
| Persistent left sidebar | Fixed, 240-280px expanded, collapsible to ~56px icon rail | Replace any top-tabs nav |
| Active route indicator | Subtle filled background OR left-side accent bar | Server-rendered active class |
| Role/account context | Top of sidebar, avatar + name + role badge | Employer / Employee / Admin |
| Global search | Top-bar input OR Ctrl+K modal | Simple modal for v1 |
| User menu (top-right) | Avatar → dropdown: profile, settings, theme toggle, logout | Standard pattern |
| Breadcrumbs OR clear page title | Pick one; stay consistent | Page title is simpler |

### Data Display

| Component | Baseline |
|-----------|----------|
| Stat/KPI cards | Number + label + optional delta; subtle border or soft shadow |
| Tables | Subtle row separation, sortable headers, sticky header, row hover, pagination |
| Empty states | Icon + heading + description + primary CTA. Never a blank div |
| Loading states | Skeleton screens (shimmer) — NOT centered spinners |
| Toast notifications | Bottom-right, auto-dismiss, dismissible, stackable |

### Forms & Inputs

| Component | Baseline |
|-----------|----------|
| Input fields | ~40px height, 8-10px radius, 1px border, color-shift + subtle focus ring |
| Labels | Above input, 13-14px, medium weight. Floating labels are out |
| Inline validation | Error below input in red ~12-13px; red border on field |
| Buttons | Primary (filled), secondary (outlined/ghost), destructive (red) |
| Disabled states | ~50% opacity + cursor: not-allowed |

### Feedback Components

| Component | Baseline |
|-----------|----------|
| Badges/chips | Pill-shaped, 11-12px, color-coded by semantic meaning, mixed-case |
| Status indicators | Colored dot + label |
| Avatars | Circular, initials fallback, consistent size scale (24/32/40/48/64px) |
| Tooltips | Appear on hover after ~400ms, dark background, small arrow |
| Modals | Centered, ~500-600px, backdrop blur OR 50% black overlay, ESC to close, focus trap |
| Dropdowns | Anchored to trigger, drop-shadow, 4-8px radius, keyboard navigable |

---

## Differentiators (premium feel)

### Visual Polish

| Pattern | Why it elevates |
|---------|----------------|
| Subtle micro-interactions | Buttons compress on press, dropdowns ease-in (150-200ms) |
| Hairline borders (1px) over heavy shadows | Linear/Vercel approach — cleaner, flatter |
| Tabular numerals | `font-variant-numeric: tabular-nums` on stats and timestamps |
| Consistent radius scale | 4/6/8/12/16px — everything aligned |
| Refined color palette | One brand color + neutral gray scale (10+ steps) + 4 semantic colors |
| Subtle dot/grid backgrounds | Faint dotted pattern on hero sections (Linear, Vercel style) |

### Stat Card Premium Patterns

| Pattern | What it does |
|---------|--------------|
| Sparkline inside card | Tiny 60-80px line chart of last 7-30 days |
| Delta with trend icon | "+12.4% ↑" green / "-3.1% ↓" red with background tint |
| Comparison context | "vs last week" in muted text |
| Click-to-drill-down | Whole card is a link; hover confirms it |
| Icon in tinted square | 32-40px rounded square, 10% brand-color tint, centered icon (Stripe/Resend) |

### Table Premium Patterns

| Pattern | What it does |
|---------|--------------|
| Inline row actions on hover | Edit/delete/menu icons appear right edge on hover |
| Bulk-select with floating action bar | Checkbox per row; floating bar when ≥1 selected |
| Filter chips above table | Active filters as removable pills + "Clear all" |
| Server-side pagination with total | "Showing 1–25 of 487" |
| Empty filtered state | Different from empty-table: "No results match filters" + Clear button |

### Form Premium Patterns

| Pattern | What it does |
|---------|--------------|
| Sectioned forms with sticky save bar | Long forms split by section; sticky "Save / Discard" when dirty |
| Optimistic UI | Submit immediately; toast confirms; rollback on error |
| Drag-and-drop file upload with preview | NOT a default `<input type="file">` |

---

## Anti-features (avoid)

### Visual Anti-Patterns

| Anti-Pattern | Why dated | Do instead |
|---|---|---|
| Heavy drop shadows on every card | Material Design 2014-2017 holdover | 1px hairline border OR very soft shadow |
| Bright saturated gradients on stat cards | Bootstrap admin templates 2016-2019 | Single solid color, subtle gradient only on hero |
| Large border-radius (>16px) on cards | Reads "consumer app" not "professional tool" | 8-12px max on cards |
| All-caps section headings | 2010s flat-design holdover | Mixed case, medium weight |
| Emoji + line icons mixed | Inconsistent visual language | One icon set throughout |
| Three different font families | Noisy | One sans-serif + optional mono for numbers |
| Sidebar with rainbow-colored icons | Bootstrap admin hallmark | Monochrome icons; color only on active state |
| Glassmorphism on every panel | 2021 trend, aged poorly when over-applied | Use sparingly: only on modals/floating menus |

### Layout Anti-Patterns

| Anti-Pattern | Why dated | Do instead |
|---|---|---|
| Centered "Welcome back {Name}!" hero with giant illustration | Marketing-page feel | Quiet greeting in page header |
| Stat cards in 2×2 grid filling 50% of viewport | Wastes screen space | 4-up row of compact cards |
| Top-tab horizontal navigation as primary | Hard scaling limit; 2015 PHP admin feel | Persistent left sidebar |
| Footer on every dashboard page | App-shell anti-pattern | Footer-free dashboard; version in user menu |

### Table Anti-Patterns

| Anti-Pattern | Why dated |
|---|---|
| Heavy row borders + zebra stripes + hover color | Visual noise — pick one |
| Bootstrap-style `<< < 1 2 3 ... > >>` pagination | 2014 jQuery DataTables look |
| Action column with text "Edit \| Delete \| View" | Cluttered — use icon buttons on hover |
| Tall rows with excessive padding | Wastes vertical space; aim for 44-52px row height |

### Form Anti-Patterns

| Anti-Pattern | Why dated |
|---|---|
| Inputs with `border: 1px solid #ccc` | Default-browser look |
| Submit button labeled "Submit" | Generic — use action verb: "Save profile", "Post vacancy" |
| Errors in `alert()` or top-of-page red banner | Disconnects error from cause |
| Single-column forms stretching full viewport | Constrain to 480-640px |

### Color Anti-Patterns

| Anti-Pattern | Why dated |
|---|---|
| `#007BFF` Bootstrap blue everywhere | Reads as "Bootstrap admin template" |
| Pure black on pure white | Eye strain — use #0A0A0A on #FAFAFA |

---

## Per-Page Recommendations

### Dashboard
**Layout:** Page header → 4-up KPI card row → 2-column (chart 2/3 + activity feed 1/3) → secondary widgets

| Component | Recommendation |
|-----------|----------------|
| Hero banner | DROP or downgrade to quiet 1-line greeting |
| Stat cards | 4 compact: tinted-square icon + label + big tabular number + delta + sparkline |
| Activity feed | Avatar + actor + verb + object + relative time; grouped by day |
| Chart | One primary chart, brand color line/area, hover tooltip |
| Empty state (new user) | Onboarding checklist instead of empty cards |

### Vacancies List
| Component | Recommendation |
|-----------|----------------|
| Layout | Search bar + filter chips at top → card grid |
| Card | Logo + title + company + location + salary + tags + "Apply" + bookmark |
| Filters | Location, salary, type, posted-date — removable chips |
| Empty state | Different copy for "no vacancies" vs "no filter results" |

### Vacancy Detail
| Component | Recommendation |
|-----------|----------------|
| Layout | Two-column: description (2/3) + sticky sidebar with Apply (1/3) |
| Already applied state | Replace Apply button with status badge |

### Profile Page
| Component | Recommendation |
|-----------|----------------|
| Layout | Sectioned form: Personal / Contact / Resume / Preferences |
| Avatar upload | Circle preview → hover "Change photo" → drag-and-drop modal with crop |
| Save behavior | Sticky bottom bar on dirty; toast confirms |

### Employees List
| Component | Recommendation |
|-----------|----------------|
| Layout | Search + filters → card grid (3-4 per row) OR dense table |
| Card | Avatar (status ring) + name + role + skill tags + "View / Message" |

### Admin Panel
| Component | Recommendation |
|-----------|----------------|
| Layout | Stat-card row → tabbed (Users / Vacancies / Reports) each with data table |
| Tables | Bulk-select, sortable, hover-row-actions, server-side pagination |
| Row actions | Overflow menu `⋯`: View / Edit / Suspend / Delete |

### Ratings Page
| Component | Recommendation |
|-----------|----------------|
| Layout | Summary card (avg + distribution bars) → individual rating list |
| Rating display | 5-star icons + tabular numeric average |
| Sort/filter | Recent / highest / lowest; filter by star count |

### Resume Page
| Component | Recommendation |
|-----------|----------------|
| Layout | Preview toggle ↔ Edit; sections as collapsible cards |
| Adding items | "+ Add experience" inline forms within section |
| Export | "Download PDF" top-right |

### Chat Page
| Component | Recommendation |
|-----------|----------------|
| Layout | Two-column: conversation list (280-320px) + active conversation. Mobile: single-column |
| Conversation list item | Avatar (status ring) + name + last message (1-line) + time + unread badge |
| Message bubbles | Sent: brand color, right. Received: neutral, left. Max-width 70% |
| Composer | Bottom-fixed, auto-grow textarea, attach + send |

---

## Component Complexity Notes

### Low complexity — implement freely
- Stat cards, badges, avatar with initials, empty states, skeleton loading, status dots
- Form inputs/buttons/labels (pure CSS)
- Toast notifications (~80 lines vanilla JS)
- Sidebar layout (expanded only)
- Sortable table headers (server-side PHP)

### Medium complexity — budget time
- Sidebar collapse/expand (toggle class + localStorage)
- Modal/dialog (focus trap + ESC — or use native `<dialog>`)
- Filter chips with removal (DOM manipulation + URL state)
- Drag-and-drop file upload (~150 lines vanilla)
- Dark mode toggle (CSS vars + JS sets `data-theme`)
- Charts (Chart.js or ApexCharts)
- Sticky save bar (dirty-form tracking)

### High complexity — use libraries
| Need | Recommended Library |
|------|---------------------|
| Charts | Chart.js or ApexCharts |
| Date picker | Flatpickr |
| Dropdown/tooltip positioning | Floating UI (vanilla) |
| Drag-and-drop reorder | SortableJS |
| Avatar crop | Cropper.js |
| Icons | Lucide SVG sprite or Heroicons |

---

## Roadmap Implications

1. **Foundation** — CSS tokens, typography, radius, dark mode, base components (button, input, badge, avatar)
2. **Layout shell** — Sidebar, topbar, page header, empty state, skeleton, toast
3. **Dashboard** — First page end-to-end; validates foundation
4. **List/table pages** — Vacancies + Employees + Admin (share most patterns)
5. **Detail/form pages** — Vacancy detail, Profile, Resume (sticky save, file upload)
6. **Communication pages** — Chat, Ratings (most complex; builds on earlier phases)
7. **Premium polish** (defer if needed) — Cmd-K palette, sidebar collapse, drag-to-reorder
