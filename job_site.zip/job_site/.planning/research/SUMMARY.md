# Research Summary — Nexio Dashboard Redesign

**Project:** Redesign 8 post-login pages to match modern landing page aesthetic.
**Stack:** PHP + MySQL + XAMPP, vanilla CSS/JS, single `style.css`, no build tools, 2 roles, 3 locales.
**Confidence:** HIGH on CSS/architecture; MEDIUM-HIGH on features; HIGH on pitfalls.

---

## Key Findings

**Stack.** Use ITCSS-organized single `style.css` with three-tier CSS custom properties (`primitive → semantic → component`) and `@layer reset, tokens, base, layout, components, utilities, overrides` to eliminate specificity wars. Theme via `[data-theme="dark"]` overriding only Tier 2 tokens, with a cookie-driven server-rendered attribute on `<html>` to avoid FOUC. Use SVG sprite + `<use>` + `currentColor` for icons. Component naming: prefixed BEM (`l-*`, `c-*`, `lp-*`, `dash-*`, `u-*`, `is-*`).

**Table Stakes:**
- Persistent left sidebar (240-280px, role badge, server-rendered active state)
- Top bar with search + user menu + theme toggle
- Stat/KPI cards (tinted-square icon + tabular number + delta)
- Data tables (sticky header, sortable, hover row actions, server-side pagination)
- Form inputs (~40px, 8-10px radius, label above, inline validation)
- Empty states (icon + heading + CTA — never a blank div) + skeleton loaders
- Toasts, modals (focus trap + ESC), badges, avatars (initials fallback)

**Watch Out For:**
- **Inline `style=""` in PHP** silently beats class-based redesign — grep all PHP first
- **Class-name collisions** between landing and dashboard — prefix convention is non-negotiable
- **Theme FOUC** on every PHP page navigation — render `<html data-theme>` server-side from cookie
- **Hardcoded colors in component rules** break dark mode — zero hex literals outside `:root`
- **`backdrop-filter` overuse** kills mid-range Windows laptops — header/modal only
- **Russian/Kazakh text expansion** (10-50% longer) — never fixed widths on text; `min-width: 0` on flex children
- **`100vh` on mobile** — always `100dvh` for app shells
- **JS-coupled `id` and form `name=""` attributes** — grep before any HTML refactoring

---

## Recommended Build Order

1. **Phase 0 — Audit & Foundations** — grep inline styles, `!important`, JS hooks, hardcoded colors; add `@layer` declaration (no visual change)
2. **Phase 1 — Token & Theme Foundation** — Tier 1-2-3 tokens, cookie-driven dark mode, `prefers-reduced-motion`, SVG icon sprite
3. **Phase 2 — Shared Components (`c-*`)** — buttons, inputs, badges, cards, modals, toasts, empty states, skeletons; built in isolation page first
4. **Phase 3 — Dashboard Shell (`dash-*`)** — grid layout, sidebar, topbar, page header; mobile-first
5. **Phase 4 — Dashboard Page** — 4-up KPI row, chart, activity feed; validates foundation end-to-end
6. **Phase 5 — List/Table Pages** — Vacancies + Employees + Admin (shared filter chips, table patterns, pagination)
7. **Phase 6 — Detail/Form Pages** — Vacancy detail, Profile, Resume, Ratings
8. **Phase 7 — Chat** — highest risk; freeze message logic, restyle shell only
9. **Phase 8 — Polish/Perf/A11y/i18n** — WCAG AA contrast, all 3 locales × 5 breakpoints, reduced-motion QA
10. **Phase 9 — Rollout** — remove feature flag, delete legacy token aliases

---

## Critical Design Decisions

1. **Single `style.css` is correct** — ITCSS + `@layer` provides structure without splitting files
2. **Cookie-driven server-rendered theme** — required; localStorage-only flashes on every PHP page load
3. **Prefixed BEM firewall (`lp-*` / `dash-*`)** — the naming IS the architectural boundary
4. **Glassmorphism budget = 1-2 elements max** — topbar OR modal, never on cards
5. **Feature flag rollout (`?new_ui=1`)** — all 8 pages behind flag until all done; no partial production release
6. **No new deps except approved micro-libs** — Chart.js, Flatpickr, Floating UI, SortableJS, Cropper.js, Lucide SVG

---

## Per-Page Priority

| Page | Priority | Key Components | Complexity |
|------|----------|----------------|------------|
| Dashboard | P0 | Page header, 4-up KPI cards, chart, activity feed | Medium |
| Vacancies list | P1 | Filter chips, vacancy card grid, empty states | Medium |
| Employees | P1 | Search, filter chips, employee card grid / table | Medium |
| Vacancy detail | P1 | Two-column, sticky apply sidebar, applied-state badge | Low |
| Admin | P1 | Stat row, tabbed tables, bulk-select, row menus | Medium-High |
| Profile | P2 | Sectioned form, sticky save bar, avatar upload + crop | Medium |
| Resume | P2 | Preview/edit toggle, collapsible sections, PDF export | Medium |
| Ratings | P2 | Summary card, distribution bars, rating list | Low-Medium |
| Chat | P3 | Two-column shell, conversation list, message bubbles | High |

---

## Libraries Approved

| Need | Library |
|------|---------|
| Charts | Chart.js or ApexCharts (pick one) |
| Date picker | Flatpickr (only if native `<input type="date">` insufficient) |
| Dropdown positioning | Floating UI (vanilla) |
| Drag-and-drop reorder | SortableJS (resume sections) |
| Avatar crop | Cropper.js |
| Icons | Lucide SVG sprite (preferred) or Heroicons |

---

## What to Avoid

- `transition: all` — name properties explicitly
- Animating `width`/`height`/`top`/`padding` — only `transform`, `opacity`, `box-shadow`, `background-color`
- Hardcoded hex outside `:root` — every color through a token
- `100vh` — always `100dvh` for app shells
- Heavy gradients on every card, neumorphism, all-caps headings, mixed emoji+icons
- Bootstrap blue `#007BFF`, Font Awesome icon fonts
- Renaming form `name=""` attributes or JS-hooked `id`s
- Touching PHP logic/queries — strictly out of scope
- Partial production rollout (some pages new, some old) — use feature flag

---

## Gaps to Resolve During Planning

1. **Current `style.css` inventory** — existing tokens, class names, `!important` count, inline `<style>` blocks
2. **JS hook map** — `getElementById`/`querySelector` inventory before any HTML restructure
3. **Existing theme mechanism** — class-based or `[data-theme]`?
4. **Chat live-state behavior** — must be reverse-engineered before Phase 7
5. **Chart library choice** — Chart.js vs ApexCharts, pick one

---

## Confidence

Overall: **HIGH** on direction; **MEDIUM** on specifics that depend on current `style.css` audit (Phase 0).
