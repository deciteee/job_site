# Pitfalls Research — Dashboard Redesign

**Project:** Nexio (PHP + MySQL + XAMPP, vanilla CSS/JS)
**Confidence:** HIGH on CSS/architecture pitfalls; MEDIUM on i18n-specific claims

---

## CSS / Specificity Pitfalls

### Pitfall 1: Appending rules to the bottom relying on source order
**Risk:** New styles "win" only by position. Reordering CSS breaks landing or dashboard.
**Prevention:** Namespace all dashboard rules with `body.app` scope. Use specificity intentionally, not source-order tricks.

### Pitfall 2: Specificity escalation war (`!important`, deep selectors)
**Risk:** To override legacy rules, `!important` spreads and stylesheet becomes unmaintainable.
**Prevention:** Audit existing `!important` before redesign. Adopt flat specificity convention: single class selectors, one scope class for context.

### Pitfall 3: Class name collisions between landing and dashboard
**Risk:** Both pages use `.btn`, `.card`, `.container` with different styles. One silently overwrites the other.
**Prevention:** Prefix convention: `.l-*` landing-only, `.dash-*` dashboard-only, shared only for truly shared components.

### Pitfall 4: CSS custom property name collisions
**Risk:** Same token name means different thing in different contexts.
**Prevention:** Two-tier token system. Global primitives on `:root`, semantic tokens per scope.

### Pitfall 5: Inline `style=""` attributes in PHP templates
**Risk:** Beat any class-based redesign. Only noticed file-by-file.
**Prevention:** Grep all PHP files for `style="` in Phase 0. Catalog and decide: move to class, delete, or keep for dynamic values (progress bars, chart heights).

---

## Dark Mode Pitfalls

### Pitfall 1: Hardcoded colors inside component rules
**Risk:** `background: #fff` stays white in dark mode.
**Prevention:** Zero hex/rgb literals outside token definitions. Everything through CSS custom properties.

### Pitfall 2: Forgotten surfaces — shadows, borders, scrollbars, focus rings, placeholders
**Risk:** Partial theming. Scrollbar stays white, shadow invisible, placeholder gray-on-gray.
**Prevention:** Theme audit checklist per component: background, foreground, border, shadow, focus ring, placeholder, selection, scrollbar, hover, active, disabled.

### Pitfall 3: SVG icons and logos not adapting
**Risk:** SVGs with `fill="#000"` stay black on dark backgrounds.
**Prevention:** Use `fill="currentColor"` in all inline SVGs. Logo variants for light/dark.

### Pitfall 4: Theme flash on page load (FOUC)
**Risk:** Page loads light, JS switches to dark — visible flash on every PHP page navigation.
**Prevention:** PHP reads theme from cookie and renders `<html data-theme="dark">` server-side. Zero flash. Fallback: inline `<script>` in `<head>` sets attribute before CSS renders.

### Pitfall 5: Theme not persisted across pages/tabs
**Risk:** User toggles dark on dashboard, navigates to vacancies, gets light mode.
**Prevention:** Cookie-based persistence for PHP multi-page apps (server-rendered `data-theme`).

### Pitfall 6: Contrast failures (WCAG AA)
**Risk:** "Looks cool" dark colors fail 4.5:1 contrast ratio.
**Prevention:** Check every text/background pair. Body text ≥ 4.5:1, large text ≥ 3:1.

---

## Responsive Design Pitfalls

### Pitfall 1: Desktop-first then "fixing" mobile last
**Prevention:** Mobile-first base styles; `@media (min-width:...)` adds complexity. Test at 320, 375, 768, 1024, 1440.

### Pitfall 2: Tables overflowing viewport
**Prevention:** Wrap every table in `overflow-x: auto`. Mobile: collapse to labeled-card layout via `data-label` + `::before { content: attr(data-label) }`.

### Pitfall 3: Fixed widths and pixel paddings
**Prevention:** `max-width` + `margin-inline: auto`. Use `clamp()` for fluid spacing. Use `min()` to cap widths: `min(100% - 2rem, 1200px)`.

### Pitfall 4: Hover-only interactions
**Prevention:** Always show critical actions. Use `@media (hover: hover) and (pointer: fine)` for hover-reveal patterns.

### Pitfall 5: Tap targets too small
**Prevention:** Minimum 44×44px touch targets. Padding to expand hit area without enlarging the visual.

### Pitfall 6: `100vh` on mobile browsers
**Prevention:** Use `100dvh` (dynamic viewport height) with `100vh` fallback.

### Pitfall 7: Chat and modal overlays not mobile-sized
**Prevention:** Full-screen on mobile (`inset: 0`), constrained on desktop via media queries.

---

## i18n Layout Pitfalls

### Pitfall 1: Russian/Kazakh text expansion
**Risk:** Russian runs 10-30% longer than English; Kazakh 30-50% longer. Buttons, nav items, table headers that fit in English overflow in Russian/Kazakh.
**Prevention:** Never hardcode widths on text-bearing elements. Use `min-width` for rhythm. Test all 3 locales.

### Pitfall 2: Single-line buttons with short labels
**Risk:** `white-space: nowrap` button breaks layout when "Save" becomes "Сохранить изменения".
**Prevention:** Allow wrapping by default. Set `min-height` not fixed `height`.

### Pitfall 3: Flex/grid items not handling overflow
**Risk:** Flex items have `min-width: auto`. Long text refuses to shrink.
**Prevention:** `min-width: 0` and `overflow-wrap: anywhere` on text-containing flex children.

### Pitfall 4: Table column widths optimized for English
**Prevention:** `table-layout: auto`, or column ratios in `%` not `px`. Test all locales.

### Pitfall 5: Tabs and segmented controls
**Prevention:** Allow horizontal scroll on overflow, or stack vertically below breakpoint. Avoid equal-width forcing.

### Pitfall 6: Date, number, currency formatting
**Prevention:** Use PHP `IntlDateFormatter`, `NumberFormatter`. Don't bake formats into HTML.

### Pitfall 7: Pluralization
**Risk:** "1 vacancies" or "2 вакансия" — Russian needs 3 plural forms.
**Prevention:** Translation dictionary supporting plural forms keyed by count.

---

## Performance Pitfalls

### Pitfall 1: `backdrop-filter: blur()` on large/many elements
**Risk:** Glassmorphism on sidebar + header + modals = slideshow on mid-range Windows laptops.
**Prevention:** Use `backdrop-filter` sparingly — header only, or modal backdrop only. Never on scrolling content. Provide solid fallback: `@supports not (backdrop-filter: blur(10px))`.

### Pitfall 2: Layered box-shadows with large blur radii
**Prevention:** One shadow per element, max two for emphasis. Keep blur radius < 30px. Pre-baked shadow tokens enforce the budget.

### Pitfall 3: `transition: all`
**Prevention:** Always name properties: `transition: background-color 0.2s, transform 0.2s`. Never `transition: all`.

### Pitfall 4: Animating expensive properties
**Prevention:** Animate only `transform` and `opacity` (GPU-composited). Avoid animating `width`, `height`, `box-shadow`, `filter`.

### Pitfall 5: Web fonts blocking render
**Prevention:** `font-display: swap`, self-host fonts, preload critical fonts. Subset to Cyrillic + Latin.

### Pitfall 6: Avatar/image layout shift (CLS)
**Prevention:** Always set `width`, `height`, or `aspect-ratio` on `<img>`. Placeholder background while loading.

---

## Scope Creep Pitfalls

### Pitfall 1: "While I'm in this file..." PHP edits
**Prevention:** Hard rule: redesign touches CSS, HTML class names, and template markup only. PHP logic, queries, form names — out of scope.

### Pitfall 2: HTML restructuring that breaks PHP-rendered structure
**Prevention:** Never rename `name=""` attributes on form fields. Never change `<form action>`. Wrap, don't move existing PHP markup.

### Pitfall 3: Renaming `id` attributes that JS hooks into
**Prevention:** Grep all JS for `getElementById`, `querySelector('#')` before renaming any id. Add new classes alongside legacy ids.

### Pitfall 4: Inconsistent rollout — some pages redesigned, some not
**Prevention:** Plan all 8 pages in a single roadmap. Ship behind feature flag (`?new_ui=1`) until all pages done. Per-page completion checklist.

### Pitfall 5: Adding new dependencies
**Prevention:** Document no-npm/no-framework rule. PRs that introduce dependencies are rejected.

### Pitfall 6: Replacing native form controls with custom JS widgets
**Prevention:** Style native controls with CSS (`appearance: none` + custom chevron). Build custom widget only when CSS cannot achieve the design.

### Pitfall 7: Chat redesign breaking live-state behavior
**Prevention:** Freeze message list rendering logic. Restyle wrapping shell only. Test with two browsers open.

---

## Phase Mapping

| Phase | Pitfalls to Address |
|-------|---------------------|
| **Phase 0 — Audit & Tokens** | CSS Pitfalls 1-5; Dark Mode 1, 6; Scope Creep 1, 5 |
| **Phase 1 — Theming Foundation** | Dark Mode 2-5; Performance 5 |
| **Phase 2 — Shell (sidebar, topbar, nav)** | Responsive 1, 4, 5, 7; i18n 1, 2, 5; Performance 1, 2 |
| **Phase 3 — Dashboard, Profile, Resume** | All Responsive; i18n 1-3, 6; Scope Creep 2, 3 |
| **Phase 4 — Vacancies, Employees, Ratings, Admin** | Responsive 2, 3; i18n 4, 7; Scope Creep 1, 6 |
| **Phase 5 — Chat** | Scope Creep 7; Responsive 7; Performance 3, 4 |
| **Phase 6 — Polish, Performance, A11y** | Performance 1-7; Dark Mode 6; i18n full-locale sweep |
| **Phase 7 — Rollout** | Scope Creep 4; testing strategy |

---

## Phase 0 Greps to Run Immediately

```bash
# Inline styles in PHP
grep -r 'style="' pages/ includes/ index.php

# !important count in CSS
grep -c '!important' assets/css/style.css

# JS id/class hooks (before renaming anything)
grep -r 'getElementById\|querySelector' assets/js/

# Hardcoded colors in component rules (outside :root)
grep -n '#[0-9a-fA-F]\{3,8\}\|rgb(\|hsl(' assets/css/style.css
```
