# Nexio Dashboard Redesign — Roadmap

## Overview

8 phases | 56 requirements | Estimated completion: 6-9 working sessions

Horizontal-layers-first ordering: foundation → components → shell → pages → polish. Every layer must work before the next is built on top. Visual change appears starting Phase 3 (shell); Phases 1-2 are infrastructure with no user-visible regression.

---

## Phases

### Phase 1: Audit & Foundation (Tokens, Theme, Layers)

**Goal:** Establish the CSS architecture and theming primitives that every subsequent phase will consume — three-tier tokens, `@layer` cascade, cookie-driven dark mode, motion + icon primitives.

**Requirements:** FOUND-01, FOUND-02, FOUND-03, FOUND-04, FOUND-05, FOUND-06, FOUND-07

**Success Criteria:**
1. `style.css` opens with `@layer reset, tokens, base, layout, components, utilities, overrides;` and every existing rule lives inside a layer — DevTools "Layers" panel shows the structure.
2. `:root` defines Tier 1 (primitives), Tier 2 (semantics), Tier 3 (component) tokens; `[data-theme="dark"]` overrides only Tier 2 — toggling theme repaints without FOUC on a hard PHP reload.
3. An audit document lists every inline `style=""`, `!important`, JS-coupled `id`/`name`, and hardcoded hex literal currently in the codebase — committed before any visual change.
4. SVG icon sprite is included from `header.php`; a test `<svg><use href="#icon-foo"></use></svg>` renders and inherits `currentColor` on both themes.

---

### Phase 2: Shared Components (`c-*` Library)

**Goal:** Build the reusable visual building blocks — buttons, inputs, badges, avatars, cards, modals, toasts, skeletons, KPI cards — in isolation, before any page consumes them.

**Requirements:** COMP-01, COMP-02, COMP-03, COMP-04, COMP-05, COMP-06, COMP-07, COMP-08, COMP-09

**Success Criteria:**
1. A `components.php` showcase page renders every variant (button states, input states with validation, badge colors, avatar sizes, empty state, skeleton, toast, modal, KPI card) on both themes with no console errors.
2. Buttons have primary/secondary/ghost/destructive variants; primary uses the landing-page gradient and matches index.php's CTA visually side-by-side.
3. Modal uses native `<dialog>` with focus trap and ESC-to-close; toast stacks bottom-right and auto-dismisses; skeleton shimmer respects `prefers-reduced-motion`.
4. Every component class is prefixed `c-*`; zero hex literals appear in component rules — all colors flow through Tier 2 tokens.

---

### Phase 3: App Shell (Sidebar, Topbar, Grid Layout)

**Goal:** Replace the legacy post-login chrome with a unified app-shell — persistent sidebar, sticky topbar, CSS Grid layout — that wraps all 8 pages identically.

**Requirements:** SHELL-01, SHELL-02, SHELL-03, SHELL-04, SHELL-05, SHELL-06

**Success Criteria:**
1. All 8 post-login pages (dashboard, vacancies, profile, employees, ratings, admin, resume, chat) render inside the same `grid-template-areas` shell with `100dvh` — no page bypasses it.
2. Sidebar (240-280px) collapses to an icon rail below 960px; the active nav item is highlighted server-side via PHP `basename($_SERVER['PHP_SELF'])`, no JS flicker on navigation.
3. Sidebar shows the user's avatar, name, and role badge ("Работодатель" / "Соискатель" / "Admin") localized correctly in ru/kz/en.
4. Topbar dropdown opens on click, contains profile/settings/theme-toggle/logout, traps focus, and closes on outside-click + ESC.

---

### Phase 4: Dashboard Page (KPI + Chart + Activity)

**Goal:** Deliver the flagship post-login page — 4-up KPI row, 7-day activity chart, activity feed, role-aware content, onboarding empty state — proving the foundation end-to-end.

**Requirements:** DASH-01, DASH-02, DASH-03, DASH-04, DASH-05

**Success Criteria:**
1. Logging in as an employer shows vacancies/applications/ratings/messages KPIs; logging in as an employee shows applications/vacancies/score/messages KPIs — verified by switching test accounts.
2. The 7-day activity chart renders via Chart.js, uses brand color from Tier 2 tokens, shows tooltips on hover, and re-themes correctly when dark mode toggles.
3. Activity feed groups events by day with avatar + actor + verb + relative timestamp; scrolls smoothly with no layout shift.
4. A brand-new account (no data) shows the onboarding empty state (icon + heading + description + CTA) instead of zero-value KPIs.

---

### Phase 5: List & Table Pages (Vacancies, Employees, Admin)

**Goal:** Apply the shared filter-chip + card-grid + table patterns across the three list-driven pages, including all empty states and pagination.

**Requirements:** VAC-01, VAC-02, VAC-03, VAC-04, VAC-05, EMP-01, EMP-02, EMP-03, ADMIN-01, ADMIN-02, ADMIN-03

**Success Criteria:**
1. Vacancies and Employees both render search + filter chips above a card grid (3-4 per row); chips toggle on click and update the URL query string for shareable filtered views.
2. Each list page shows two distinct empty states — one for "no data exists" and one for "no results match these filters" — with the appropriate CTA.
3. Vacancy detail page is a 2-column layout (description 2/3 + sticky Apply sidebar 1/3); the Apply button becomes a status badge ("Заявка отправлена") for already-applied vacancies.
4. Admin tables have sticky headers, sortable columns, `⋯` row action menus, and server-side pagination showing "Showing X–Y of Z" — page navigation reloads only the table region's data fetch.

---

### Phase 6: Detail & Form Pages (Profile, Resume, Ratings)

**Goal:** Redesign the personal/editable pages — sectioned profile form, dual-mode resume, ratings summary — using shared form components and the sticky-save pattern.

**Requirements:** PROF-01, PROF-02, PROF-03, RAT-01, RAT-02, RES-01, RES-02, RES-03

**Success Criteria:**
1. Profile renders four sections (Personal / Contact / About / Preferences); editing any field surfaces a sticky save bar at the bottom that disappears on save and triggers a success toast.
2. Avatar upload opens a Cropper.js modal with circular preview and drag-and-drop; cropped result replaces the avatar on save without page reload.
3. Resume has a Preview ↔ Edit toggle; in Edit mode each section (Personal / Experience / Education / Skills) is a collapsible card with an inline "+ Add" form (no modal).
4. Ratings page shows a summary card (average + 5→1 distribution bars) above the individual rating list; sort dropdown re-orders by recent/highest/lowest without losing scroll position.

---

### Phase 7: Chat Page (Two-Column Shell + Bubbles)

**Goal:** Restyle the chat shell — conversation list, message bubbles, fixed composer, mobile single-column — without touching any message-sending or socket logic.

**Requirements:** CHAT-01, CHAT-02, CHAT-03, CHAT-04, CHAT-05

**Success Criteria:**
1. Desktop renders a two-column layout: conversation list (280-320px, scrollable) on the left, active conversation on the right; selecting a conversation updates the right pane without full page reload.
2. Each conversation list item shows avatar + name + last-message preview + timestamp + unread badge (when applicable); the active conversation is visually distinct.
3. Sent messages appear right-aligned in brand color; received messages left-aligned in neutral; both capped at 70% max-width with proper wrapping for long URLs and Cyrillic text.
4. On mobile (<768px) the conversation list and active conversation become single full-screen views with a back button; composer textarea auto-grows to ~4 lines max then scrolls internally.

---

### Phase 8: Polish — i18n, Responsive, A11y, FOUC

**Goal:** Cross-cutting quality pass — verify all pages survive every locale, breakpoint, theme transition, and accessibility check before removing the rollout flag.

**Requirements:** QA-01, QA-02, QA-03, QA-04, QA-05

**Success Criteria:**
1. All 8 pages tested in ru, kz, and en with no overflow, no clipped text, no fixed-width breaks — Russian/Kazakh expansion handled via `min-width: 0` on flex children.
2. All 8 pages tested at 320px / 375px / 768px / 1024px / 1440px viewports — no horizontal scroll, no broken layouts; mobile-first breakpoints verified in DevTools.
3. WCAG AA contrast (≥4.5:1 body text) verified on both light and dark themes via axe DevTools — zero contrast failures reported.
4. `git diff` for the entire redesign shows zero changes to `.php` files outside template markup, CSS class names, and HTML structure — no SQL, no PHP logic, no route changes.

---

## Requirement Coverage

| Requirement | Phase | Status |
|-------------|-------|--------|
| FOUND-01 | Phase 1 | Pending |
| FOUND-02 | Phase 1 | Pending |
| FOUND-03 | Phase 1 | Pending |
| FOUND-04 | Phase 1 | Pending |
| FOUND-05 | Phase 1 | Pending |
| FOUND-06 | Phase 1 | Pending |
| FOUND-07 | Phase 1 | Pending |
| COMP-01 | Phase 2 | Pending |
| COMP-02 | Phase 2 | Pending |
| COMP-03 | Phase 2 | Pending |
| COMP-04 | Phase 2 | Pending |
| COMP-05 | Phase 2 | Pending |
| COMP-06 | Phase 2 | Pending |
| COMP-07 | Phase 2 | Pending |
| COMP-08 | Phase 2 | Pending |
| COMP-09 | Phase 2 | Pending |
| SHELL-01 | Phase 3 | Pending |
| SHELL-02 | Phase 3 | Pending |
| SHELL-03 | Phase 3 | Pending |
| SHELL-04 | Phase 3 | Pending |
| SHELL-05 | Phase 3 | Pending |
| SHELL-06 | Phase 3 | Pending |
| DASH-01 | Phase 4 | Pending |
| DASH-02 | Phase 4 | Pending |
| DASH-03 | Phase 4 | Pending |
| DASH-04 | Phase 4 | Pending |
| DASH-05 | Phase 4 | Pending |
| VAC-01 | Phase 5 | Pending |
| VAC-02 | Phase 5 | Pending |
| VAC-03 | Phase 5 | Pending |
| VAC-04 | Phase 5 | Pending |
| VAC-05 | Phase 5 | Pending |
| EMP-01 | Phase 5 | Pending |
| EMP-02 | Phase 5 | Pending |
| EMP-03 | Phase 5 | Pending |
| ADMIN-01 | Phase 5 | Pending |
| ADMIN-02 | Phase 5 | Pending |
| ADMIN-03 | Phase 5 | Pending |
| PROF-01 | Phase 6 | Pending |
| PROF-02 | Phase 6 | Pending |
| PROF-03 | Phase 6 | Pending |
| RAT-01 | Phase 6 | Pending |
| RAT-02 | Phase 6 | Pending |
| RES-01 | Phase 6 | Pending |
| RES-02 | Phase 6 | Pending |
| RES-03 | Phase 6 | Pending |
| CHAT-01 | Phase 7 | Pending |
| CHAT-02 | Phase 7 | Pending |
| CHAT-03 | Phase 7 | Pending |
| CHAT-04 | Phase 7 | Pending |
| CHAT-05 | Phase 7 | Pending |
| QA-01 | Phase 8 | Pending |
| QA-02 | Phase 8 | Pending |
| QA-03 | Phase 8 | Pending |
| QA-04 | Phase 8 | Pending |
| QA-05 | Phase 8 | Pending |

**Coverage:** 55 unique requirement IDs / 55 mapped — 100% ✓
*(Note: REQUIREMENTS.md lists "RAT-01" twice — the second instance is treated as a typo for the rating-list sub-requirement; both intents are covered by Phase 6 success criteria.)*

---

## Progress Table

| Phase | Plans Complete | Status | Completed |
|-------|----------------|--------|-----------|
| 1. Audit & Foundation | 0/0 | Not started | — |
| 2. Shared Components | 0/0 | Not started | — |
| 3. App Shell | 0/0 | Not started | — |
| 4. Dashboard Page | 0/0 | Not started | — |
| 5. List & Table Pages | 0/0 | Not started | — |
| 6. Detail & Form Pages | 0/0 | Not started | — |
| 7. Chat Page | 0/0 | Not started | — |
| 8. Polish | 0/0 | Not started | — |
