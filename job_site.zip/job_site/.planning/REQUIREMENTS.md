# Requirements — Nexio Dashboard Redesign

## v1 Requirements

### FOUNDATION — Token & Theme System
- [ ] **FOUND-01**: CSS three-tier token system (primitives, semantics, dark overrides) defined in `:root`
- [ ] **FOUND-02**: `@layer` cascade structure added to `style.css` eliminating specificity conflicts
- [ ] **FOUND-03**: Cookie-driven server-rendered `[data-theme]` on `<html>` — zero FOUC on PHP page navigation
- [ ] **FOUND-04**: Light and dark themes work consistently across all 8 post-login pages
- [ ] **FOUND-05**: SVG icon sprite included in `header.php` using `currentColor` — no icon fonts
- [ ] **FOUND-06**: `prefers-reduced-motion` global block added
- [ ] **FOUND-07**: Phase 0 audit: all inline `style=""`, `!important`, JS-coupled ids inventoried before changes

### SHELL — Sidebar & Topbar
- [ ] **SHELL-01**: Persistent left sidebar (240-280px, collapsible to icon rail on mobile <960px)
- [ ] **SHELL-02**: Sidebar shows role badge (Работодатель / Соискатель / Admin) + user avatar + name
- [ ] **SHELL-03**: Server-rendered active state on sidebar nav items (PHP `basename()` comparison)
- [ ] **SHELL-04**: Sticky top bar with user menu dropdown (profile, settings, theme toggle, logout)
- [ ] **SHELL-05**: App-shell CSS Grid layout (`grid-template-areas`, `100dvh`) — mobile-first
- [ ] **SHELL-06**: All 8 post-login pages use the same redesigned shell (no exceptions)

### COMPONENTS — Shared (`c-*`)
- [ ] **COMP-01**: Button variants: primary (gradient), secondary (outline), ghost, destructive
- [ ] **COMP-02**: Form inputs (~40px height, 8-10px radius, label above, inline red validation below field)
- [ ] **COMP-03**: Badges/chips (pill-shaped, semantic color-coding, mixed-case)
- [ ] **COMP-04**: Avatar component (circular, initials fallback, consistent size scale)
- [ ] **COMP-05**: Empty state component (icon + heading + description + CTA)
- [ ] **COMP-06**: Skeleton loader component (shimmer animation — replaces spinners)
- [ ] **COMP-07**: Toast notifications (bottom-right, auto-dismiss, stackable)
- [ ] **COMP-08**: Modal/dialog (focus trap, ESC to close, backdrop, native `<dialog>`)
- [ ] **COMP-09**: Stat/KPI card (tinted-square icon + tabular number + delta badge)

### DASHBOARD page
- [ ] **DASH-01**: 4-up KPI card row (employer: vacancies/applications/ratings/messages; employee: applications/vacancies/score/messages)
- [ ] **DASH-02**: Activity feed (avatar + actor + verb + timestamp, grouped by day)
- [ ] **DASH-03**: Primary chart (7-day activity, Chart.js, brand color, hover tooltip)
- [ ] **DASH-04**: Empty/onboarding state for new users with no data
- [ ] **DASH-05**: Employer and employee role show different dashboard content

### VACANCIES pages
- [ ] **VAC-01**: Vacancy list with search bar + filter chips (location, type, posted-date)
- [ ] **VAC-02**: Vacancy card (title + company + location + salary + tags + Apply/bookmark)
- [ ] **VAC-03**: Empty state for no vacancies and separate state for no filter results
- [ ] **VAC-04**: Vacancy detail — two-column layout (description 2/3 + sticky sidebar with Apply 1/3)
- [ ] **VAC-05**: "Already applied" state replaces Apply button with status badge

### PROFILE page
- [ ] **PROF-01**: Sectioned form (Personal / Contact / About / Preferences)
- [ ] **PROF-02**: Avatar upload with circle preview + drag-and-drop modal (Cropper.js)
- [ ] **PROF-03**: Sticky save bar appears only when form is dirty; toast on success

### EMPLOYEES page
- [ ] **EMP-01**: Search + filter chips → employee card grid (3-4 per row)
- [ ] **EMP-02**: Employee card (avatar + status ring + name + role + skills + View/Message)
- [ ] **EMP-03**: Empty filtered state

### ADMIN page
- [ ] **ADMIN-01**: Stat-card row at top + tabbed sections (Users / Vacancies)
- [ ] **ADMIN-02**: Data tables with sticky header, sortable columns, `⋯` row action menus
- [ ] **ADMIN-03**: Server-side pagination with "Showing X–Y of Z" counter

### RATINGS page
- [ ] **RAT-01**: Summary card (avg rating + distribution bars 5→1 stars)
- [ ] **RAT-01**: Individual rating list (avatar + name + stars + date + comment)
- [ ] **RAT-02**: Sort by recent/highest/lowest

### RESUME page
- [ ] **RES-01**: Preview ↔ Edit toggle
- [ ] **RES-02**: Sections as collapsible cards (Personal / Experience / Education / Skills)
- [ ] **RES-03**: Inline "+ Add" forms within each section (no modal)

### CHAT page
- [ ] **CHAT-01**: Two-column shell (conversation list 280-320px + active conversation)
- [ ] **CHAT-02**: Conversation list item (avatar + name + last message + time + unread badge)
- [ ] **CHAT-03**: Message bubbles (sent: brand color right; received: neutral left; max-width 70%)
- [ ] **CHAT-04**: Fixed composer bar at bottom (auto-grow textarea + send button)
- [ ] **CHAT-05**: Mobile: single-column full-screen with back button

### QUALITY — Cross-cutting
- [ ] **QA-01**: All pages tested in all 3 locales (ru/kz/en) — no overflow, no fixed-width breaks
- [ ] **QA-02**: All pages tested at 320px, 375px, 768px, 1024px, 1440px viewports
- [ ] **QA-03**: Dark theme works without FOUC on all pages
- [ ] **QA-04**: WCAG AA contrast (≥4.5:1 body text) on both themes
- [ ] **QA-05**: Zero PHP logic changes — only CSS, HTML classes, and template markup

---

## v2 Requirements (deferred)

- Cmd-K command palette
- Keyboard shortcuts cheatsheet (`?` key)
- Sidebar collapse with localStorage persistence on desktop
- Drag-to-reorder resume sections (SortableJS)
- Animated page transitions (View Transitions API)
- Saved table view presets
- Column visibility toggle in admin tables
- PDF resume export (server-side)
- Onboarding product tour (spotlight tooltips)

---

## Out of Scope

- PHP logic, SQL queries, routing — only UI changes
- New functional features (real-time notifications, new search algorithms)
- New build pipeline (npm, webpack, vite) — vanilla only
- Bootstrap, Tailwind, or other CSS frameworks
- Replacing the existing PHP template system
- New pages not currently in the app

---

## Traceability

| Phase | Requirements |
|-------|-------------|
| Phase 0 — Audit | FOUND-07 |
| Phase 1 — Foundation | FOUND-01 to FOUND-06 |
| Phase 2 — Components | COMP-01 to COMP-09 |
| Phase 3 — Shell | SHELL-01 to SHELL-06 |
| Phase 4 — Dashboard | DASH-01 to DASH-05 |
| Phase 5 — List Pages | VAC-01 to VAC-05, EMP-01 to EMP-03, ADMIN-01 to ADMIN-03 |
| Phase 6 — Detail/Form | PROF-01 to PROF-03, RAT-01 to RAT-02, RES-01 to RES-03 |
| Phase 7 — Chat | CHAT-01 to CHAT-05 |
| Phase 8 — Polish | QA-01 to QA-05 |
