# Nexio — Dashboard Redesign

## What This Is

Nexio — платформа для поиска работы (PHP + MySQL + XAMPP). Лендинг-страница (index.php) выглядит стильно и современно: тёмный header, градиенты, glassmorphism-кнопки, анимации. Все страницы после входа (dashboard, vacancies, profile, employees, ratings, admin, resume, chat) визуально отстают — устаревший flat-дизайн 2015-года. Задача: полностью переработать UI внутренних страниц, выровняв их по стилю лендинга.

## Core Value

После входа пользователь должен чувствовать ту же премиум-атмосферу SaaS-продукта, что и на лендинге — единый дизайн-язык от первого экрана до каждой внутренней страницы.

## Requirements

### Validated

(None yet — ship to validate)

### Active

- [ ] Dashboard: hero-баннер, stat-карточки, activity feed — в стиле лендинга
- [ ] Sidebar: современный, с glassmorphism/gradient-акцентами, иконки переработаны
- [ ] Topbar: соответствует лендинг-навигации по уровню полировки
- [ ] Vacancies: карточки вакансий с современным hover, badges, typography
- [ ] Profile: современная форма-страница с avatar-upload, секции
- [ ] Employees: карточки сотрудников, фильтры, поиск — современный вид
- [ ] Admin: панель с таблицами в современном стиле
- [ ] Ratings: страница рейтингов переработана
- [ ] Resume: страница резюме переработана
- [ ] Chat: переработан в современном стиле
- [ ] Тёмная/светлая тема работает консистентно на всех страницах
- [ ] CSS-переменные и компоненты синхронизированы с лендингом

### Out of Scope

- Изменение PHP-логики / бэкенда — только UI
- Смена библиотек (остаётся vanilla JS + CSS)
- Новые функциональные фичи — только визуал

## Context

- Стек: PHP 8+, MySQL, vanilla CSS/JS, XAMPP (localhost)
- Лендинг index.php — эталон стиля: тёмный navy `#1a2e4a`, primary `#2563eb`, градиентные кнопки
- Единый style.css содержит и лендинг, и дашборд — нужно расширить/переработать dashboard-секцию
- Два пользовательских роля: employer / employee (разные UI в dashboard)
- Поддержка 3 языков: ru, kz, en (i18n через lang/*.php)
- Светлая и тёмная тема через CSS-переменные (`data-theme="dark"`)

## Constraints

- **Tech stack**: Vanilla PHP, CSS, JS — никаких фреймворков
- **Design reference**: index.php — единственный источник истины по стилю
- **Compatibility**: XAMPP localhost, без сборщиков (no npm/webpack)

## Key Decisions

| Decision | Rationale | Outcome |
|----------|-----------|---------|
| Переработать CSS в style.css, не создавать новый файл | Единый файл, нет дублирования переменных | — Pending |
| Сохранить структуру PHP-шаблонов | Только UI, логика не трогается | — Pending |
| Opus 4.7 для всех planning-агентов | Пользователь запросил максимальное качество | — Pending |

## Evolution

This document evolves at phase transitions and milestone boundaries.

**After each phase transition** (via `/gsd-transition`):
1. Requirements invalidated? → Move to Out of Scope with reason
2. Requirements validated? → Move to Validated with phase reference
3. New requirements emerged? → Add to Active
4. Decisions to log? → Add to Key Decisions
5. "What This Is" still accurate? → Update if drifted

**After each milestone** (via `/gsd-complete-milestone`):
1. Full review of all sections
2. Core Value check — still the right priority?
3. Audit Out of Scope — reasons still valid?
4. Update Context with current state

---
*Last updated: 2026-05-09 after initialization*
