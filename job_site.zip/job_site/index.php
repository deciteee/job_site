<?php
session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/i18n.php';

if (isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/pages/dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="<?= currentLang() === 'kz' ? 'kk' : 'ru' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= SITE_NAME ?> — <?= t('site_tagline') ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <script>(function(){var t=localStorage.getItem('nexio-theme')||'light';document.documentElement.setAttribute('data-theme',t);})()</script>
</head>
<body class="lp-page">

<!-- ===== Header ===== -->
<header class="lp-header" id="lpHeader">
    <div class="lp-header__inner">

        <a href="<?= BASE_URL ?>/" class="lp-header__logo">
            <svg viewBox="0 0 105 32" fill="none" height="30">
                <defs>
                    <linearGradient id="nexio-g-lp" x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0%" stop-color="#60a5fa"/>
                        <stop offset="100%" stop-color="#2563eb"/>
                    </linearGradient>
                </defs>
                <path d="M4 27V7L22 27V7" stroke="url(#nexio-g-lp)" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
                <circle cx="22" cy="2.5" r="3" fill="#3b82f6"/>
                <text x="32" y="24" font-family="-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif"
                      font-size="21" font-weight="800" fill="currentColor" letter-spacing="-0.3">exio</text>
            </svg>
        </a>

        <nav class="lp-nav">
            <a href="#features"  class="lp-nav__link"><?= t('nav_features') ?></a>
            <a href="#how"       class="lp-nav__link"><?= t('nav_how_it_works') ?></a>
            <a href="#reviews"   class="lp-nav__link"><?= t('nav_about') ?></a>
        </nav>

        <div class="lp-header__right">
            <div class="lp-header__controls">
                <div class="lang-dropdown" id="langDropdownLp">
                    <button class="lang-dropdown__trigger lp-lang-dropdown-trigger" type="button"
                            onclick="document.getElementById('langDropdownLp').classList.toggle('open')">
                        <i data-lucide="globe" width="13" height="13"></i>
                        <?= strtoupper(currentLang()) ?>
                        <i data-lucide="chevron-down" width="10" height="10"></i>
                    </button>
                    <div class="lang-dropdown__menu">
                        <a href="?setlang=ru" class="lang-dropdown__item <?= currentLang()==='ru'?'active':'' ?>">Русский</a>
                        <a href="?setlang=kz" class="lang-dropdown__item <?= currentLang()==='kz'?'active':'' ?>">Қазақша</a>
                        <a href="?setlang=en" class="lang-dropdown__item <?= currentLang()==='en'?'active':'' ?>">English</a>
                    </div>
                </div>
                <button class="lp-theme-btn" data-action="lp-theme" title="Toggle theme">
                    <i data-lucide="moon" width="15" height="15"></i>
                </button>
            </div>

            <div class="lp-header__cta">
                <a href="<?= BASE_URL ?>/pages/login.php"    class="btn-lp-ghost"><?= t('sign_in') ?></a>
                <a href="<?= BASE_URL ?>/pages/register.php" class="btn-lp-primary">
                    <?= t('start_free') ?>
                    <i data-lucide="arrow-right" width="14" height="14"></i>
                </a>
            </div>
        </div>
    </div>
</header>

<!-- ===== Hero ===== -->
<section class="lp-hero">
    <div class="lp-hero__inner">
        <div class="lp-hero__content">
            <div class="lp-hero__badge">
                <div class="lp-hero__badge-dot"></div>
                <?= t('landing_badge') ?> v<?= VERSION ?>
            </div>

            <h1 class="lp-hero__title">
                <?= t('hero_title_line1') ?><br>
                <span class="gradient-text"><?= t('hero_title_line2') ?></span>
            </h1>

            <p class="lp-hero__subtitle"><?= t('hero_subtitle') ?></p>

            <div class="lp-hero__actions">
                <a href="<?= BASE_URL ?>/pages/register.php" class="btn-hero-primary">
                    <?= t('start_free') ?>
                    <i data-lucide="arrow-right" width="16" height="16"></i>
                </a>
                <a href="<?= BASE_URL ?>/pages/login.php" class="btn-hero-ghost">
                    <i data-lucide="circle-play" width="16" height="16"></i>
                    <?= t('watch_demo') ?>
                </a>
            </div>

            <div class="lp-hero__trust">
                <div class="lp-trust-item">
                    <div class="lp-trust-check"><i data-lucide="check" width="11" height="11"></i></div>
                    <?= t('hero_trust_free') ?>
                </div>
                <div class="lp-trust-item">
                    <div class="lp-trust-check"><i data-lucide="check" width="11" height="11"></i></div>
                    <?= t('hero_trust_nocard') ?>
                </div>
                <div class="lp-trust-item">
                    <div class="lp-trust-check"><i data-lucide="check" width="11" height="11"></i></div>
                    <?= t('hero_trust_fast') ?>
                </div>
            </div>
        </div>

        <!-- Visual -->
        <div class="lp-hero__visual">
            <div class="lp-mockup">
                <div class="lp-mockup__bar">
                    <span class="lp-mockup__dot lp-mockup__dot--r"></span>
                    <span class="lp-mockup__dot lp-mockup__dot--y"></span>
                    <span class="lp-mockup__dot lp-mockup__dot--g"></span>
                    <span class="lp-mockup__url">nexio.app/dashboard</span>
                </div>
                <div class="lp-mockup__body">
                    <div class="lp-mockup__sidebar">
                        <div class="lp-mockup__sl"></div>
                        <div class="lp-mockup__si lp-mockup__si--a"></div>
                        <div class="lp-mockup__si"></div>
                        <div class="lp-mockup__si"></div>
                        <div class="lp-mockup__si"></div>
                        <div class="lp-mockup__si"></div>
                    </div>
                    <div class="lp-mockup__content">
                        <div class="lp-mockup__topbar"></div>
                        <div class="lp-mockup__cards">
                            <div class="lp-mockup__mc lp-mockup__mc--b"></div>
                            <div class="lp-mockup__mc lp-mockup__mc--g"></div>
                            <div class="lp-mockup__mc lp-mockup__mc--p"></div>
                        </div>
                        <div class="lp-mockup__row"></div>
                        <div class="lp-mockup__row lp-mockup__row--alt"></div>
                        <div class="lp-mockup__row"></div>
                        <div class="lp-mockup__row lp-mockup__row--alt"></div>
                        <div class="lp-mockup__row"></div>
                    </div>
                </div>
            </div>

            <!-- Floating cards -->
            <div class="lp-hero__float lp-hero__float--1">
                <div class="lp-float__label"><?= t('stat_total_jobs') ?></div>
                <div class="lp-float__value">2,400+</div>
                <div class="lp-float__change">↑ 18% <?= currentLang() === 'kz' ? 'осы айда' : 'за месяц' ?></div>
            </div>
            <div class="lp-hero__float lp-hero__float--2">
                <div class="lp-float__label"><?= currentLang() === 'kz' ? 'Жаңа үміткер' : 'Новый кандидат' ?></div>
                <div class="lp-float__row" style="margin-top:6px;">
                    <div class="lp-float__avatar">АП</div>
                    <div>
                        <div class="lp-float__name">Алексей П.</div>
                        <div class="lp-float__role">Senior PHP Dev</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ===== Stats bar ===== -->
<div class="lp-stats">
    <div class="lp-stats__inner">
        <div class="lp-stat-item">
            <div class="lp-stat-item__num">500+</div>
            <div class="lp-stat-item__label"><?= t('stat_companies') ?></div>
        </div>
        <div class="lp-stat-item">
            <div class="lp-stat-item__num">2,400+</div>
            <div class="lp-stat-item__label"><?= t('stat_total_jobs') ?></div>
        </div>
        <div class="lp-stat-item">
            <div class="lp-stat-item__num">15K+</div>
            <div class="lp-stat-item__label"><?= t('stat_candidates') ?></div>
        </div>
        <div class="lp-stat-item">
            <div class="lp-stat-item__num">98%</div>
            <div class="lp-stat-item__label"><?= t('stat_satisfaction') ?></div>
        </div>
    </div>
</div>

<!-- ===== Features ===== -->
<section class="lp-features" id="features">
    <div class="lp-section-inner">
        <div class="lp-section-header">
            <div class="lp-section-eyebrow"><?= t('nav_features') ?></div>
            <h2 class="lp-section-title"><?= t('features_title') ?></h2>
            <p class="lp-section-subtitle"><?= t('features_subtitle') ?></p>
        </div>

        <div class="lp-features-grid">
            <div class="lp-feat-card">
                <div class="lp-feat-card__icon lp-feat-card__icon--blue">
                    <i data-lucide="briefcase" width="26" height="26"></i>
                </div>
                <div class="lp-feat-card__num">01</div>
                <h3 class="lp-feat-card__title"><?= t('feat1_title') ?></h3>
                <p class="lp-feat-card__desc"><?= t('feat1_desc') ?></p>
            </div>

            <div class="lp-feat-card">
                <div class="lp-feat-card__icon lp-feat-card__icon--green">
                    <i data-lucide="star" width="26" height="26"></i>
                </div>
                <div class="lp-feat-card__num">02</div>
                <h3 class="lp-feat-card__title"><?= t('feat2_title') ?></h3>
                <p class="lp-feat-card__desc"><?= t('feat2_desc') ?></p>
            </div>

            <div class="lp-feat-card">
                <div class="lp-feat-card__icon lp-feat-card__icon--purple">
                    <i data-lucide="message-square" width="26" height="26"></i>
                </div>
                <div class="lp-feat-card__num">03</div>
                <h3 class="lp-feat-card__title"><?= t('feat3_title') ?></h3>
                <p class="lp-feat-card__desc"><?= t('feat3_desc') ?></p>
            </div>

            <div class="lp-feat-card">
                <div class="lp-feat-card__icon lp-feat-card__icon--orange">
                    <i data-lucide="bar-chart-2" width="26" height="26"></i>
                </div>
                <div class="lp-feat-card__num">04</div>
                <h3 class="lp-feat-card__title"><?= t('feat4_title') ?></h3>
                <p class="lp-feat-card__desc"><?= t('feat4_desc') ?></p>
            </div>
        </div>
    </div>
</section>

<!-- ===== How it works ===== -->
<section class="lp-how" id="how">
    <div class="lp-section-inner">
        <div class="lp-section-header">
            <div class="lp-section-eyebrow"><?= t('nav_how_it_works') ?></div>
            <h2 class="lp-section-title"><?= t('how_title') ?></h2>
            <p class="lp-section-subtitle"><?= t('how_subtitle') ?></p>
        </div>

        <div class="lp-how-steps">
            <div class="lp-how-step">
                <div class="lp-how-step__num">1</div>
                <h3 class="lp-how-step__title"><?= t('step1_title') ?></h3>
                <p class="lp-how-step__desc"><?= t('step1_desc') ?></p>
            </div>
            <div class="lp-how-step">
                <div class="lp-how-step__num">2</div>
                <h3 class="lp-how-step__title"><?= t('step2_title') ?></h3>
                <p class="lp-how-step__desc"><?= t('step2_desc') ?></p>
            </div>
            <div class="lp-how-step">
                <div class="lp-how-step__num">3</div>
                <h3 class="lp-how-step__title"><?= t('step3_title') ?></h3>
                <p class="lp-how-step__desc"><?= t('step3_desc') ?></p>
            </div>
        </div>
    </div>
</section>

<!-- ===== Testimonials ===== -->
<section class="lp-testimonials" id="reviews">
    <div class="lp-section-inner">
        <div class="lp-section-header">
            <div class="lp-section-eyebrow"><?= t('testi_title') ?></div>
            <h2 class="lp-section-title"><?= t('testi_subtitle') ?></h2>
        </div>

        <div class="lp-testi-grid">
            <div class="lp-testi-card">
                <div class="lp-testi-card__stars" style="display:flex;gap:2px"><i data-lucide="star" width="15" height="15" fill="currentColor"></i><i data-lucide="star" width="15" height="15" fill="currentColor"></i><i data-lucide="star" width="15" height="15" fill="currentColor"></i><i data-lucide="star" width="15" height="15" fill="currentColor"></i><i data-lucide="star" width="15" height="15" fill="currentColor"></i></div>
                <p class="lp-testi-card__text"><?= t('testi1_text') ?></p>
                <div class="lp-testi-card__author">
                    <div class="lp-testi-card__avatar lp-testi-card__avatar--a">АП</div>
                    <div>
                        <div class="lp-testi-card__name"><?= t('testi1_name') ?></div>
                        <div class="lp-testi-card__role"><?= t('testi1_role') ?></div>
                    </div>
                </div>
            </div>

            <div class="lp-testi-card">
                <div class="lp-testi-card__stars" style="display:flex;gap:2px"><i data-lucide="star" width="15" height="15" fill="currentColor"></i><i data-lucide="star" width="15" height="15" fill="currentColor"></i><i data-lucide="star" width="15" height="15" fill="currentColor"></i><i data-lucide="star" width="15" height="15" fill="currentColor"></i><i data-lucide="star" width="15" height="15" fill="currentColor"></i></div>
                <p class="lp-testi-card__text"><?= t('testi2_text') ?></p>
                <div class="lp-testi-card__author">
                    <div class="lp-testi-card__avatar lp-testi-card__avatar--b">МЛ</div>
                    <div>
                        <div class="lp-testi-card__name"><?= t('testi2_name') ?></div>
                        <div class="lp-testi-card__role"><?= t('testi2_role') ?></div>
                    </div>
                </div>
            </div>

            <div class="lp-testi-card">
                <div class="lp-testi-card__stars" style="display:flex;gap:2px"><i data-lucide="star" width="15" height="15" fill="currentColor"></i><i data-lucide="star" width="15" height="15" fill="currentColor"></i><i data-lucide="star" width="15" height="15" fill="currentColor"></i><i data-lucide="star" width="15" height="15" fill="currentColor"></i><i data-lucide="star" width="15" height="15" fill="currentColor"></i></div>
                <p class="lp-testi-card__text"><?= t('testi3_text') ?></p>
                <div class="lp-testi-card__author">
                    <div class="lp-testi-card__avatar lp-testi-card__avatar--c">ДС</div>
                    <div>
                        <div class="lp-testi-card__name"><?= t('testi3_name') ?></div>
                        <div class="lp-testi-card__role"><?= t('testi3_role') ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ===== CTA ===== -->
<section class="lp-cta">
    <div class="lp-cta__inner">
        <div class="lp-cta__box">
            <div class="lp-cta__eyebrow"><?= t('cta_eyebrow') ?></div>
            <h2 class="lp-cta__title"><?= t('cta_title') ?></h2>
            <p class="lp-cta__subtitle"><?= t('cta_subtitle') ?></p>
            <div class="lp-cta__actions">
                <a href="<?= BASE_URL ?>/pages/register.php" class="btn-hero-primary">
                    <?= t('create_account') ?>
                    <i data-lucide="arrow-right" width="16" height="16"></i>
                </a>
                <a href="<?= BASE_URL ?>/pages/login.php" class="btn-cta-outline"><?= t('sign_in') ?></a>
            </div>
        </div>
    </div>
</section>

<!-- ===== Footer ===== -->
<footer class="lp-footer">
    <div class="lp-footer__inner">
        <div class="lp-footer__grid">
            <div>
                <a href="<?= BASE_URL ?>/" class="lp-footer__logo-link">
                    <svg viewBox="0 0 105 32" fill="none" height="26">
                        <defs>
                            <linearGradient id="nexio-g-footer" x1="0" y1="0" x2="1" y2="1">
                                <stop offset="0%" stop-color="#60a5fa"/>
                                <stop offset="100%" stop-color="#2563eb"/>
                            </linearGradient>
                        </defs>
                        <path d="M4 27V7L22 27V7" stroke="url(#nexio-g-footer)" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
                        <circle cx="22" cy="2.5" r="3" fill="#3b82f6"/>
                        <text x="32" y="24" font-family="-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif"
                              font-size="21" font-weight="800" fill="currentColor" letter-spacing="-0.3">exio</text>
                    </svg>
                </a>
                <p class="lp-footer__tagline"><?= t('footer_tagline') ?></p>
            </div>

            <div>
                <div class="lp-footer__col-title"><?= t('footer_col_platform') ?></div>
                <div class="lp-footer__links">
                    <a href="<?= BASE_URL ?>/pages/vacancies.php" class="lp-footer__link"><?= t('nav_vacancies') ?></a>
                    <a href="<?= BASE_URL ?>/pages/ratings.php"   class="lp-footer__link"><?= t('nav_ratings') ?></a>
                    <a href="<?= BASE_URL ?>/pages/chat.php"      class="lp-footer__link"><?= t('nav_messages') ?></a>
                    <a href="<?= BASE_URL ?>/pages/dashboard.php" class="lp-footer__link"><?= t('nav_dashboard') ?></a>
                </div>
            </div>

            <div>
                <div class="lp-footer__col-title"><?= t('footer_col_account') ?></div>
                <div class="lp-footer__links">
                    <a href="<?= BASE_URL ?>/pages/login.php"    class="lp-footer__link"><?= t('sign_in') ?></a>
                    <a href="<?= BASE_URL ?>/pages/register.php" class="lp-footer__link"><?= t('create_account') ?></a>
                    <a href="<?= BASE_URL ?>/pages/profile.php"  class="lp-footer__link"><?= t('nav_profile') ?></a>
                </div>
            </div>

            <div>
                <div class="lp-footer__col-title"><?= t('footer_col_info') ?></div>
                <div class="lp-footer__links">
                    <a href="#features" class="lp-footer__link"><?= t('nav_features') ?></a>
                    <a href="#how"      class="lp-footer__link"><?= t('nav_how_it_works') ?></a>
                    <a href="#reviews"  class="lp-footer__link"><?= t('nav_about') ?></a>
                </div>
            </div>
        </div>

        <div class="lp-footer__bottom">
            <div><?= t('footer_copy') ?> &copy; <?= date('Y') ?> <?= SITE_NAME ?></div>
            <div class="lp-footer__badge">v<?= VERSION ?></div>
        </div>
    </div>
</footer>

<script src="<?= BASE_URL ?>/assets/js/lucide.min.js?v=<?= asset_ver('assets/js/lucide.min.js') ?>"></script>
<script src="<?= BASE_URL ?>/assets/js/app.js?v=<?= asset_ver('assets/js/app.js') ?>"></script>
</body>
</html>
