-- ================================================================
-- HireOS — Smart HR Platform
-- Database Schema v1.0
-- ================================================================

CREATE DATABASE IF NOT EXISTS `hr_platform`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `hr_platform`;

-- ----------------------------------------------------------------
-- users
-- ----------------------------------------------------------------
CREATE TABLE `users` (
  `id`         INT UNSIGNED     AUTO_INCREMENT PRIMARY KEY,
  `name`       VARCHAR(100)     NOT NULL,
  `email`      VARCHAR(150)     NOT NULL UNIQUE,
  `password`   VARCHAR(255)     NOT NULL,
  `role`       ENUM('employer','employee','admin') NOT NULL DEFAULT 'employee',
  `company`    VARCHAR(150)     DEFAULT NULL,
  `position`   VARCHAR(100)     DEFAULT NULL,
  `bio`        TEXT             DEFAULT NULL,
  `phone`      VARCHAR(30)      DEFAULT NULL,
  `created_at` TIMESTAMP        DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------
-- vacancies
-- ----------------------------------------------------------------
CREATE TABLE `vacancies` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `employer_id`     INT UNSIGNED NOT NULL,
  `title`           VARCHAR(200) NOT NULL,
  `description`     TEXT         NOT NULL,
  `requirements`    TEXT         DEFAULT NULL,
  `salary_min`      INT          DEFAULT NULL,
  `salary_max`      INT          DEFAULT NULL,
  `location`        VARCHAR(100) DEFAULT NULL,
  `employment_type` ENUM('full-time','part-time','remote','contract') DEFAULT 'full-time',
  `status`          ENUM('active','closed','draft') DEFAULT 'active',
  `created_at`      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_vacancy_employer`
    FOREIGN KEY (`employer_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------
-- applications
-- ----------------------------------------------------------------
CREATE TABLE `applications` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `vacancy_id`   INT UNSIGNED NOT NULL,
  `employee_id`  INT UNSIGNED NOT NULL,
  `cover_letter` TEXT         DEFAULT NULL,
  `status`       ENUM('pending','reviewed','accepted','rejected') DEFAULT 'pending',
  `applied_at`   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_application` (`vacancy_id`,`employee_id`),
  CONSTRAINT `fk_app_vacancy`
    FOREIGN KEY (`vacancy_id`)  REFERENCES `vacancies`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_app_employee`
    FOREIGN KEY (`employee_id`) REFERENCES `users`(`id`)    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------
-- ratings
-- ----------------------------------------------------------------
CREATE TABLE `ratings` (
  `id`          INT UNSIGNED  AUTO_INCREMENT PRIMARY KEY,
  `employer_id` INT UNSIGNED  NOT NULL,
  `employee_id` INT UNSIGNED  NOT NULL,
  `score`       TINYINT UNSIGNED NOT NULL COMMENT '1-5',
  `category`    VARCHAR(80)   DEFAULT NULL,
  `comment`     TEXT          DEFAULT NULL,
  `created_at`  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `chk_score` CHECK (`score` BETWEEN 1 AND 5),
  CONSTRAINT `fk_rating_employer`
    FOREIGN KEY (`employer_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rating_employee`
    FOREIGN KEY (`employee_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------
-- messages
-- ----------------------------------------------------------------
CREATE TABLE `messages` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `sender_id`   INT UNSIGNED NOT NULL,
  `receiver_id` INT UNSIGNED NOT NULL,
  `content`     TEXT         NOT NULL,
  `is_read`     TINYINT(1)   UNSIGNED DEFAULT 0,
  `sent_at`     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_msg_sender`
    FOREIGN KEY (`sender_id`)   REFERENCES `users`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_msg_receiver`
    FOREIGN KEY (`receiver_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ================================================================
-- Demo data  |  password = "password" for all accounts
-- ================================================================
INSERT INTO `users` (`name`,`email`,`password`,`role`,`company`,`position`,`bio`,`phone`) VALUES
('Administrator',  'admin@nexio.app', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'admin', NULL, 'Platform Admin', 'Super administrator account.', NULL),
('TechCorp HR',   'employer@demo.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'employer','TechCorp Ltd',  'HR Director',        'Leading IT company focused on cloud solutions.','+7 495 000-01-01'),
('Anna Johnson',   'anna@demo.com',    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'employer','StartUp Inc',   'Talent Acquisition', 'Growing startup in fintech.','+7 495 000-01-02'),
('Ivan Petrov',    'ivan@demo.com',    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'employee', NULL,           'PHP Developer',      '3 years backend PHP/MySQL. Open to remote.','+7 916 111-22-33'),
('Maria Sidorova', 'maria@demo.com',   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'employee', NULL,           'UX Designer',        'Figma expert, 4 years product design.','+7 916 444-55-66');

INSERT INTO `vacancies` (`employer_id`,`title`,`description`,`requirements`,`salary_min`,`salary_max`,`location`,`employment_type`,`status`) VALUES
(1,'Senior PHP Developer',
 'We are looking for an experienced PHP developer to build scalable backend services for our SaaS platform. You will work closely with the architecture team.',
 'PHP 8.1+, MySQL, REST API, Git, Docker basics. 3+ years experience.',
 120000,180000,'Moscow / Remote','remote','active'),
(1,'DevOps Engineer',
 'Maintain and scale our CI/CD pipelines, manage cloud infrastructure on AWS, ensure high availability of production systems.',
 'Docker, Kubernetes, AWS or GCP, Terraform, 2+ years DevOps.',
 140000,200000,'Moscow','full-time','active'),
(2,'UX/UI Designer',
 'Design beautiful, data-driven interfaces for our fintech products. Collaborate with product and engineering.',
 'Figma, Adobe XD, design systems, 2+ years.',
 90000,130000,'Remote','remote','active'),
(2,'Frontend Developer',
 'Build responsive, performant web interfaces. Work on our main product dashboard.',
 'HTML5, CSS3, JavaScript ES6+, React, 2+ years.',
 100000,150000,'Saint Petersburg','full-time','active'),
(1,'QA Engineer',
 'Write and maintain test cases, automate regression testing, work with dev teams to ensure quality.',
 'Manual + automation testing, Selenium or Cypress, SQL basics.',
 80000,110000,'Remote','remote','active');

INSERT INTO `applications` (`vacancy_id`,`employee_id`,`cover_letter`,`status`) VALUES
(1,3,'I have 3 years of PHP/MySQL experience and have built several REST APIs. Looking forward to discussing this role.','reviewed'),
(3,4,'I am a passionate UX designer with 4 years of experience. My portfolio includes several fintech projects.','pending'),
(4,3,'I also have solid frontend skills and can contribute to both backend and frontend tasks.','pending');

INSERT INTO `ratings` (`employer_id`,`employee_id`,`score`,`category`,`comment`) VALUES
(1,3,5,'Technical Skills','Excellent PHP developer. Clean code, great attention to detail.'),
(1,3,4,'Communication','Communicates well but could improve written documentation.'),
(1,3,5,'Reliability','Always delivers on time. Very dependable team member.'),
(2,4,5,'Design Quality','Outstanding UI work. The redesign improved user retention by 20%.'),
(2,4,4,'Collaboration','Works well in a team. Proactively shares ideas.');

INSERT INTO `messages` (`sender_id`,`receiver_id`,`content`) VALUES
(1,3,'Hello Ivan! We reviewed your application and would like to schedule a technical interview.'),
(3,1,'Thank you! I am available Mon-Fri this week. When works best for you?'),
(1,3,'How about Thursday at 14:00 Moscow time? We will use Google Meet.'),
(3,1,'Thursday at 14:00 works perfectly. Please send the meeting link.'),
(1,3,'Link sent to your email. Please prepare a short code review exercise.'),
(2,4,'Hi Maria! We loved your portfolio. Would you like to discuss the UX Designer role?'),
(4,2,'Of course! I am very interested in the position. Happy to schedule a call.'),
(2,4,'Great! Are you free tomorrow at 11:00?');
