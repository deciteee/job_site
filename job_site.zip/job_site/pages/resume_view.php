<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

$viewId = (int)($_GET['id'] ?? 0);
if (!$viewId) { header('Location: ' . BASE_URL . '/pages/dashboard.php'); exit; }

// Allow only: the owner, employers, admins
$myId   = (int)$_SESSION['user_id'];
$myRole = $_SESSION['user_role'];
if ($myId !== $viewId && $myRole !== 'employer' && !isAdmin()) {
    header('Location: ' . BASE_URL . '/pages/dashboard.php'); exit;
}

// Fetch user
$u = $conn->prepare("SELECT id, name, email, position, phone, bio, company, avatar, role, created_at FROM users WHERE id=? AND role='employee'");
$u->bind_param('i', $viewId); $u->execute();
$user = $u->get_result()->fetch_assoc(); $u->close();
if (!$user) { header('Location: ' . BASE_URL . '/pages/dashboard.php'); exit; }

// Resume
$resume = $conn->query("SELECT * FROM resumes WHERE user_id=$viewId")->fetch_assoc();
$exps   = $conn->query("SELECT * FROM resume_experiences WHERE user_id=$viewId ORDER BY sort_order, id DESC")->fetch_all(MYSQLI_ASSOC);
$edus   = $conn->query("SELECT * FROM resume_educations WHERE user_id=$viewId ORDER BY sort_order, id DESC")->fetch_all(MYSQLI_ASSOC);
$files  = $conn->query("SELECT * FROM resume_files WHERE user_id=$viewId ORDER BY uploaded_at DESC")->fetch_all(MYSQLI_ASSOC);

$skillsList = $resume ? array_filter(array_map('trim', explode(',', $resume['skills'] ?? ''))) : [];

// Average rating
$avgRating = $conn->query("SELECT IFNULL(ROUND(AVG(score)*2,1),0) FROM ratings WHERE employee_id=$viewId")->fetch_row()[0];
$ratingCnt = (int)$conn->query("SELECT COUNT(*) FROM ratings WHERE employee_id=$viewId")->fetch_row()[0];

// Check if employer already chatted
$hasChat = false;
if ($myRole === 'employer') {
    $r = $conn->prepare("SELECT id FROM messages WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?) LIMIT 1");
    $r->bind_param('iiii', $myId, $viewId, $viewId, $myId); $r->execute();
    $hasChat = (bool)$r->get_result()->fetch_assoc(); $r->close();
}

$pageTitle = htmlspecialchars($user['name']) . ' — ' . t('nav_resume');
include __DIR__ . '/../includes/header.php';
?>

<style>
/* ── Back link ─────────────────────────────────────────── */
.rv-back { display:inline-flex;align-items:center;gap:6px;font-size:13.5px;color:var(--text-muted);text-decoration:none;margin-bottom:20px;transition:color .15s; }
.rv-back:hover { color:var(--primary);text-decoration:none; }

/* ── Layout ────────────────────────────────────────────── */
.rv-layout { display:grid; grid-template-columns: 1fr 300px; gap:24px; align-items:start; }
@media (max-width:860px) { .rv-layout { grid-template-columns:1fr; } }

/* ── Hero ──────────────────────────────────────────────── */
.rv-hero {
    background: linear-gradient(135deg,#0f172a 0%,#1e3a5f 60%,#1d4ed8 100%);
    border-radius: 22px; padding: 32px 30px; margin-bottom: 22px;
    position: relative; overflow: hidden;
}
.rv-hero::before {
    content:''; position:absolute; top:-60px; right:-60px;
    width:260px; height:260px; border-radius:50%;
    background:rgba(59,130,246,.12); pointer-events:none;
}
.rv-hero::after {
    content:''; position:absolute; bottom:-40px; left:40px;
    width:160px; height:160px; border-radius:50%;
    background:rgba(99,102,241,.10); pointer-events:none;
}
.rv-hero__inner { display:flex;align-items:center;gap:22px;position:relative;z-index:1; }
.rv-hero__ava {
    width:80px; height:80px; border-radius:20px; flex-shrink:0;
    background:linear-gradient(135deg,#3b82f6,#6366f1);
    display:flex;align-items:center;justify-content:center;
    font-size:26px;font-weight:800;color:#fff;overflow:hidden;
    border:3px solid rgba(255,255,255,.2); box-shadow:0 6px 20px rgba(0,0,0,.4);
}
.rv-hero__ava img { width:100%;height:100%;object-fit:cover; }
.rv-hero__name { font-size:24px;font-weight:800;color:#fff;margin-bottom:4px;line-height:1.2; }
.rv-hero__pos  { font-size:14px;color:#93c5fd;margin-bottom:14px; }
.rv-hero__chips { display:flex;flex-wrap:wrap;gap:10px; }
.rv-hero__chip {
    display:inline-flex;align-items:center;gap:5px;
    font-size:12px;color:#cbd5e1;background:rgba(255,255,255,.08);
    border:1px solid rgba(255,255,255,.12);border-radius:100px;padding:4px 12px;
}
.rv-hero__rating {
    position:absolute;top:20px;right:22px;z-index:1;
    background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.15);
    border-radius:12px;padding:8px 14px;text-align:center;
}
.rv-hero__rating-val { font-size:22px;font-weight:800;color:#fbbf24; }
.rv-hero__rating-sub { font-size:11px;color:#94a3b8;margin-top:1px; }

/* ── Section ───────────────────────────────────────────── */
.rv-section {
    background:var(--card-bg);border:1.5px solid var(--border);
    border-radius:20px;margin-bottom:18px;overflow:hidden;
}
.rv-section__head {
    display:flex;align-items:center;gap:10px;
    padding:16px 22px;border-bottom:1px solid var(--border-light);
}
.rv-section__icon { width:32px;height:32px;border-radius:9px;display:flex;align-items:center;justify-content:center;flex-shrink:0; }
.rv-section__title { font-size:14.5px;font-weight:700;color:var(--text-primary); }
.rv-section__body { padding:20px 22px; }

/* ── Skills ────────────────────────────────────────────── */
.rv-skills { display:flex;flex-wrap:wrap;gap:8px; }
.rv-skill {
    display:inline-flex;align-items:center;padding:6px 14px;
    border-radius:100px;font-size:13px;font-weight:500;
    background:rgba(37,99,235,.09);color:#2563eb;
    border:1.5px solid rgba(37,99,235,.2);
}

/* ── Timeline ──────────────────────────────────────────── */
.rv-timeline { display:flex;flex-direction:column;gap:0; }
.rv-timeline-item { display:flex;gap:16px;position:relative;padding-bottom:22px; }
.rv-timeline-item:last-child { padding-bottom:0; }
.rv-timeline-item:not(:last-child)::before {
    content:''; position:absolute; left:15px; top:34px; bottom:0;
    width:2px; background:var(--border-light);
}
.rv-tl-dot {
    width:32px;height:32px;border-radius:10px;flex-shrink:0;
    display:flex;align-items:center;justify-content:center;
    position:relative;z-index:1;
}
.rv-tl-title { font-size:14.5px;font-weight:700;color:var(--text-primary);margin-bottom:2px; }
.rv-tl-sub   { font-size:13px;color:var(--text-secondary);margin-bottom:6px; }
.rv-tl-dates { display:inline-flex;align-items:center;gap:5px;font-size:11.5px;color:var(--text-muted);background:var(--border-light);border-radius:100px;padding:3px 10px; }
.rv-tl-desc  { font-size:13px;color:var(--text-secondary);line-height:1.6;margin-top:8px; }

/* ── Files ─────────────────────────────────────────────── */
.rv-files { display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px; }
.rv-file {
    display:flex;align-items:center;gap:12px;
    background:var(--body-bg);border:1.5px solid var(--border);
    border-radius:14px;padding:14px;text-decoration:none;
    transition:border-color .15s,box-shadow .15s;
}
.rv-file:hover { border-color:var(--primary);box-shadow:0 4px 14px rgba(37,99,235,.12);text-decoration:none; }
.rv-file__icon { font-size:24px;flex-shrink:0; }
.rv-file__name { font-size:13px;font-weight:600;color:var(--text-primary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap; }
.rv-file__type { font-size:11.5px;color:var(--text-muted);margin-top:2px; }

/* ── Sidebar card ──────────────────────────────────────── */
.rv-sidebar-card {
    background:var(--card-bg);border:1.5px solid var(--border);
    border-radius:20px;overflow:hidden;margin-bottom:18px;
}
.rv-sidebar-card__head { padding:16px 18px;border-bottom:1px solid var(--border-light); font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--text-muted); }
.rv-sidebar-card__body { padding:16px 18px; }
.rv-sidebar-stat { display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border-light); }
.rv-sidebar-stat:last-child { border-bottom:none; }
.rv-sidebar-stat__label { font-size:13px;color:var(--text-secondary); }
.rv-sidebar-stat__val   { font-size:14px;font-weight:700;color:var(--text-primary); }
</style>

<a href="javascript:history.back()" class="rv-back">
    <i data-lucide="arrow-left" width="14" height="14"></i>
    <?= t('btn_back') ?>
</a>

<!-- Hero -->
<div class="rv-hero">
    <?php if ($avgRating > 0): ?>
    <div class="rv-hero__rating">
        <div class="rv-hero__rating-val" style="display:inline-flex;align-items:center;gap:5px"><i data-lucide="star" width="18" height="18" fill="currentColor"></i><?= $avgRating ?></div>
        <div class="rv-hero__rating-sub"><?= $ratingCnt ?> <?= t('rating_reviews') ?></div>
    </div>
    <?php endif; ?>
    <div class="rv-hero__inner">
        <div class="rv-hero__ava">
            <?php if (!empty($user['avatar'])): ?>
                <img src="<?= BASE_URL ?>/assets/uploads/avatars/<?= htmlspecialchars($user['avatar']) ?>" alt="">
            <?php else: ?>
                <?= mb_strtoupper(mb_substr($user['name'], 0, 1)) ?>
            <?php endif; ?>
        </div>
        <div>
            <div class="rv-hero__name"><?= htmlspecialchars($user['name']) ?></div>
            <div class="rv-hero__pos"><?= htmlspecialchars($user['position'] ?? t('no_position_set')) ?></div>
            <div class="rv-hero__chips">
                <?php if ($user['email']): ?>
                <span class="rv-hero__chip">
                    <i data-lucide="mail" width="11" height="11"></i>
                    <?= htmlspecialchars($user['email']) ?>
                </span>
                <?php endif; ?>
                <?php if ($user['phone']): ?>
                <span class="rv-hero__chip">
                    <i data-lucide="phone" width="11" height="11"></i>
                    <?= htmlspecialchars($user['phone']) ?>
                </span>
                <?php endif; ?>
                <span class="rv-hero__chip">
                    <i data-lucide="calendar" width="11" height="11"></i>
                    <?= t('member_since') ?> <?= date('M Y', strtotime($user['created_at'])) ?>
                </span>
            </div>
        </div>
    </div>
</div>

<div class="rv-layout">

<!-- Left -->
<div>

<?php if (!empty($resume['about'])): ?>
<div class="rv-section">
    <div class="rv-section__head">
        <div class="rv-section__icon" style="background:rgba(37,99,235,.1)">
            <i data-lucide="user" width="16" height="16" style="color:#2563eb"></i>
        </div>
        <div class="rv-section__title"><?= t('section_about') ?></div>
    </div>
    <div class="rv-section__body">
        <p style="font-size:14px;color:var(--text-secondary);line-height:1.7;margin:0"><?= nl2br(htmlspecialchars($resume['about'])) ?></p>
    </div>
</div>
<?php endif; ?>

<?php if (!empty($skillsList)): ?>
<div class="rv-section">
    <div class="rv-section__head">
        <div class="rv-section__icon" style="background:rgba(16,185,129,.1)">
            <i data-lucide="activity" width="16" height="16" style="color:#10b981"></i>
        </div>
        <div class="rv-section__title"><?= t('section_skills') ?></div>
    </div>
    <div class="rv-section__body">
        <div class="rv-skills">
            <?php foreach ($skillsList as $sk): ?>
            <span class="rv-skill"><?= htmlspecialchars($sk) ?></span>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if (!empty($exps)): ?>
<div class="rv-section">
    <div class="rv-section__head">
        <div class="rv-section__icon" style="background:rgba(139,92,246,.1)">
            <i data-lucide="briefcase" width="16" height="16" style="color:#8b5cf6"></i>
        </div>
        <div class="rv-section__title"><?= t('section_experience') ?></div>
    </div>
    <div class="rv-section__body">
        <div class="rv-timeline">
        <?php foreach ($exps as $ex): ?>
        <div class="rv-timeline-item">
            <div class="rv-tl-dot" style="background:rgba(139,92,246,.1)">
                <i data-lucide="briefcase" width="16" height="16" style="color:#8b5cf6"></i>
            </div>
            <div style="flex:1;min-width:0">
                <div class="rv-tl-title"><?= htmlspecialchars($ex['position']) ?></div>
                <div class="rv-tl-sub"><?= htmlspecialchars($ex['company']) ?></div>
                <?php if ($ex['date_from']): ?>
                <span class="rv-tl-dates">
                    <i data-lucide="clock" width="10" height="10"></i>
                    <?= htmlspecialchars($ex['date_from']) ?> — <?= $ex['is_current'] ? t('present') : htmlspecialchars($ex['date_to'] ?? '') ?>
                </span>
                <?php endif; ?>
                <?php if ($ex['description']): ?>
                <div class="rv-tl-desc"><?= nl2br(htmlspecialchars($ex['description'])) ?></div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if (!empty($edus)): ?>
<div class="rv-section">
    <div class="rv-section__head">
        <div class="rv-section__icon" style="background:rgba(245,158,11,.1)">
            <i data-lucide="graduation-cap" width="16" height="16" style="color:#f59e0b"></i>
        </div>
        <div class="rv-section__title"><?= t('section_education') ?></div>
    </div>
    <div class="rv-section__body">
        <div class="rv-timeline">
        <?php foreach ($edus as $ed): ?>
        <div class="rv-timeline-item">
            <div class="rv-tl-dot" style="background:rgba(245,158,11,.1)">
                <i data-lucide="graduation-cap" width="16" height="16" style="color:#f59e0b"></i>
            </div>
            <div style="flex:1">
                <div class="rv-tl-title"><?= htmlspecialchars($ed['degree'] ?? $ed['institution']) ?></div>
                <div class="rv-tl-sub"><?= htmlspecialchars($ed['institution']) ?></div>
                <?php if ($ed['year_from']): ?>
                <span class="rv-tl-dates"><?= $ed['year_from'] ?><?= $ed['year_to'] ? ' — '.$ed['year_to'] : '' ?></span>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if (!empty($files)): ?>
<div class="rv-section">
    <div class="rv-section__head">
        <div class="rv-section__icon" style="background:rgba(239,68,68,.1)">
            <i data-lucide="file-text" width="16" height="16" style="color:#ef4444"></i>
        </div>
        <div class="rv-section__title"><?= t('section_documents') ?></div>
    </div>
    <div class="rv-section__body">
        <div class="rv-files">
        <?php foreach ($files as $f):
            $iconName = $f['file_type'] === 'diploma' ? 'graduation-cap' : ($f['file_type'] === 'certificate' ? 'scroll' : 'file-text');
            $typeLabel = ['diploma' => t('file_type_diploma'), 'certificate' => t('file_type_certificate'), 'other' => t('file_type_other')][$f['file_type']];
        ?>
        <a class="rv-file" href="<?= BASE_URL ?>/assets/uploads/resume/<?= htmlspecialchars($f['filename']) ?>" target="_blank">
            <div class="rv-file__icon" style="color:var(--primary)"><i data-lucide="<?= $iconName ?>" width="24" height="24"></i></div>
            <div style="min-width:0">
                <div class="rv-file__name"><?= htmlspecialchars($f['original_name']) ?></div>
                <div class="rv-file__type"><?= $typeLabel ?> · <?= t('btn_open') ?></div>
            </div>
        </a>
        <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if (empty($resume['about']) && empty($skillsList) && empty($exps) && empty($edus) && empty($files)): ?>
<div style="background:var(--card-bg);border:1.5px dashed var(--border);border-radius:20px;padding:52px 24px;text-align:center">
    <div style="margin-bottom:12px;color:var(--text-muted)"><i data-lucide="file-text" width="40" height="40" stroke-width="1.5"></i></div>
    <div style="font-size:16px;font-weight:600;color:var(--text-primary);margin-bottom:6px"><?= t('resume_empty_title') ?></div>
    <div style="font-size:13px;color:var(--text-muted)"><?= t('resume_empty_sub') ?></div>
</div>
<?php endif; ?>

</div><!-- end left -->

<!-- Right sidebar -->
<div>

<?php if ($myRole === 'employer' && $myId !== $viewId): ?>
<div class="rv-sidebar-card">
    <div class="rv-sidebar-card__head"><?= t('sidebar_actions') ?></div>
    <div class="rv-sidebar-card__body" style="display:flex;flex-direction:column;gap:10px">
        <a href="<?= BASE_URL ?>/pages/chat.php?with=<?= $viewId ?>"
           class="btn btn-primary" style="width:100%;justify-content:center;gap:8px">
            <i data-lucide="message-square" width="14" height="14"></i>
            <?= t('btn_message') ?>
        </a>
        <a href="<?= BASE_URL ?>/pages/ratings.php?rate=<?= $viewId ?>"
           class="btn btn-outline" style="width:100%;justify-content:center;gap:8px">
            <i data-lucide="star" width="14" height="14"></i>
            <?= t('submit_rating') ?>
        </a>
    </div>
</div>
<?php endif; ?>

<div class="rv-sidebar-card">
    <div class="rv-sidebar-card__head"><?= t('sidebar_info') ?></div>
    <div class="rv-sidebar-card__body">
        <div class="rv-sidebar-stat">
            <span class="rv-sidebar-stat__label"><?= t('field_position') ?></span>
            <span class="rv-sidebar-stat__val"><?= htmlspecialchars($user['position'] ?? '—') ?></span>
        </div>
        <?php if ($avgRating > 0): ?>
        <div class="rv-sidebar-stat">
            <span class="rv-sidebar-stat__label"><?= t('stat_rating') ?></span>
            <span class="rv-sidebar-stat__val" style="color:#f59e0b;display:inline-flex;align-items:center;gap:4px"><i data-lucide="star" width="13" height="13" fill="currentColor"></i><?= $avgRating ?>/10</span>
        </div>
        <?php endif; ?>
        <div class="rv-sidebar-stat">
            <span class="rv-sidebar-stat__label"><?= t('section_skills') ?></span>
            <span class="rv-sidebar-stat__val"><?= count($skillsList) ?></span>
        </div>
        <div class="rv-sidebar-stat">
            <span class="rv-sidebar-stat__label"><?= t('emp_work_places') ?></span>
            <span class="rv-sidebar-stat__val"><?= count($exps) ?></span>
        </div>
        <div class="rv-sidebar-stat">
            <span class="rv-sidebar-stat__label"><?= t('emp_documents') ?></span>
            <span class="rv-sidebar-stat__val"><?= count($files) ?></span>
        </div>
    </div>
</div>

<?php if ($myId === $viewId): ?>
<a href="<?= BASE_URL ?>/pages/resume.php"
   class="btn btn-primary" style="width:100%;justify-content:center;gap:8px">
    <i data-lucide="square-pen" width="14" height="14"></i>
    <?= t('edit_resume_btn') ?>
</a>
<?php endif; ?>

</div><!-- end sidebar -->

</div><!-- rv-layout -->

<?php include __DIR__ . '/../includes/footer.php'; ?>
