<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

$uid  = $_SESSION['user_id'];
$role = $_SESSION['user_role'];

// Pre-selected conversation partner from URL
$withId = isset($_GET['with']) ? (int)$_GET['with'] : 0;

// ── Send message ─────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $toId    = (int)($_POST['to_id']  ?? 0);
    $content = trim($_POST['content'] ?? '');

    if ($toId && $content && $toId !== $uid) {
        $stmt = $conn->prepare(
            "INSERT INTO messages (sender_id, receiver_id, content) VALUES (?,?,?)"
        );
        $stmt->bind_param('iis', $uid, $toId, $content);
        $stmt->execute(); $stmt->close();

        header('Location: ' . BASE_URL . '/pages/chat.php?with=' . $toId . '#bottom');
        exit;
    }
}

// ── Load conversation partners (anyone who messaged me or I messaged) ─
$stmt = $conn->prepare("
    SELECT DISTINCT u.id, u.name, u.role, u.company, u.position,
        (SELECT COUNT(*) FROM messages m2
         WHERE m2.sender_id=u.id AND m2.receiver_id=? AND m2.is_read=0) AS unread,
        (SELECT m3.sent_at FROM messages m3
         WHERE (m3.sender_id=u.id AND m3.receiver_id=?) OR (m3.sender_id=? AND m3.receiver_id=u.id)
         ORDER BY m3.sent_at DESC LIMIT 1) AS last_msg_at
    FROM messages m
    JOIN users u ON (m.sender_id=u.id OR m.receiver_id=u.id)
    WHERE (m.sender_id=? OR m.receiver_id=?) AND u.id != ?
    GROUP BY u.id
    ORDER BY last_msg_at DESC
");
$stmt->bind_param('iiiiii', $uid, $uid, $uid, $uid, $uid, $uid);
$stmt->execute();
$contacts = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Also load all users to start new conversation
$stmt = $conn->prepare("SELECT id, name, role, company, position FROM users WHERE id != ? ORDER BY name");
$stmt->bind_param('i', $uid); $stmt->execute();
$allUsers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();

// ── Load messages for selected contact ────────────────────────
$activeContact = null;
$messages = [];

if ($withId) {
    $stmt = $conn->prepare("SELECT id, name, role, company, position FROM users WHERE id=?");
    $stmt->bind_param('i', $withId); $stmt->execute();
    $activeContact = $stmt->get_result()->fetch_assoc(); $stmt->close();

    if ($activeContact) {
        // Load messages
        $stmt = $conn->prepare("
            SELECT id, sender_id, receiver_id, content, is_read, sent_at
            FROM messages
            WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)
            ORDER BY sent_at ASC
        ");
        $stmt->bind_param('iiii', $uid, $withId, $withId, $uid);
        $stmt->execute();
        $messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();

        // Mark messages from them as read
        $stmt = $conn->prepare("UPDATE messages SET is_read=1 WHERE sender_id=? AND receiver_id=? AND is_read=0");
        $stmt->bind_param('ii', $withId, $uid); $stmt->execute(); $stmt->close();
    }
}

$pageTitle = 'Messages';
include __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <div>
        <h2 class="page-title">Messages</h2>
        <p class="page-subtitle">Direct communication with employers and candidates.</p>
    </div>

    <!-- New conversation trigger -->
    <div style="position:relative">
        <button class="btn btn-primary" onclick="document.getElementById('newChatPanel').classList.toggle('hidden')">
            + New Message
        </button>
        <div class="dropdown-panel hidden" id="newChatPanel">
            <div class="dropdown-panel__header">Start conversation with</div>
            <?php foreach ($allUsers as $u): ?>
                <a href="<?= BASE_URL ?>/pages/chat.php?with=<?= $u['id'] ?>"
                   class="dropdown-panel__item">
                    <div class="contact-avatar"><?= getUserInitials($u['name']) ?></div>
                    <div>
                        <div class="contact-name"><?= htmlspecialchars($u['name']) ?></div>
                        <div class="contact-meta text-muted small"><?= ucfirst($u['role']) ?><?= $u['position'] ? ' · ' . htmlspecialchars($u['position']) : '' ?></div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<div class="chat-layout">
    <!-- ── Contact list ── -->
    <div class="chat-contacts">
        <?php if (empty($contacts)): ?>
            <div class="empty-state">No conversations yet.</div>
        <?php else: ?>
            <?php foreach ($contacts as $c): ?>
            <a href="<?= BASE_URL ?>/pages/chat.php?with=<?= $c['id'] ?>"
               class="contact-item <?= $withId === $c['id'] ? 'contact-item--active' : '' ?>">
                <div class="contact-avatar"><?= getUserInitials($c['name']) ?></div>
                <div class="contact-info">
                    <div class="contact-name"><?= htmlspecialchars($c['name']) ?></div>
                    <div class="contact-sub text-muted small">
                        <?= ucfirst($c['role']) ?>
                        <?= $c['company'] ? ' · ' . htmlspecialchars($c['company']) : '' ?>
                    </div>
                </div>
                <?php if ($c['unread'] > 0): ?>
                    <span class="badge-count"><?= $c['unread'] ?></span>
                <?php endif; ?>
                <?php if ($c['last_msg_at']): ?>
                    <div class="contact-time"><?= date('d M', strtotime($c['last_msg_at'])) ?></div>
                <?php endif; ?>
            </a>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- ── Message thread ── -->
    <div class="chat-thread">
        <?php if (!$activeContact): ?>
            <div class="chat-empty">
                <i data-lucide="message-square" width="48" height="48" style="color:#cbd5e1"></i>
                <p>Select a conversation or start a new one</p>
            </div>
        <?php else: ?>
            <!-- Thread header -->
            <div class="chat-thread__header">
                <div class="contact-avatar"><?= getUserInitials($activeContact['name']) ?></div>
                <div>
                    <div class="chat-thread__name"><?= htmlspecialchars($activeContact['name']) ?></div>
                    <div class="chat-thread__sub text-muted small">
                        <?= ucfirst($activeContact['role']) ?>
                        <?= $activeContact['position'] ? ' · ' . htmlspecialchars($activeContact['position']) : '' ?>
                        <?= $activeContact['company'] ? ' @ ' . htmlspecialchars($activeContact['company']) : '' ?>
                    </div>
                </div>
            </div>

            <!-- Messages -->
            <div class="chat-messages" id="chatMessages">
                <?php if (empty($messages)): ?>
                    <div class="chat-empty-thread">
                        No messages yet. Say hello!
                    </div>
                <?php else: ?>
                    <?php
                    $prevDate = '';
                    foreach ($messages as $msg):
                        $isMine  = $msg['sender_id'] == $uid;
                        $msgDate = date('d F Y', strtotime($msg['sent_at']));
                    ?>
                    <?php if ($msgDate !== $prevDate): $prevDate = $msgDate; ?>
                        <div class="chat-date-divider"><?= $msgDate ?></div>
                    <?php endif; ?>
                    <div class="chat-bubble <?= $isMine ? 'chat-bubble--mine' : 'chat-bubble--theirs' ?>">
                        <div class="chat-bubble__text"><?= nl2br(htmlspecialchars($msg['content'])) ?></div>
                        <div class="chat-bubble__time">
                            <?= date('H:i', strtotime($msg['sent_at'])) ?>
                            <?php if ($isMine): ?>
                                <span class="read-tick <?= $msg['is_read'] ? 'read-tick--read' : '' ?>">&#10003;&#10003;</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                <div id="bottom"></div>
            </div>

            <!-- Input -->
            <div class="chat-input-area">
                <form method="POST" class="chat-form">
                    <input type="hidden" name="to_id" value="<?= $withId ?>">
                    <textarea class="chat-textarea" name="content" id="chatInput"
                              placeholder="Type your message..." rows="1" required></textarea>
                    <button type="submit" class="btn btn-primary chat-send-btn">
                        <i data-lucide="send" width="18" height="18"></i>
                        Send
                    </button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
