<?php
session_start();
session_destroy();
require_once __DIR__ . '/../config.php';
header('Location: ' . BASE_URL . '/pages/login.php');
exit;
