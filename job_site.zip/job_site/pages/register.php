<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/i18n.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/pages/dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name']     ?? '');
    $email    = trim($_POST['email']    ?? '');
    $password = trim($_POST['password'] ?? '');
    $role     = $_POST['role'] ?? 'employee';
    $company  = trim($_POST['company']  ?? '');
    $position = trim($_POST['position'] ?? '');

    if (!$name || !$email || !$password || !$role) {
        $error = t('err_fill_all');
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = t('err_invalid_email');
    } elseif (strlen($password) < 6) {
        $error = t('err_short_password');
    } elseif (!in_array($role, ['employer', 'employee'])) {
        $error = t('err_invalid_role');
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();
        $exists = $stmt->num_rows > 0;
        $stmt->close();

        if ($exists) {
            $error = t('err_email_exists');
        } else {
            $hash  = password_hash($password, PASSWORD_BCRYPT);
            $token = bin2hex(random_bytes(32));
            $stmt  = $conn->prepare(
                "INSERT INTO users (name, email, password, role, company, position, status, verify_token) VALUES (?,?,?,?,?,?,'pending',?)"
            );
            $stmt->bind_param('sssssss', $name, $email, $hash, $role, $company, $position, $token);

            if ($stmt->execute()) {
                $newUserId = $stmt->insert_id;
                $stmt->close();
                require_once __DIR__ . '/../includes/mailer.php';
                $sent = sendVerificationEmail($email, $name, $token);
                if ($sent) {
                    header('Location: ' . BASE_URL . '/pages/login.php?registered=1&email=' . urlencode($email));
                    exit;
                } else {
                    // Rollback user so they can re-register once SMTP is configured
                    $conn->query("DELETE FROM users WHERE id=$newUserId");
                    $error = 'Не удалось отправить письмо подтверждения. Проверьте настройки SMTP (MAIL_PASS в mailer.php).';
                }
            } else {
                $error = t('err_register_fail');
                $stmt->close();
            }
        }
    }
}

$langBase   = '?setlang=';
$currentParams = array_diff_key($_GET, ['setlang' => '']);
$paramStr   = $currentParams ? '&' . http_build_query($currentParams) : '';
$selectedRole = $_POST['role'] ?? 'employee';
?>
<!DOCTYPE html>
<html lang="<?= currentLang() === 'kz' ? 'kk' : 'ru' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= t('register_title') ?> — <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <script>(function(){var t=localStorage.getItem('nexio-theme')||'light';document.documentElement.setAttribute('data-theme',t);})()</script>
</head>
<body class="auth-body">

<div class="auth-layout">

    <!-- Lang + Theme controls -->
    <div class="auth-controls">
        <div class="lang-dropdown" id="langDropdownReg">
            <button class="lang-dropdown__trigger" type="button"
                    onclick="document.getElementById('langDropdownReg').classList.toggle('open')">
                <i data-lucide="globe" width="13" height="13"></i>
                <?= strtoupper(currentLang()) ?>
                <i data-lucide="chevron-down" width="10" height="10"></i>
            </button>
            <div class="lang-dropdown__menu">
                <a href="<?= $langBase ?>ru<?= $paramStr ?>" class="lang-dropdown__item <?= currentLang()==='ru'?'active':'' ?>">Русский</a>
                <a href="<?= $langBase ?>kz<?= $paramStr ?>" class="lang-dropdown__item <?= currentLang()==='kz'?'active':'' ?>">Қазақша</a>
                <a href="<?= $langBase ?>en<?= $paramStr ?>" class="lang-dropdown__item <?= currentLang()==='en'?'active':'' ?>">English</a>
            </div>
        </div>
        <button class="theme-btn" data-action="theme" title="Toggle theme">
            <i data-lucide="moon" width="14" height="14"></i>
        </button>
    </div>

    <!-- Form panel -->
    <div class="auth-panel auth-panel--wide">
        <div class="auth-brand">
            <a href="<?= BASE_URL ?>/" style="display:flex;align-items:center;text-decoration:none;color:inherit;">
                <svg viewBox="0 0 105 32" fill="none" height="28">
                    <defs>
                        <linearGradient id="nexio-g-reg" x1="0" y1="0" x2="1" y2="1">
                            <stop offset="0%" stop-color="#60a5fa"/>
                            <stop offset="100%" stop-color="#2563eb"/>
                        </linearGradient>
                    </defs>
                    <path d="M4 27V7L22 27V7" stroke="url(#nexio-g-reg)" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
                    <circle cx="22" cy="2.5" r="3" fill="#3b82f6"/>
                    <text x="32" y="24" font-family="-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif"
                          font-size="21" font-weight="800" fill="currentColor" letter-spacing="-0.3">exio</text>
                </svg>
            </a>
        </div>

        <h1 class="auth-title"><?= t('register_title') ?></h1>
        <p class="auth-subtitle"><?= t('register_subtitle') ?></p>

        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" class="auth-form" novalidate>

            <div class="form-group">
                <label class="form-label"><?= t('i_am_a') ?></label>
                <div class="role-selector">
                    <label class="role-option <?= $selectedRole === 'employer' ? 'selected' : '' ?>">
                        <input type="radio" name="role" value="employer"
                               <?= $selectedRole === 'employer' ? 'checked' : '' ?>>
                        <div class="role-option__icon">
                            <i data-lucide="briefcase" width="22" height="22"></i>
                        </div>
                        <div>
                            <strong><?= t('employer') ?></strong>
                            <span><?= t('employer_desc') ?></span>
                        </div>
                    </label>
                    <label class="role-option <?= $selectedRole === 'employee' ? 'selected' : '' ?>">
                        <input type="radio" name="role" value="employee"
                               <?= $selectedRole === 'employee' ? 'checked' : '' ?>>
                        <div class="role-option__icon">
                            <i data-lucide="user" width="22" height="22"></i>
                        </div>
                        <div>
                            <strong><?= t('employee') ?></strong>
                            <span><?= t('employee_desc') ?></span>
                        </div>
                    </label>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="name"><?= t('full_name') ?> <span class="req">*</span></label>
                    <input class="form-control" type="text" id="name" name="name"
                           value="<?= htmlspecialchars($_POST['name'] ?? '') ?>"
                           placeholder="Иван Иванов" required autofocus>
                </div>
                <div class="form-group">
                    <label class="form-label" for="email"><?= t('email') ?> <span class="req">*</span></label>
                    <input class="form-control" type="email" id="email" name="email"
                           value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                           placeholder="you@company.com" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group" id="companyGroup">
                    <label class="form-label" for="company" id="companyLabel">
                        <?= t('field_company_employer') ?>
                    </label>
                    <input class="form-control" type="text" id="company" name="company"
                           value="<?= htmlspecialchars($_POST['company'] ?? '') ?>"
                           placeholder="<?= t('field_company_ph_employer') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label" for="position" id="positionLabel">
                        <?= $selectedRole === 'employee' ? t('field_position_employee') : t('field_position_employer') ?>
                    </label>
                    <input class="form-control" type="text" id="position" name="position"
                           value="<?= htmlspecialchars($_POST['position'] ?? '') ?>"
                           placeholder="<?= $selectedRole === 'employee' ? t('field_position_ph_employee') : t('field_position_ph_employer') ?>"
                           id="positionInput">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="password"><?= t('password') ?> <span class="req">*</span></label>
                <input class="form-control" type="password" id="password" name="password"
                       placeholder="<?= currentLang() === 'kz' ? 'Кемінде 6 таңба' : 'Минимум 6 символов' ?>" required>
            </div>

            <button type="submit" class="btn btn-primary btn-block btn-lg"><?= t('register_now') ?></button>
        </form>

        <script>
        window.nexioPage = {
            selectedRole: <?= json_encode($selectedRole) ?>,
            roleLabels: {
                employer: {
                    positionLabel: <?= json_encode(t('field_position_employer')) ?>,
                    positionPh:    <?= json_encode(t('field_position_ph_employer')) ?>,
                    showCompany:   true
                },
                employee: {
                    positionLabel: <?= json_encode(t('field_position_employee')) ?>,
                    positionPh:    <?= json_encode(t('field_position_ph_employee')) ?>,
                    showCompany:   false
                }
            }
        };
        </script>
        <script src="<?= BASE_URL ?>/assets/js/pages/register.js?v=<?= asset_ver('assets/js/pages/register.js') ?>"></script>

        <div class="auth-footer">
            <?= t('already_have_account') ?>
            <a href="<?= BASE_URL ?>/pages/login.php"><?= t('sign_in') ?></a>
        </div>
    </div>

    <!-- Visual panel -->
    <div class="auth-visual">
        <div class="auth-visual__content">
            <h2><?= t('auth_visual_register') ?></h2>
            <ul class="auth-features-list">
                <li><?= t('auth_feat_1') ?></li>
                <li><?= t('auth_feat_2') ?></li>
                <li><?= t('auth_feat_3') ?></li>
                <li><?= t('auth_feat_4') ?></li>
            </ul>
        </div>
    </div>

</div>

<script src="<?= BASE_URL ?>/assets/js/lucide.min.js?v=<?= asset_ver('assets/js/lucide.min.js') ?>"></script>
<script src="<?= BASE_URL ?>/assets/js/app.js?v=<?= asset_ver('assets/js/app.js') ?>"></script>
</body>
</html>
