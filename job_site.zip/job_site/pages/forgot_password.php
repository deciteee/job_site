<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/i18n.php';

if (isLoggedIn()) { header('Location: ' . BASE_URL . '/pages/dashboard.php'); exit; }

$msg = ''; $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = t('err_invalid_email');
    } else {
        // Always show success to prevent email enumeration
        $msg = t('forgot_success_msg');

        $stmt = $conn->prepare("SELECT id, name FROM users WHERE email=? AND status='active'");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($user) {
            $token   = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

            $stmt = $conn->prepare(
                "INSERT INTO password_resets (email, token, expires_at) VALUES (?,?,?)
                 ON DUPLICATE KEY UPDATE token=VALUES(token), expires_at=VALUES(expires_at), created_at=NOW()"
            );
            $stmt->bind_param('sss', $email, $token, $expires);
            $stmt->execute(); $stmt->close();

            require_once __DIR__ . '/../includes/mailer.php';
            sendPasswordResetEmail($email, $user['name'], $token);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="<?= $_SESSION['lang'] ?? 'ru' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= t('forgot_title') ?> — <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <script>(function(){var t=localStorage.getItem('nexio-theme')||'light';document.documentElement.setAttribute('data-theme',t);})()</script>
</head>
<body class="auth-body">

<div class="auth-layout">

    <div class="auth-controls">
        <button class="theme-btn" data-action="theme" title="Toggle theme">
            <i data-lucide="moon" width="14" height="14"></i>
        </button>
    </div>

    <div class="auth-panel">
        <div class="auth-brand">
            <a href="<?= BASE_URL ?>/" style="display:flex;align-items:center;text-decoration:none;color:inherit;">
                <svg viewBox="0 0 105 32" fill="none" height="28">
                    <defs>
                        <linearGradient id="nexio-g-fp" x1="0" y1="0" x2="1" y2="1">
                            <stop offset="0%" stop-color="#60a5fa"/>
                            <stop offset="100%" stop-color="#2563eb"/>
                        </linearGradient>
                    </defs>
                    <path d="M4 27V7L22 27V7" stroke="url(#nexio-g-fp)" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
                    <circle cx="22" cy="2.5" r="3" fill="#3b82f6"/>
                    <text x="32" y="24" font-family="-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif"
                          font-size="21" font-weight="800" fill="currentColor" letter-spacing="-0.3">exio</text>
                </svg>
            </a>
        </div>

        <h1 class="auth-title"><?= t('forgot_title') ?></h1>
        <p class="auth-subtitle"><?= t('forgot_subtitle') ?></p>

        <?php if ($msg): ?>
            <div class="alert alert-success" style="margin-bottom:18px"><?= htmlspecialchars($msg) ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-error" style="margin-bottom:18px"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if (!$msg): ?>
        <form method="POST" class="auth-form" novalidate>
            <div class="form-group">
                <label class="form-label" for="email">Email</label>
                <input class="form-control" type="email" id="email" name="email"
                       value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                       placeholder="you@example.com" required autofocus>
            </div>
            <button type="submit" class="btn btn-primary btn-block btn-lg"><?= t('forgot_send_btn') ?></button>
        </form>
        <?php endif; ?>

        <div class="auth-footer" style="margin-top:20px">
            <a href="<?= BASE_URL ?>/pages/login.php"><?= t('back_to_login') ?></a>
        </div>
    </div>

    <div class="auth-visual">
        <div class="auth-visual__content">
            <h2><?= t('recovery_visual_title') ?></h2>
            <ul class="auth-features-list">
                <li><?= t('recovery_feat_1') ?></li>
                <li><?= t('recovery_feat_2') ?></li>
                <li><?= t('recovery_feat_3') ?></li>
            </ul>
        </div>
    </div>

</div>

<script src="<?= BASE_URL ?>/assets/js/lucide.min.js?v=<?= asset_ver('assets/js/lucide.min.js') ?>"></script>
<script src="<?= BASE_URL ?>/assets/js/app.js?v=<?= asset_ver('assets/js/app.js') ?>"></script>
</body>
</html>
