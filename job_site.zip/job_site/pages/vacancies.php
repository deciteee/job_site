<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

$uid  = $_SESSION['user_id'];
$role = $_SESSION['user_role'];

// ── Special tab (saved / hidden) ──────────────────────────────
$tab = $_GET['tab'] ?? '';
if (!in_array($tab, ['saved','hidden'])) $tab = '';

// ── Filters ───────────────────────────────────────────────────
$search      = trim($_GET['q']       ?? '');
$location    = trim($_GET['loc']     ?? '');
$filterTypes = array_intersect($_GET['et'] ?? [], ['full-time','part-time','remote','contract']);
$salMin      = (int)($_GET['sal_min'] ?? 0);
$salMax      = (int)($_GET['sal_max'] ?? 0);
$sort        = in_array($_GET['sort'] ?? '', ['newest','sal_asc','sal_desc']) ? $_GET['sort'] : 'newest';

// ── Build WHERE ───────────────────────────────────────────────
$statusCond = ($tab === 'hidden' && $role === 'employer') ? "v.status = 'closed'" : "v.status = 'active'";
// For employees browsing active vacancies: exclude expired
$expiryCond = ($role === 'employee' && $tab !== 'hidden')
    ? "AND (v.expires_at IS NULL OR v.expires_at >= CURDATE())"
    : "";
$where  = [$statusCond . " $expiryCond"];
$params = [];
$types  = '';

if ($role === 'employer') {
    $where[]  = "v.employer_id = ?";
    $params[] = $uid;
    $types   .= 'i';
}

$savedJoin = '';
if ($tab === 'saved' && $role === 'employee') {
    $savedJoin = "JOIN saved_vacancies _sv ON _sv.vacancy_id=v.id AND _sv.user_id=$uid";
}

if ($search) {
    $like = "%$search%";
    $where[]  = "(v.title LIKE ? OR v.description LIKE ? OR u.company LIKE ?)";
    $params[] = $like; $params[] = $like; $params[] = $like;
    $types   .= 'sss';
}
if ($location) {
    $where[]  = "v.location LIKE ?";
    $params[] = "%$location%";
    $types   .= 's';
}
if ($filterTypes) {
    $ph = implode(',', array_fill(0, count($filterTypes), '?'));
    $where[] = "v.employment_type IN ($ph)";
    foreach ($filterTypes as $ft) { $params[] = $ft; $types .= 's'; }
}
if ($salMin > 0) {
    $where[]  = "(v.salary_max >= ? OR v.salary_min >= ?)";
    $params[] = $salMin; $params[] = $salMin;
    $types   .= 'ii';
}
if ($salMax > 0) {
    $where[]  = "(v.salary_min <= ? OR v.salary_min IS NULL)";
    $params[] = $salMax;
    $types   .= 'i';
}

$orderSQL = match($sort) {
    'sal_asc'  => 'ORDER BY COALESCE(v.salary_min,0) ASC',
    'sal_desc' => 'ORDER BY COALESCE(v.salary_max,v.salary_min,0) DESC',
    default    => 'ORDER BY v.created_at DESC',
};

$whereSQL = 'WHERE ' . implode(' AND ', $where);

// ── Pagination ────────────────────────────────────────────────
$perPage = 10;
$page    = max(1, (int)($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;

$cntStmt = $conn->prepare("SELECT COUNT(*) FROM vacancies v JOIN users u ON v.employer_id=u.id $savedJoin $whereSQL");
if ($params) $cntStmt->bind_param($types, ...$params);
$cntStmt->execute();
$totalVacancies = (int)$cntStmt->get_result()->fetch_row()[0];
$cntStmt->close();
$totalPages = (int)ceil($totalVacancies / $perPage);

$stmt = $conn->prepare("SELECT v.*, u.name AS employer_name, u.company
    FROM vacancies v JOIN users u ON v.employer_id=u.id
    $savedJoin $whereSQL $orderSQL LIMIT ? OFFSET ?");
$allP = array_merge($params, [$perPage, $offset]);
$stmt->bind_param($types . 'ii', ...$allP);
$stmt->execute();
$vacancies = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// ── Applied & saved IDs ───────────────────────────────────────
$applied_ids = []; $saved_ids = [];
if ($role === 'employee') {
    $r = $conn->prepare("SELECT vacancy_id FROM applications WHERE employee_id=?");
    $r->bind_param('i',$uid); $r->execute();
    foreach ($r->get_result()->fetch_all() as $x) $applied_ids[] = $x[0];
    $r->close();
    $r = $conn->prepare("SELECT vacancy_id FROM saved_vacancies WHERE user_id=?");
    $r->bind_param('i',$uid); $r->execute();
    foreach ($r->get_result()->fetch_all() as $x) $saved_ids[] = $x[0];
    $r->close();
}

// ── Tab counts ────────────────────────────────────────────────
$tcWhere = ["v.status='active'"]; $tcP = []; $tcT = '';
if ($role === 'employer') { $tcWhere[] = "v.employer_id=?"; $tcP[] = $uid; $tcT .= 'i'; }
$tcStmt = $conn->prepare("SELECT employment_type, COUNT(*) cnt FROM vacancies v WHERE ".implode(' AND ',$tcWhere)." GROUP BY employment_type");
if ($tcP) $tcStmt->bind_param($tcT,...$tcP);
$tcStmt->execute();
$typeCounts = []; $totalCount = 0;
foreach ($tcStmt->get_result()->fetch_all(MYSQLI_ASSOC) as $row) {
    $typeCounts[$row['employment_type']] = (int)$row['cnt'];
    $totalCount += (int)$row['cnt'];
}
$tcStmt->close();

$savedCount  = $role === 'employee'
    ? (int)$conn->query("SELECT COUNT(*) FROM saved_vacancies WHERE user_id=$uid")->fetch_row()[0] : 0;
$hiddenCount = $role === 'employer'
    ? (int)$conn->query("SELECT COUNT(*) FROM vacancies WHERE employer_id=$uid AND status='closed'")->fetch_row()[0] : 0;

// ── Unique cities for datalist ────────────────────────────────
$cities = [];
$cr = $conn->query("SELECT DISTINCT location FROM vacancies WHERE status='active' AND location!='' ORDER BY location LIMIT 50");
while ($row = $cr->fetch_row()) $cities[] = $row[0];

// ── Sidebar stats ─────────────────────────────────────────────
if ($role === 'employee') {
    $sb_apps   = (int)$conn->query("SELECT COUNT(*) FROM applications WHERE employee_id=$uid")->fetch_row()[0];
    $sb_avg    = $conn->query("SELECT IFNULL(ROUND(AVG(score)*2,1),0) FROM ratings WHERE employee_id=$uid")->fetch_row()[0];
} else {
    $sb_vac    = (int)$conn->query("SELECT COUNT(*) FROM vacancies WHERE employer_id=$uid AND status='active'")->fetch_row()[0];
    $sb_apps   = (int)$conn->query("SELECT COUNT(*) FROM applications a JOIN vacancies v ON a.vacancy_id=v.id WHERE v.employer_id=$uid")->fetch_row()[0];
}

// ── Helpers ───────────────────────────────────────────────────
function companyGrad(string $name): string {
    $p=[['#3b82f6','#1d4ed8'],['#8b5cf6','#6d28d9'],['#ec4899','#be185d'],['#10b981','#047857'],['#f59e0b','#b45309'],['#06b6d4','#0e7490'],['#ef4444','#b91c1c'],['#6366f1','#4338ca']];
    return "linear-gradient(135deg,{$p[ord($name[0]??'A')%count($p)][0]},{$p[ord($name[0]??'A')%count($p)][1]})";
}
function vacAgo(string $ts): string {
    $d = time() - strtotime($ts);
    if ($d < 3600)    return floor($d/60).' '.t('time_min_ago');
    if ($d < 86400)   return floor($d/3600).' '.t('time_hr_ago');
    if ($d < 604800)  return floor($d/86400).' '.t('time_day_ago');
    if ($d < 2592000) return floor($d/604800).' '.t('time_week_ago');
    return date('d M Y', strtotime($ts));
}

require_once __DIR__ . '/../includes/covers.php';

// Active filter count (for badge)
$activeFilters = (int)(bool)$search + (int)(bool)$location + count($filterTypes)
               + (int)($salMin > 0) + (int)($salMax > 0);

$pageTitle = t('vacancies');
include __DIR__ . '/../includes/header.php';
?>

<style>
/* ── Layout ──────────────────────────────────────────────────── */
.vac-page { display: grid; grid-template-columns: 268px 1fr; gap: 22px; align-items: start; }
@media (max-width: 900px) { .vac-page { grid-template-columns: 1fr; } .vac-sidebar { display: none; } }

/* ── Filter sidebar ──────────────────────────────────────────── */
.vac-sidebar { position: sticky; top: 16px; display: flex; flex-direction: column; gap: 12px; }

.filter-card {
    background: var(--card-bg);
    border: 1.5px solid var(--border);
    border-radius: 20px;
    overflow: hidden;
}
.filter-card__head {
    display: flex; align-items: center; justify-content: space-between;
    padding: 14px 18px 12px;
    border-bottom: 1px solid var(--border-light);
}
.filter-card__title {
    font-size: 13px; font-weight: 700; color: var(--text-primary);
    display: flex; align-items: center; gap: 7px;
}
.filter-badge {
    display: inline-flex; align-items: center; justify-content: center;
    width: 18px; height: 18px; border-radius: 50%;
    background: var(--primary); color: #fff; font-size: 10px; font-weight: 700;
}
.filter-reset {
    font-size: 12px; color: var(--text-muted); text-decoration: none;
    padding: 3px 8px; border-radius: 8px; border: 1px solid var(--border);
    transition: all .14s;
}
.filter-reset:hover { color: #ef4444; border-color: #ef4444; text-decoration: none; }

.filter-section { padding: 14px 18px; border-bottom: 1px solid var(--border-light); }
.filter-section:last-child { border-bottom: none; }
.filter-label {
    font-size: 10.5px; font-weight: 700; text-transform: uppercase;
    letter-spacing: .07em; color: var(--text-muted); margin-bottom: 10px;
    display: flex; align-items: center; gap: 6px;
}
.filter-input {
    width: 100%; background: var(--border-light); border: 1.5px solid transparent;
    border-radius: 10px; padding: 8px 12px; font-size: 13px;
    color: var(--text-primary); outline: none; transition: border-color .15s;
    box-sizing: border-box;
}
.filter-input:focus { border-color: var(--primary); background: var(--card-bg); }

/* Checkboxes */
.filter-check { display: flex; align-items: center; gap: 9px; padding: 6px 0; cursor: pointer; }
.filter-check input[type=checkbox] { display: none; }
.filter-check__box {
    width: 18px; height: 18px; border-radius: 5px; flex-shrink: 0;
    border: 1.5px solid var(--border); background: var(--card-bg);
    display: flex; align-items: center; justify-content: center;
    transition: all .14s;
}
.filter-check input:checked ~ .filter-check__box {
    background: var(--primary); border-color: var(--primary);
}
.filter-check input:checked ~ .filter-check__box svg { display: block; }
.filter-check__box svg { display: none; }
.filter-check__label { font-size: 13px; color: var(--text-primary); flex: 1; }
.filter-check__cnt { font-size: 11px; color: var(--text-muted); font-weight: 600; }

/* Salary inputs */
.salary-row { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.salary-row input { text-align: center; }

/* Sort select */
.filter-select {
    width: 100%; background: var(--border-light); border: 1.5px solid transparent;
    border-radius: 10px; padding: 8px 12px; font-size: 13px;
    color: var(--text-primary); outline: none; cursor: pointer;
    transition: border-color .15s; box-sizing: border-box; appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%236b7280' stroke-width='2.5'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E");
    background-repeat: no-repeat; background-position: right 10px center;
    padding-right: 30px;
}
.filter-select:focus { border-color: var(--primary); }

.filter-apply {
    width: 100%; padding: 10px; border-radius: 12px; font-size: 13px;
    font-weight: 600; border: none; cursor: pointer;
    background: linear-gradient(135deg,#3b82f6,#1d4ed8);
    color: #fff; transition: opacity .15s; margin-top: 2px;
}
.filter-apply:hover { opacity: .88; }

/* ── Stats mini card (employer/employee) ─────────────────────── */
.vsb-mini {
    background: var(--card-bg); border: 1.5px solid var(--border);
    border-radius: 16px; padding: 14px 16px;
    display: flex; gap: 0; flex-direction: column;
}
.vsb-mini__row {
    display: flex; align-items: center; gap: 10px;
    padding: 7px 0; border-bottom: 1px solid var(--border-light);
}
.vsb-mini__row:last-child { border-bottom: none; padding-bottom: 0; }
.vsb-mini__row:first-child { padding-top: 0; }
.vsb-mini__icon { width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.vsb-mini__label { font-size: 12px; color: var(--text-secondary); flex: 1; }
.vsb-mini__val { font-size: 13px; font-weight: 700; color: var(--text-primary); }

/* ── Main area ───────────────────────────────────────────────── */
.vac-main { display: flex; flex-direction: column; gap: 14px; min-width: 0; }

/* ── Topbar: result count + tabs ────────────────────────────── */
.vac-topbar { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; }
.vac-result-info { font-size: 13px; color: var(--text-muted); display: flex; align-items: center; gap: 6px; }

/* ── Tabs (saved/hidden only) ────────────────────────────────── */
.vac-tabs { display: flex; gap: 7px; flex-wrap: wrap; }
.vac-tab { display: inline-flex; align-items: center; gap: 6px; padding: 7px 14px; border-radius: 100px; font-size: 12.5px; font-weight: 500; text-decoration: none; border: 1.5px solid var(--border); color: var(--text-secondary); background: var(--card-bg); transition: all .14s; white-space: nowrap; }
.vac-tab:hover { border-color: var(--primary); color: var(--primary); background: rgba(37,99,235,.05); text-decoration: none; }
.vac-tab.active { background: var(--primary); border-color: var(--primary); color: #fff; box-shadow: 0 4px 12px rgba(37,99,235,.28); }
.vac-tab__cnt { font-size: 10.5px; font-weight: 700; opacity: .85; }
.vac-tab--heart.active { background: #f43f5e; border-color: #f43f5e; box-shadow: 0 4px 12px rgba(244,63,94,.3); }
.vac-tab--hidden.active { background: #6b7280; border-color: #6b7280; box-shadow: 0 4px 12px rgba(107,114,128,.3); }

/* ── Active filter chips ──────────────────────────────────────── */
.active-chips { display: flex; flex-wrap: wrap; gap: 6px; }
.chip { display: inline-flex; align-items: center; gap: 5px; padding: 4px 10px; border-radius: 100px; font-size: 12px; font-weight: 500; background: rgba(37,99,235,.09); color: #2563eb; border: 1px solid rgba(37,99,235,.2); }
.chip__x { cursor: pointer; opacity: .7; font-size: 14px; line-height: 1; }
.chip__x:hover { opacity: 1; }

/* ── Cards ───────────────────────────────────────────────────── */
.vac-grid { display: flex; flex-direction: column; gap: 10px; }
.vac-card {
    background: var(--card-bg);
    border: 1px solid var(--border);
    border-radius: 12px;
    overflow: hidden;
    display: flex;
    transition: border-color .18s ease, box-shadow .18s ease;
    position: relative;
}
.vac-card__content {
    flex: 1; min-width: 0;
    padding: 18px 20px 18px 18px;
}
.vac-card:hover {
    border-color: rgba(37,99,235,.45);
    box-shadow: 0 4px 14px rgba(15,23,42,.06);
}
[data-theme="dark"] .vac-card:hover { box-shadow: 0 4px 14px rgba(0,0,0,.35); }

.vac-card__fav {
    position: absolute; top: 14px; right: 16px;
    width: 30px; height: 30px; border-radius: 8px;
    background: transparent; border: 1px solid var(--border);
    cursor: pointer; display: flex; align-items: center; justify-content: center;
    transition: all .15s; color: var(--text-muted); padding: 0;
}
.vac-card__fav:hover { background: rgba(244,63,94,.08); border-color: rgba(244,63,94,.35); color: #f43f5e; }
.vac-card__fav.saved { background: rgba(244,63,94,.08); border-color: rgba(244,63,94,.35); color: #f43f5e; }
.vac-card__fav.saved svg { fill: #f43f5e; }

.vac-card__head { display: flex; gap: 14px; align-items: flex-start; margin-bottom: 10px; padding-right: 42px; }
.vac-card__head-text { min-width: 0; flex: 1; }
.vac-card__title {
    font-size: 16px; font-weight: 700; color: var(--text-primary);
    text-decoration: none; line-height: 1.35; margin-bottom: 4px; display: block;
    letter-spacing: -.01em;
}
.vac-card__title:hover { color: var(--primary); text-decoration: none; }
.vac-card__company {
    font-size: 13px; color: var(--text-secondary);
    display: inline-flex; align-items: center; flex-wrap: wrap;
    line-height: 1.5;
}
.vac-card__sep { margin: 0 8px; color: var(--text-muted); opacity: .6; }

.vac-card__pills { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 10px; }
.vac-pill {
    display: inline-flex; align-items: center; gap: 4px;
    padding: 3px 9px; border-radius: 6px;
    font-size: 11.5px; font-weight: 500;
}
.vac-pill--loc       { background: var(--border-light); color: var(--text-secondary); border: 1px solid var(--border); }
.vac-pill--remote    { background: rgba(37,99,235,.07);  color: #1d4ed8; border: 1px solid rgba(37,99,235,.18); }
.vac-pill--full-time { background: rgba(15,23,42,.04);   color: var(--text-secondary); border: 1px solid var(--border); }
.vac-pill--part-time { background: rgba(15,23,42,.04);   color: var(--text-secondary); border: 1px solid var(--border); }
.vac-pill--contract  { background: rgba(15,23,42,.04);   color: var(--text-secondary); border: 1px solid var(--border); }
[data-theme="dark"] .vac-pill--full-time,
[data-theme="dark"] .vac-pill--part-time,
[data-theme="dark"] .vac-pill--contract { background: rgba(255,255,255,.04); }

.vac-card__salary {
    font-size: 14px; font-weight: 700; color: var(--text-primary);
    margin-bottom: 12px; display: inline-flex; align-items: center; gap: 6px;
    letter-spacing: -.01em;
}
.vac-card__salary svg { color: #059669; }
.vac-card__footer {
    display: flex; align-items: center; justify-content: space-between;
    padding-top: 12px; border-top: 1px solid var(--border-light);
    gap: 8px; flex-wrap: wrap;
}
.vac-card__time { font-size: 11.5px; color: var(--text-muted); }
.vac-card__applied-badge {
    display: inline-flex; align-items: center; gap: 5px;
    font-size: 12px; font-weight: 600; color: #059669;
    padding: 5px 11px; background: rgba(16,185,129,.08);
    border-radius: 6px; border: 1px solid rgba(16,185,129,.2);
}

/* ── Empty ───────────────────────────────────────────────────── */
.vac-empty { background: var(--card-bg); border: 1.5px dashed var(--border); border-radius: 20px; padding: 60px 24px; text-align: center; }
.vac-empty__icon { font-size: 44px; margin-bottom: 12px; }
.vac-empty__title { font-size: 16px; font-weight: 600; color: var(--text-primary); margin-bottom: 6px; }
.vac-empty__sub { font-size: 13px; color: var(--text-muted); }

/* ── Vacancy covers ──────────────────────────────────────────── */
.vac-cover {
    width: 88px; align-self: stretch; flex-shrink: 0;
    background-size: cover; background-position: center;
    background-color: #1e293b;
    position: relative; overflow: hidden;
}
.vac-cover::after {
    content: '';
    position: absolute; right: 0; top: 0; bottom: 0; width: 28px;
    background: linear-gradient(to right, transparent, var(--card-bg));
    pointer-events: none;
}

/* ── Pagination ──────────────────────────────────────────────── */
.vac-pagination { display: flex; justify-content: center; align-items: center; gap: 5px; flex-wrap: wrap; }
.pg-btn { display: inline-flex; align-items: center; justify-content: center; width: 36px; height: 36px; border-radius: 10px; font-size: 13px; font-weight: 500; text-decoration: none; border: 1.5px solid var(--border); background: var(--card-bg); color: var(--text-primary); transition: all .14s; }
.pg-btn:hover { border-color: var(--primary); color: var(--primary); text-decoration: none; }
.pg-btn.active { background: var(--primary); border-color: var(--primary); color: #fff; font-weight: 700; }
</style>

<?php
// Build base URL params (without page) for filter links
$filterParams = array_filter([
    'q'       => $search,
    'loc'     => $location,
    'sal_min' => $salMin ?: '',
    'sal_max' => $salMax ?: '',
    'sort'    => $sort !== 'newest' ? $sort : '',
    'tab'     => $tab,
]);
foreach ($filterTypes as $ft) $filterParams['et'][] = $ft;
$filterParams = array_filter($filterParams);
?>

<div class="vac-page">

<!-- ════════════ SIDEBAR FILTER ════════════ -->
<aside class="vac-sidebar">
<form method="GET" id="filterForm">

<div class="filter-card">
    <div class="filter-card__head">
        <div class="filter-card__title">
            <i data-lucide="filter" width="15" height="15"></i>
            <?= t('filter_title') ?>
            <?php if ($activeFilters > 0): ?>
            <span class="filter-badge"><?= $activeFilters ?></span>
            <?php endif; ?>
        </div>
        <?php if ($activeFilters > 0): ?>
        <a href="<?= BASE_URL ?>/pages/vacancies.php<?= $tab ? '?tab='.$tab : '' ?>" class="filter-reset"><?= t('clear') ?></a>
        <?php endif; ?>
    </div>

    <!-- Search -->
    <div class="filter-section">
        <div class="filter-label">
            <i data-lucide="search" width="12" height="12"></i>
            <?= t('search_label') ?>
        </div>
        <input type="text" name="q" class="filter-input" placeholder="<?= t('search_job_ph') ?>" value="<?= htmlspecialchars($search) ?>">
    </div>

    <!-- Location -->
    <div class="filter-section">
        <div class="filter-label">
            <i data-lucide="map-pin" width="12" height="12"></i>
            <?= t('city_label') ?>
        </div>
        <input type="text" name="loc" class="filter-input" placeholder="<?= t('search_city_ph') ?>" value="<?= htmlspecialchars($location) ?>" list="cityList" autocomplete="off">
        <datalist id="cityList">
            <?php foreach ($cities as $c): ?>
            <option value="<?= htmlspecialchars($c) ?>">
            <?php endforeach; ?>
        </datalist>
    </div>

    <!-- Employment type -->
    <div class="filter-section">
        <div class="filter-label">
            <i data-lucide="briefcase" width="12" height="12"></i>
            <?= t('filter_employment_type') ?>
        </div>
        <?php
        $etOptions = [
            'full-time' => ['label' => t('type_full_time'), 'color' => '#10b981'],
            'part-time' => ['label' => t('type_part_time'), 'color' => '#f59e0b'],
            'remote'    => ['label' => t('type_remote'),    'color' => '#3b82f6'],
            'contract'  => ['label' => t('type_contract'),  'color' => '#8b5cf6'],
        ];
        foreach ($etOptions as $val => $opt):
            $checked = in_array($val, $filterTypes);
            $cnt = $typeCounts[$val] ?? 0;
        ?>
        <label class="filter-check">
            <input type="checkbox" name="et[]" value="<?= $val ?>" <?= $checked ? 'checked' : '' ?>>
            <div class="filter-check__box" style="<?= $checked ? "background:{$opt['color']};border-color:{$opt['color']}" : '' ?>">
                <i data-lucide="check" width="10" height="10" stroke="#fff" stroke-width="3"></i>
            </div>
            <span class="filter-check__label"><?= $opt['label'] ?></span>
            <?php if ($cnt): ?><span class="filter-check__cnt"><?= $cnt ?></span><?php endif; ?>
        </label>
        <?php endforeach; ?>
    </div>

    <!-- Salary -->
    <div class="filter-section">
        <div class="filter-label">
            <i data-lucide="dollar-sign" width="12" height="12"></i>
            <?= t('filter_salary') ?>
        </div>
        <div class="salary-row">
            <input type="number" name="sal_min" class="filter-input" placeholder="<?= t('from_salary') ?>" min="0" step="10000"
                   value="<?= $salMin ?: '' ?>">
            <input type="number" name="sal_max" class="filter-input" placeholder="<?= t('to_salary') ?>" min="0" step="10000"
                   value="<?= $salMax ?: '' ?>">
        </div>
    </div>

    <!-- Sort -->
    <div class="filter-section">
        <div class="filter-label">
            <i data-lucide="align-left" width="12" height="12"></i>
            <?= t('filter_sort') ?>
        </div>
        <select name="sort" class="filter-select">
            <option value="newest"   <?= $sort==='newest'   ? 'selected' : '' ?>><?= t('sort_newest') ?></option>
            <option value="sal_desc" <?= $sort==='sal_desc' ? 'selected' : '' ?>><?= t('sort_sal_desc') ?></option>
            <option value="sal_asc"  <?= $sort==='sal_asc'  ? 'selected' : '' ?>><?= t('sort_sal_asc') ?></option>
        </select>
    </div>

    <?php if ($tab): ?><input type="hidden" name="tab" value="<?= htmlspecialchars($tab) ?>"><?php endif; ?>

    <div class="filter-section" style="padding-top:10px;padding-bottom:16px">
        <button type="submit" class="filter-apply">
            <i data-lucide="search" width="14" height="14" style="vertical-align:-2px;margin-right:5px"></i>
            <?= t('filter_apply_btn') ?>
        </button>
    </div>
</div>

</form>

<!-- Mini stats -->
<div class="vsb-mini">
<?php if ($role === 'employee'): ?>
    <div class="vsb-mini__row">
        <div class="vsb-mini__icon" style="background:rgba(37,99,235,.1)">
            <i data-lucide="square-check" width="14" height="14" style="color:#2563eb"></i>
        </div>
        <span class="vsb-mini__label"><?= t('sb_my_apps') ?></span>
        <span class="vsb-mini__val"><?= $sb_apps ?></span>
    </div>
    <div class="vsb-mini__row">
        <div class="vsb-mini__icon" style="background:rgba(244,63,94,.1)">
            <i data-lucide="heart" width="14" height="14" style="color:#f43f5e"></i>
        </div>
        <span class="vsb-mini__label"><?= t('sb_saved') ?></span>
        <span class="vsb-mini__val"><?= $savedCount ?></span>
    </div>
    <div class="vsb-mini__row">
        <div class="vsb-mini__icon" style="background:rgba(16,185,129,.1)">
            <i data-lucide="briefcase" width="14" height="14" style="color:#10b981"></i>
        </div>
        <span class="vsb-mini__label"><?= t('sb_total_vacs') ?></span>
        <span class="vsb-mini__val"><?= $totalCount ?></span>
    </div>
<?php else: ?>
    <div class="vsb-mini__row">
        <div class="vsb-mini__icon" style="background:rgba(37,99,235,.1)">
            <i data-lucide="briefcase" width="14" height="14" style="color:#2563eb"></i>
        </div>
        <span class="vsb-mini__label"><?= t('sb_active_vacs') ?></span>
        <span class="vsb-mini__val"><?= $sb_vac ?></span>
    </div>
    <div class="vsb-mini__row">
        <div class="vsb-mini__icon" style="background:rgba(16,185,129,.1)">
            <i data-lucide="user" width="14" height="14" style="color:#10b981"></i>
        </div>
        <span class="vsb-mini__label"><?= t('sb_total_apps') ?></span>
        <span class="vsb-mini__val"><?= $sb_apps ?></span>
    </div>
    <div class="vsb-mini__row">
        <div class="vsb-mini__icon" style="background:rgba(107,114,128,.1)">
            <i data-lucide="eye-off" width="14" height="14" style="color:#6b7280"></i>
        </div>
        <span class="vsb-mini__label"><?= t('status_closed') ?></span>
        <span class="vsb-mini__val"><?= $hiddenCount ?></span>
    </div>
<?php endif; ?>
</div>

<?php if ($role === 'employer'): ?>
<a href="<?= BASE_URL ?>/pages/vacancy_create.php"
   style="display:flex;align-items:center;justify-content:center;gap:8px;padding:12px;background:linear-gradient(135deg,#3b82f6,#1d4ed8);color:#fff;border-radius:14px;text-decoration:none;font-weight:600;font-size:13.5px;transition:opacity .15s">
    <i data-lucide="circle-plus" width="15" height="15"></i>
    <?= t('post_new_vacancy') ?>
</a>
<?php endif; ?>

</aside>

<!-- ════════════ MAIN ════════════ -->
<div class="vac-main">

    <!-- Topbar: result info + special tabs -->
    <div class="vac-topbar">
        <div class="vac-result-info">
            <i data-lucide="briefcase" width="14" height="14"></i>
            <strong style="color:var(--text-primary)"><?= $totalVacancies ?></strong> <?= t('vac_found_count') ?>
            <?php if ($totalPages > 1): ?>&nbsp;·&nbsp;<?= t('page_label') ?> <?= $page ?> / <?= $totalPages ?><?php endif; ?>
        </div>

        <div class="vac-tabs">
            <!-- All tab -->
            <?php $allHref = BASE_URL.'/pages/vacancies.php'.($filterParams ? '?'.http_build_query(array_diff_key($filterParams,['tab'=>''])) : ''); ?>
            <a href="<?= $allHref ?>" class="vac-tab <?= $tab==='' ? 'active' : '' ?>">
                <i data-lucide="layout-grid" width="12" height="12"></i>
                <?= t('tab_all') ?>
            </a>
            <?php if ($role === 'employee'): ?>
            <a href="<?= BASE_URL ?>/pages/vacancies.php?tab=saved" class="vac-tab vac-tab--heart <?= $tab==='saved' ? 'active' : '' ?>">
                <i data-lucide="heart" width="12" height="12" fill="<?= $tab==='saved'?'#fff':'none' ?>"></i>
                <?= t('tab_saved') ?>
                <?php if ($savedCount): ?><span class="vac-tab__cnt"><?= $savedCount ?></span><?php endif; ?>
            </a>
            <?php endif; ?>
            <?php if ($role === 'employer'): ?>
            <a href="<?= BASE_URL ?>/pages/vacancies.php?tab=hidden" class="vac-tab vac-tab--hidden <?= $tab==='hidden' ? 'active' : '' ?>">
                <i data-lucide="eye-off" width="12" height="12"></i>
                <?= t('tab_hidden') ?>
                <?php if ($hiddenCount): ?><span class="vac-tab__cnt"><?= $hiddenCount ?></span><?php endif; ?>
            </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Active filter chips -->
    <?php if ($activeFilters > 0): ?>
    <div class="active-chips">
        <?php if ($search): ?>
        <span class="chip">
            <i data-lucide="search" width="11" height="11"></i>
            <?= htmlspecialchars($search) ?>
            <a class="chip__x" href="<?= BASE_URL ?>/pages/vacancies.php?<?= http_build_query(array_merge($filterParams,['q'=>''])) ?>">&times;</a>
        </span>
        <?php endif; ?>
        <?php if ($location): ?>
        <span class="chip">
            <i data-lucide="map-pin" width="11" height="11"></i>
            <?= htmlspecialchars($location) ?>
            <a class="chip__x" href="<?= BASE_URL ?>/pages/vacancies.php?<?= http_build_query(array_merge($filterParams,['loc'=>''])) ?>">&times;</a>
        </span>
        <?php endif; ?>
        <?php foreach ($filterTypes as $ft): ?>
        <span class="chip"><?= $etOptions[$ft]['label'] ?>
            <?php $newEt = array_values(array_diff($filterTypes,[$ft])); $p2 = $filterParams; $p2['et'] = $newEt; ?>
            <a class="chip__x" href="<?= BASE_URL ?>/pages/vacancies.php?<?= http_build_query($p2) ?>">&times;</a>
        </span>
        <?php endforeach; ?>
        <?php if ($salMin): ?>
        <span class="chip">от <?= number_format($salMin,0,'.',' ') ?> ₸
            <a class="chip__x" href="<?= BASE_URL ?>/pages/vacancies.php?<?= http_build_query(array_merge($filterParams,['sal_min'=>''])) ?>">&times;</a>
        </span>
        <?php endif; ?>
        <?php if ($salMax): ?>
        <span class="chip">до <?= number_format($salMax,0,'.',' ') ?> ₸
            <a class="chip__x" href="<?= BASE_URL ?>/pages/vacancies.php?<?= http_build_query(array_merge($filterParams,['sal_max'=>''])) ?>">&times;</a>
        </span>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Cards -->
    <?php if (empty($vacancies)): ?>
    <div class="vac-empty">
        <div class="vac-empty__icon" style="color:var(--text-muted)"><i data-lucide="<?= $tab==='saved' ? 'heart' : 'search' ?>" width="44" height="44" stroke-width="1.5"></i></div>
        <div class="vac-empty__title"><?= $tab==='saved' ? t('vac_empty_saved') : t('vac_empty_search') ?></div>
        <div class="vac-empty__sub" style="margin-bottom:18px">
            <?= $tab==='saved' ? t('vac_empty_saved_hint') : t('vac_empty_search_hint') ?>
        </div>
        <?php if ($role === 'employer'): ?>
        <a href="<?= BASE_URL ?>/pages/vacancy_create.php" class="btn btn-primary">+ <?= t('post_new_vacancy') ?></a>
        <?php endif; ?>
    </div>
    <?php else: ?>
    <div class="vac-grid">
    <?php foreach ($vacancies as $v):
        $cn        = $v['company'] ?: $v['employer_name'];
        $initials  = mb_strtoupper(mb_substr($cn,0,1)).mb_strtoupper(mb_substr($cn,1,1));
        $grad      = companyGrad($cn);
        $isSaved   = in_array($v['id'], $saved_ids);
        $isApplied = in_array($v['id'], $applied_ids);
        $tk = strtolower(str_replace(' ','-',$v['employment_type']??''));
        $pillClass = match(true) {
            str_contains($tk,'remote')   => 'vac-pill--remote',
            str_contains($tk,'full')     => 'vac-pill--full-time',
            str_contains($tk,'part')     => 'vac-pill--part-time',
            str_contains($tk,'contract') => 'vac-pill--contract',
            default => 'vac-pill--loc',
        };
    ?>
    <?php $coverCat = vacancyCoverCat($v['title'], $v['cover_image'] ?? 'default'); ?>
    <div class="vac-card">
        <div class="vac-cover" style="background-image:url('<?= vacancyCoverUrl($coverCat, 176) ?>')"></div>
        <div class="vac-card__content">

        <?php if ($role === 'employee'): ?>
        <button class="vac-card__fav <?= $isSaved ? 'saved' : '' ?>" data-id="<?= $v['id'] ?>" title="<?= t('fav_btn_title') ?>">
            <i data-lucide="heart" width="15" height="15" fill="<?= $isSaved?'#f43f5e':'none' ?>"></i>
        </button>
        <?php endif; ?>

        <div class="vac-card__head">
            <div class="vac-card__head-text">
                <a href="<?= BASE_URL ?>/pages/vacancy_detail.php?id=<?= $v['id'] ?>" class="vac-card__title">
                    <?= htmlspecialchars($v['title']) ?>
                </a>
                <div class="vac-card__company">
                    <i data-lucide="building-2" width="12" height="12" style="vertical-align:-2px;margin-right:5px;opacity:.7"></i>
                    <strong style="color:var(--text-primary);font-weight:600"><?= htmlspecialchars($cn) ?></strong>
                    <?php if ($v['location']): ?>
                    <span class="vac-card__sep">·</span>
                    <i data-lucide="map-pin" width="11" height="11" style="vertical-align:-1px;margin-right:3px;opacity:.7"></i>
                    <?= htmlspecialchars($v['location']) ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="vac-card__pills">
            <?php if ($v['employment_type']): ?>
            <span class="vac-pill <?= $pillClass ?>">
                <?php if (str_contains($tk,'remote')): ?>
                <i data-lucide="home" width="10" height="10"></i>
                <?php elseif (str_contains($tk,'full')): ?>
                <i data-lucide="briefcase" width="10" height="10"></i>
                <?php else: ?>
                <i data-lucide="clock" width="10" height="10"></i>
                <?php endif; ?>
                <?= htmlspecialchars($v['employment_type']) ?>
            </span>
            <?php endif; ?>
            <?php if ($role === 'employer' && isset($v['status'])): ?>
            <span class="vac-pill" style="background:var(--border-light);color:var(--text-secondary);border:1px solid var(--border)">
                <?= t('status_'.$v['status']) ?>
            </span>
            <?php endif; ?>
        </div>

        <?php if ($v['salary_min'] || $v['salary_max']): ?>
        <div class="vac-card__salary">
            <span style="color:#059669;font-size:13px">₸</span>
            <?php
            if ($v['salary_min'] && $v['salary_max'])
                echo number_format($v['salary_min'],0,'.','&thinsp;').' – '.number_format($v['salary_max'],0,'.','&thinsp;').' '.t('salary_per_month');
            elseif ($v['salary_min'])
                echo t('from_salary').' '.number_format($v['salary_min'],0,'.','&thinsp;').' '.t('salary_per_month');
            else
                echo t('to_salary').' '.number_format($v['salary_max'],0,'.','&thinsp;').' '.t('salary_per_month');
            ?>
        </div>
        <?php endif; ?>

        <div class="vac-card__footer">
            <span class="vac-card__time">
                <i data-lucide="clock" width="11" height="11" style="vertical-align:-1px;margin-right:3px"></i>
                <?= vacAgo($v['created_at']) ?>
                <?php if (!empty($v['expires_at'])): ?>
                &nbsp;·&nbsp;
                <i data-lucide="calendar" width="11" height="11" style="vertical-align:-1px;margin-right:2px"></i>
                <?= t('expires_until') ?> <?= date('d.m.Y', strtotime($v['expires_at'])) ?>
                <?php endif; ?>
            </span>
            <div style="display:flex;gap:7px;align-items:center">
                <?php if ($role === 'employee'): ?>
                    <?php if ($isApplied): ?>
                    <span class="vac-card__applied-badge">
                        <i data-lucide="check" width="12" height="12" stroke-width="2.5"></i>
                        <?= t('applied_badge') ?>
                    </span>
                    <?php else: ?>
                    <a href="<?= BASE_URL ?>/pages/vacancy_detail.php?id=<?= $v['id'] ?>"
                       class="btn btn-primary btn-sm" style="border-radius:10px;padding:7px 15px;font-size:12.5px">
                        <?= t('btn_apply') ?>
                        <i data-lucide="arrow-right" width="11" height="11" style="margin-left:3px"></i>
                    </a>
                    <?php endif; ?>
                <?php else: ?>
                <a href="<?= BASE_URL ?>/pages/vacancy_detail.php?id=<?= $v['id'] ?>"
                   class="btn btn-ghost btn-sm" style="border-radius:10px;font-size:12.5px"><?= t('btn_view') ?></a>
                <?php if ($v['employer_id'] == $uid): ?>
                <a href="<?= BASE_URL ?>/pages/vacancy_create.php?edit=<?= $v['id'] ?>"
                   class="btn btn-ghost btn-sm" style="border-radius:10px;font-size:12.5px"><?= t('btn_edit') ?></a>
                <?php $isHidden = $v['status'] === 'closed'; ?>
                <button class="btn btn-ghost btn-sm vac-hide-btn"
                        style="border-radius:10px;font-size:12.5px;color:<?= $isHidden?'#10b981':'var(--text-muted)' ?>"
                        data-id="<?= $v['id'] ?>" data-action="<?= $isHidden?'show':'hide' ?>">
                    <?php if ($isHidden): ?>
                    <i data-lucide="eye" width="12" height="12" style="margin-right:3px;vertical-align:-1px"></i><?= t('btn_show') ?>
                    <?php else: ?>
                    <i data-lucide="eye-off" width="12" height="12" style="margin-right:3px;vertical-align:-1px"></i><?= t('btn_hide') ?>
                    <?php endif; ?>
                </button>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        </div><!-- /.vac-card__content -->
    </div>
    <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- Pagination -->
    <?php if ($totalPages > 1):
        $pgBase = array_filter(array_merge($filterParams, ['tab' => $tab]));
    ?>
    <div class="vac-pagination">
        <?php
        $prev2 = null;
        for ($i = 1; $i <= $totalPages; $i++):
            if ($i !== 1 && $i !== $totalPages && abs($i - $page) > 2) {
                if ($prev2 !== null && abs($prev2 - $i) === 1) echo '<span style="color:var(--text-muted)">…</span>';
                $prev2 = $i; continue;
            }
            $pgUrl = BASE_URL.'/pages/vacancies.php?'.http_build_query(array_filter(array_merge($pgBase, ['page' => $i])));
        ?>
        <a href="<?= $pgUrl ?>" class="pg-btn <?= $i===$page?'active':'' ?>"><?= $i ?></a>
        <?php $prev2 = $i; endfor; ?>
    </div>
    <?php endif; ?>

</div><!-- /.vac-main -->
</div><!-- /.vac-page -->

<script>window.nexioPage = { base: '<?= addslashes(BASE_URL) ?>' };</script>
<script src="<?= BASE_URL ?>/assets/js/pages/vacancies.js?v=<?= asset_ver('assets/js/pages/vacancies.js') ?>"></script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
