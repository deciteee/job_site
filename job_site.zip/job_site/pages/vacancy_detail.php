<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

$uid  = $_SESSION['user_id'];
$role = $_SESSION['user_role'];
$id   = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id) { header('Location: ' . BASE_URL . '/pages/vacancies.php'); exit; }

// Load vacancy
$stmt = $conn->prepare(
    "SELECT v.*, u.name AS employer_name, u.company, u.email AS employer_email
     FROM vacancies v JOIN users u ON v.employer_id=u.id WHERE v.id=?"
);
$stmt->bind_param('i', $id); $stmt->execute();
$v = $stmt->get_result()->fetch_assoc(); $stmt->close();

if (!$v) { header('Location: ' . BASE_URL . '/pages/vacancies.php'); exit; }

// Check application status (exclude withdrawn so employee can re-apply)
$applied = false; $appStatus = '';
if ($role === 'employee') {
    $stmt = $conn->prepare("SELECT status FROM applications WHERE vacancy_id=? AND employee_id=? AND status != 'withdrawn'");
    $stmt->bind_param('ii', $id, $uid); $stmt->execute();
    $stmt->bind_result($appStatus); $stmt->fetch(); $stmt->close();
    $applied = !empty($appStatus);
}

// Vacancy expired?
$vacancyExpired = !empty($v['expires_at']) && $v['expires_at'] < date('Y-m-d');

// Applications list (for employer)
$applications = [];
if ($role === 'employer' && $v['employer_id'] == $uid) {
    $stmt = $conn->prepare(
        "SELECT a.id, a.status, a.applied_at, a.cover_letter,
                u.id AS uid, u.name, u.email, u.position
         FROM applications a JOIN users u ON a.employee_id=u.id
         WHERE a.vacancy_id=? ORDER BY a.applied_at DESC"
    );
    $stmt->bind_param('i', $id); $stmt->execute();
    $applications = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
}

$error = ''; $success = '';

// ── Apply ─────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {

    if ($_POST['action'] === 'apply' && $role === 'employee' && !$applied && !$vacancyExpired) {
        $letter = trim($_POST['cover_letter'] ?? '');
        $stmt = $conn->prepare(
            "INSERT IGNORE INTO applications (vacancy_id,employee_id,cover_letter) VALUES (?,?,?)"
        );
        $stmt->bind_param('iis', $id, $uid, $letter);
        if ($stmt->execute()) {
            $applied = true; $appStatus = 'pending';
            $success = t('apply_success_msg');

            // Auto-message to employer
            $empId   = $v['employer_id'];
            $vacName = $v['title'];
            $autoMsg = sprintf(t('auto_msg_apply'), $vacName);
            $stmt2 = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, content) VALUES (?,?,?)");
            $stmt2->bind_param('iis', $uid, $empId, $autoMsg);
            $stmt2->execute(); $stmt2->close();

            // Email notification to employer
            require_once __DIR__ . '/../includes/mailer.php';
            $vacUrl = BASE_URL . '/pages/vacancy_detail.php?id=' . $id;
            sendApplicationNotification(
                $v['employer_email'], $v['employer_name'],
                $_SESSION['user_name'], $vacName, $vacUrl
            );
        } else {
            $error = t('err_apply_fail');
        }
        $stmt->close();
    }

    // Update application status (employer)
    if ($_POST['action'] === 'update_status' && $role === 'employer' && $v['employer_id'] == $uid) {
        $appId    = (int)($_POST['app_id'] ?? 0);
        $newStatus = $_POST['new_status'] ?? '';
        $allowed  = ['pending','reviewed','accepted','rejected'];
        if ($appId && in_array($newStatus, $allowed)) {
            $stmt = $conn->prepare(
                "UPDATE applications a JOIN vacancies va ON a.vacancy_id=va.id
                 SET a.status=? WHERE a.id=? AND va.employer_id=?"
            );
            $stmt->bind_param('sii', $newStatus, $appId, $uid);
            $stmt->execute(); $stmt->close();
            header('Location: ' . BASE_URL . '/pages/vacancy_detail.php?id=' . $id . '&updated=1');
            exit;
        }
    }
}

$pageTitle = htmlspecialchars($v['title']);
include __DIR__ . '/../includes/header.php';
?>

<?php if (isset($_GET['created'])): ?>
    <div class="alert alert-success"><?= t('vac_published_msg') ?></div>
<?php endif; ?>
<?php if (isset($_GET['updated'])): ?>
    <div class="alert alert-success"><?= t('app_updated_msg') ?></div>
<?php endif; ?>
<?php if (isset($_GET['withdrawn'])): ?>
    <div class="alert alert-success"><?= t('app_withdrawn_ok') ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>
<?php if ($success): ?>
    <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<div class="page-header">
    <div>
        <a href="<?= BASE_URL ?>/pages/vacancies.php" class="back-link">&larr; <?= t('back_to_vacancies') ?></a>
        <h2 class="page-title"><?= htmlspecialchars($v['title']) ?></h2>
        <div class="page-meta">
            <span><?= htmlspecialchars($v['company'] ?: $v['employer_name']) ?></span>
            <?php if ($v['location']): ?><span class="meta-sep">·</span><span><?= htmlspecialchars($v['location']) ?></span><?php endif; ?>
            <span class="meta-sep">·</span>
            <span class="tag"><?= htmlspecialchars($v['employment_type']) ?></span>
            <span class="badge badge-<?= $v['status']==='active'?'success':'danger' ?>"><?= t('status_'.$v['status']) ?></span>
        </div>
    </div>
    <?php if ($role === 'employer' && $v['employer_id'] == $uid): ?>
        <a href="<?= BASE_URL ?>/pages/vacancy_create.php?edit=<?= $v['id'] ?>" class="btn btn-ghost"><?= t('edit_vacancy') ?></a>
    <?php endif; ?>
</div>

<div class="detail-layout">
    <!-- ── Left: vacancy info ── -->
    <div class="detail-main">
        <div class="card">
            <div class="card__header">
                <h3 class="card__title"><?= t('about_role') ?></h3>
            </div>
            <div class="card__body">
                <div class="prose"><?= nl2br(htmlspecialchars($v['description'])) ?></div>

                <?php if ($v['requirements']): ?>
                <h4 class="section-heading"><?= t('requirements') ?></h4>
                <div class="prose"><?= nl2br(htmlspecialchars($v['requirements'])) ?></div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ── Apply form (employee) ── -->
        <?php if ($role === 'employee'): ?>
            <div class="card">
                <div class="card__header">
                    <h3 class="card__title"><?= t('apply_for_position') ?></h3>
                </div>
                <div class="card__body">
                    <?php if ($applied): ?>
                        <div class="applied-state">
                            <i data-lucide="circle-check" width="32" height="32" style="color:#16a34a"></i>
                            <div>
                                <strong><?= t('application_submitted') ?></strong>
                                <p><?= t('col_status') ?>: <span class="badge badge-<?= match($appStatus) {
                                    'accepted'=>'success','rejected'=>'danger','reviewed'=>'blue',default=>'warning'} ?>">
                                    <?= t('status_'.$appStatus) ?></span>
                                </p>
                            </div>
                        </div>
                        <?php if ($appStatus === 'pending'): ?>
                        <form method="POST" action="<?= BASE_URL ?>/pages/api/withdraw_application.php"
                              style="margin-top:14px"
                              onsubmit="return confirm('<?= t('withdraw_confirm') ?>')">
                            <input type="hidden" name="vacancy_id" value="<?= $id ?>">
                            <button type="submit" class="btn btn-ghost" style="font-size:13px;color:var(--danger);border-color:rgba(220,38,38,.25)">
                                <i data-lucide="x" width="14" height="14" style="margin-right:5px"></i>
                                <?= t('btn_withdraw_app') ?>
                            </button>
                        </form>
                        <?php endif; ?>
                    <?php elseif ($v['status'] !== 'active' || $vacancyExpired): ?>
                        <p class="text-muted"><?= t('app_no_longer_active') ?></p>
                    <?php else: ?>
                        <form method="POST" novalidate>
                            <input type="hidden" name="action" value="apply">
                            <div class="form-group">
                                <label class="form-label" for="cover_letter"><?= t('cover_letter') ?> <span class="text-muted">(<?= t('cover_letter_optional') ?>)</span></label>
                                <textarea class="form-control" id="cover_letter" name="cover_letter"
                                          rows="5" placeholder="<?= t('cover_letter_hint') ?>"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary btn-lg"><?= t('submit_application') ?></button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- ── Applications list (employer) ── -->
        <?php if ($role === 'employer' && $v['employer_id'] == $uid): ?>
        <style>
        /* ── Application cards ──────────────────────────────── */
        .app-list { display: flex; flex-direction: column; gap: 14px; }

        .app-card {
            background: var(--card-bg); border: 1.5px solid var(--border);
            border-radius: 18px; overflow: hidden;
            transition: box-shadow .2s, border-color .2s, transform .2s;
        }
        .app-card:hover { box-shadow: 0 8px 28px rgba(0,0,0,.09); transform: translateY(-1px); }
        .app-card--accepted { border-color: rgba(16,185,129,.4); }
        .app-card--rejected { border-color: rgba(239,68,68,.3); }
        .app-card--reviewed { border-color: rgba(37,99,235,.35); }

        .app-card__top {
            display: flex; align-items: center; gap: 14px;
            padding: 16px 18px; flex-wrap: wrap;
        }
        .app-card__ava {
            width: 46px; height: 46px; border-radius: 13px; flex-shrink: 0;
            display: flex; align-items: center; justify-content: center;
            font-size: 16px; font-weight: 800; color: #fff; overflow: hidden;
        }
        .app-card__ava img { width: 100%; height: 100%; object-fit: cover; }
        .app-card__info { flex: 1; min-width: 0; }
        .app-card__name { font-size: 15px; font-weight: 700; color: var(--text-primary); margin-bottom: 2px; }
        .app-card__sub  { font-size: 12.5px; color: var(--text-secondary); display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
        .app-card__time { font-size: 12px; color: var(--text-muted); display: flex; align-items: center; gap: 4px; white-space: nowrap; }

        .app-status-badge {
            display: inline-flex; align-items: center; gap: 5px;
            padding: 5px 12px; border-radius: 100px; font-size: 12px; font-weight: 700;
            white-space: nowrap;
        }
        .app-status-badge--pending  { background: rgba(245,158,11,.12); color: #d97706; border: 1.5px solid rgba(245,158,11,.25); }
        .app-status-badge--reviewed { background: rgba(37,99,235,.10);  color: #2563eb; border: 1.5px solid rgba(37,99,235,.25); }
        .app-status-badge--accepted { background: rgba(16,185,129,.12); color: #059669; border: 1.5px solid rgba(16,185,129,.25); }
        .app-status-badge--rejected { background: rgba(239,68,68,.10);  color: #dc2626; border: 1.5px solid rgba(239,68,68,.22); }

        /* ── Cover letter block ─────────────────────────────── */
        .app-card__letter-toggle {
            display: flex; align-items: center; gap: 6px;
            padding: 10px 18px; border-top: 1px solid var(--border-light);
            background: var(--body-bg); cursor: pointer;
            font-size: 13px; font-weight: 500; color: var(--primary);
            border: none; width: 100%; text-align: left;
            transition: background .15s;
        }
        .app-card__letter-toggle:hover { background: rgba(37,99,235,.05); }
        .app-card__letter-toggle svg { transition: transform .2s; flex-shrink: 0; }
        .app-card__letter-toggle.open svg { transform: rotate(180deg); }

        .app-card__letter-body {
            display: none; padding: 16px 18px;
            border-top: 1px solid var(--border-light);
            background: var(--body-bg);
        }
        .app-card__letter-body.open { display: block; }
        .app-card__letter-text {
            font-size: 13.5px; color: var(--text-secondary); line-height: 1.7;
            white-space: pre-wrap; word-break: break-word;
            background: var(--card-bg); border: 1.5px solid var(--border);
            border-radius: 12px; padding: 14px 16px;
            border-left: 3px solid var(--primary);
        }

        /* ── Action buttons row ─────────────────────────────── */
        .app-card__actions {
            display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
            padding: 12px 18px; border-top: 1px solid var(--border-light);
            background: var(--card-bg);
        }
        .app-action-btn {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 7px 14px; border-radius: 10px; font-size: 13px; font-weight: 600;
            border: 1.5px solid transparent; cursor: pointer; transition: all .15s;
            text-decoration: none; white-space: nowrap;
        }
        .app-action-btn:hover { transform: translateY(-1px); text-decoration: none; }
        .app-action-btn:active { transform: translateY(0); }

        .app-action-btn--accept {
            background: rgba(16,185,129,.1); color: #059669;
            border-color: rgba(16,185,129,.3);
        }
        .app-action-btn--accept:hover { background: rgba(16,185,129,.18); border-color: rgba(16,185,129,.5); color: #059669; }
        .app-action-btn--accept.active {
            background: #10b981; color: #fff; border-color: #10b981;
            box-shadow: 0 4px 14px rgba(16,185,129,.35);
        }

        .app-action-btn--review {
            background: rgba(37,99,235,.08); color: #2563eb;
            border-color: rgba(37,99,235,.25);
        }
        .app-action-btn--review:hover { background: rgba(37,99,235,.15); border-color: rgba(37,99,235,.4); color: #2563eb; }
        .app-action-btn--review.active {
            background: #2563eb; color: #fff; border-color: #2563eb;
            box-shadow: 0 4px 14px rgba(37,99,235,.35);
        }

        .app-action-btn--reject {
            background: rgba(239,68,68,.08); color: #dc2626;
            border-color: rgba(239,68,68,.22);
        }
        .app-action-btn--reject:hover { background: rgba(239,68,68,.15); border-color: rgba(239,68,68,.4); color: #dc2626; }
        .app-action-btn--reject.active {
            background: #ef4444; color: #fff; border-color: #ef4444;
            box-shadow: 0 4px 14px rgba(239,68,68,.3);
        }

        .app-action-btn--msg {
            background: transparent; color: var(--text-secondary);
            border-color: var(--border); margin-left: auto;
        }
        .app-action-btn--msg:hover { background: var(--border-light); color: var(--text-primary); border-color: var(--border); }

        .app-saving { font-size: 12px; color: var(--text-muted); display: none; align-items: center; gap: 4px; }
        .app-saving.show { display: inline-flex; }

        /* ── Stat strip ─────────────────────────────────────── */
        .app-stats-strip {
            display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 16px;
        }
        .app-stats-chip {
            display: flex; align-items: center; gap: 7px;
            background: var(--card-bg); border: 1.5px solid var(--border);
            border-radius: 12px; padding: 8px 14px; font-size: 13px;
        }
        .app-stats-chip__dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
        .app-stats-chip__val { font-weight: 700; color: var(--text-primary); }
        .app-stats-chip__lbl { color: var(--text-muted); }
        </style>

        <?php
        // Count by status
        $cntPending  = count(array_filter($applications, fn($a) => $a['status'] === 'pending'));
        $cntReviewed = count(array_filter($applications, fn($a) => $a['status'] === 'reviewed'));
        $cntAccepted = count(array_filter($applications, fn($a) => $a['status'] === 'accepted'));
        $cntRejected = count(array_filter($applications, fn($a) => $a['status'] === 'rejected'));
        function appGrad(string $name): string {
            $p=[['#3b82f6','#1d4ed8'],['#8b5cf6','#6d28d9'],['#ec4899','#be185d'],
                ['#10b981','#047857'],['#f59e0b','#b45309'],['#06b6d4','#0e7490'],
                ['#ef4444','#b91c1c'],['#6366f1','#4338ca']];
            $i = ord($name[0] ?? 'A') % count($p);
            return "linear-gradient(135deg,{$p[$i][0]},{$p[$i][1]})";
        }
        ?>

        <div class="card">
            <div class="card__header">
                <h3 class="card__title"><?= t('apps_card_title') ?> <span style="color:var(--text-muted);font-weight:500">(<?= count($applications) ?>)</span></h3>
            </div>
            <div class="card__body">
            <?php if (empty($applications)): ?>
                <div style="text-align:center;padding:40px 20px">
                    <div style="margin-bottom:10px;color:var(--text-muted)"><i data-lucide="inbox" width="40" height="40" stroke-width="1.5"></i></div>
                    <div style="font-size:15px;font-weight:600;color:var(--text-primary);margin-bottom:5px"><?= t('no_apps_yet_title') ?></div>
                    <div style="font-size:13px;color:var(--text-muted)"><?= t('no_apps_yet_desc') ?></div>
                </div>
            <?php else: ?>

                <!-- Stats strip -->
                <div class="app-stats-strip">
                    <div class="app-stats-chip">
                        <span class="app-stats-chip__dot" style="background:#f59e0b"></span>
                        <span class="app-stats-chip__val"><?= $cntPending ?></span>
                        <span class="app-stats-chip__lbl"><?= t('apps_stat_new') ?></span>
                    </div>
                    <div class="app-stats-chip">
                        <span class="app-stats-chip__dot" style="background:#3b82f6"></span>
                        <span class="app-stats-chip__val"><?= $cntReviewed ?></span>
                        <span class="app-stats-chip__lbl"><?= t('apps_stat_reviewed') ?></span>
                    </div>
                    <div class="app-stats-chip">
                        <span class="app-stats-chip__dot" style="background:#10b981"></span>
                        <span class="app-stats-chip__val"><?= $cntAccepted ?></span>
                        <span class="app-stats-chip__lbl"><?= t('apps_stat_accepted') ?></span>
                    </div>
                    <div class="app-stats-chip">
                        <span class="app-stats-chip__dot" style="background:#ef4444"></span>
                        <span class="app-stats-chip__val"><?= $cntRejected ?></span>
                        <span class="app-stats-chip__lbl"><?= t('apps_stat_rejected') ?></span>
                    </div>
                </div>

                <!-- Cards -->
                <div class="app-list">
                <?php foreach ($applications as $a):
                    $st   = $a['status'];
                    $grad = appGrad($a['name']);
                    $init = mb_strtoupper(mb_substr($a['name'], 0, 1));
                    $ago  = (function($ts) {
                        $d = time() - strtotime($ts);
                        if ($d < 60)     return t('time_just_now');
                        if ($d < 3600)   return floor($d/60).' '.t('time_min_ago');
                        if ($d < 86400)  return floor($d/3600).' '.t('time_hr_ago');
                        if ($d < 604800) return floor($d/86400).' '.t('time_day_ago');
                        return date('d M Y', strtotime($ts));
                    })($a['applied_at']);
                    $stLabel = ['pending'=>t('app_label_new'),'reviewed'=>t('app_label_reviewed'),'accepted'=>t('app_label_accepted'),'rejected'=>t('app_label_rejected')][$st] ?? $st;
                ?>
                <div class="app-card app-card--<?= $st ?>" id="appcard-<?= $a['id'] ?>">

                    <!-- Top row: avatar + info + status badge -->
                    <div class="app-card__top">
                        <div class="app-card__ava" style="background:<?= $grad ?>"><?= $init ?></div>
                        <div class="app-card__info">
                            <div class="app-card__name"><?= htmlspecialchars($a['name']) ?></div>
                            <div class="app-card__sub">
                                <span><?= htmlspecialchars($a['email']) ?></span>
                                <?php if ($a['position']): ?>
                                <span style="color:var(--border)">·</span>
                                <span><?= htmlspecialchars($a['position']) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:6px;flex-shrink:0">
                            <span class="app-status-badge app-status-badge--<?= $st ?>" id="badge-<?= $a['id'] ?>">
                                <?php $stIcon = match($st) {
                                    'accepted' => 'check',
                                    'rejected' => 'x',
                                    'reviewed' => 'eye',
                                    default    => 'clock'
                                }; ?>
                                <i data-lucide="<?= $stIcon ?>" width="13" height="13"></i>
                                <?= $stLabel ?>
                            </span>
                            <div class="app-card__time">
                                <i data-lucide="clock" width="11" height="11"></i>
                                <?= $ago ?>
                            </div>
                        </div>
                    </div>

                    <!-- Cover letter toggle -->
                    <?php if ($a['cover_letter']): ?>
                    <button class="app-card__letter-toggle" onclick="toggleLetter(this, <?= $a['id'] ?>)">
                        <i data-lucide="mail" width="14" height="14"></i>
                        <?= t('cover_letter') ?>
                        <i data-lucide="chevron-down" width="13" height="13" style="margin-left:auto"></i>
                    </button>
                    <div class="app-card__letter-body" id="letter-<?= $a['id'] ?>">
                        <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--text-muted);margin-bottom:8px"><?= t('cover_letter_card') ?></div>
                        <div class="app-card__letter-text"><?= htmlspecialchars($a['cover_letter']) ?></div>
                        <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">
                            <a href="<?= BASE_URL ?>/pages/resume_view.php?id=<?= $a['uid'] ?>"
                               class="app-action-btn" style="border-color:rgba(37,99,235,.25);color:#2563eb;background:rgba(37,99,235,.07);font-size:12px;padding:5px 12px">
                                <i data-lucide="file-text" width="12" height="12"></i>
                                <?= t('resume_of_candidate') ?>
                            </a>
                        </div>
                    </div>
                    <?php else: ?>
                    <div style="padding:8px 18px;border-top:1px solid var(--border-light);font-size:12.5px;color:var(--text-muted);display:flex;align-items:center;gap:6px;background:var(--body-bg)">
                        <i data-lucide="mail" width="12" height="12"></i>
                        <?= t('no_cover_letter_text') ?>
                        &nbsp;·&nbsp;
                        <a href="<?= BASE_URL ?>/pages/resume_view.php?id=<?= $a['uid'] ?>" style="color:var(--primary);font-weight:600"><?= t('resume_arrow') ?></a>
                    </div>
                    <?php endif; ?>

                    <!-- Action buttons -->
                    <div class="app-card__actions">
                        <button class="app-action-btn app-action-btn--accept <?= $st==='accepted'?'active':'' ?>"
                                onclick="setStatus(<?= $a['id'] ?>, 'accepted', this)">
                            <i data-lucide="check" width="13" height="13" stroke-width="2.5"></i>
                            <?= t('btn_accept') ?>
                        </button>
                        <button class="app-action-btn app-action-btn--review <?= $st==='reviewed'?'active':'' ?>"
                                onclick="setStatus(<?= $a['id'] ?>, 'reviewed', this)">
                            <i data-lucide="eye" width="13" height="13" stroke-width="2.5"></i>
                            <?= t('btn_in_review') ?>
                        </button>
                        <button class="app-action-btn app-action-btn--reject <?= $st==='rejected'?'active':'' ?>"
                                onclick="setStatus(<?= $a['id'] ?>, 'rejected', this)">
                            <i data-lucide="x" width="13" height="13" stroke-width="2.5"></i>
                            <?= t('btn_reject') ?>
                        </button>
                        <span class="app-saving" id="saving-<?= $a['id'] ?>">
                            <i data-lucide="loader-circle" width="12" height="12"></i>
                            <?= t('saving_text') ?>
                        </span>
                        <a href="<?= BASE_URL ?>/pages/chat.php?with=<?= $a['uid'] ?>"
                           class="app-action-btn app-action-btn--msg">
                            <i data-lucide="message-square" width="13" height="13"></i>
                            <?= t('btn_message') ?>
                        </a>
                    </div>

                </div>
                <?php endforeach; ?>
                </div>

            <?php endif; ?>
            </div>
        </div>

        <script>
        window.nexioPage = {
            base: '<?= addslashes(BASE_URL) ?>',
            i18n: {
                accepted: <?= json_encode(t('app_label_accepted')) ?>,
                rejected: <?= json_encode(t('app_label_rejected')) ?>,
                reviewed: <?= json_encode(t('app_label_reviewed')) ?>,
                pending:  <?= json_encode(t('app_label_new')) ?>
            }
        };
        </script>
        <script src="<?= BASE_URL ?>/assets/js/pages/vacancy-detail.js?v=<?= asset_ver('assets/js/pages/vacancy-detail.js') ?>"></script>
        <?php endif; ?>
    </div>

    <!-- ── Right: sidebar info ── -->
    <aside class="detail-sidebar">
        <div class="card">
            <div class="card__header"><h3 class="card__title"><?= t('job_overview') ?></h3></div>
            <div class="card__body">
                <dl class="info-list">
                    <dt><?= t('employment_type') ?></dt>
                    <dd><?= t('type_' . str_replace('-','_',$v['employment_type'])) ?></dd>
                    <?php if ($v['location']): ?>
                    <dt><?= t('col_location') ?></dt>
                    <dd><?= htmlspecialchars($v['location']) ?></dd>
                    <?php endif; ?>
                    <?php if ($v['salary_min'] || $v['salary_max']): ?>
                    <dt><?= t('salary') ?></dt>
                    <dd>
                        <?php
                        if ($v['salary_min'] && $v['salary_max'])
                            echo number_format($v['salary_min'],0,'.','&nbsp;') . ' – ' . number_format($v['salary_max'],0,'.','&nbsp;') . ' ₸';
                        elseif ($v['salary_min'])
                            echo t('from_salary') . ' ' . number_format($v['salary_min'],0,'.','&nbsp;') . ' ₸';
                        else
                            echo t('to_salary') . ' ' . number_format($v['salary_max'],0,'.','&nbsp;') . ' ₸';
                        ?>
                    </dd>
                    <?php endif; ?>
                    <dt><?= t('posted') ?></dt>
                    <dd><?= date('d M Y', strtotime($v['created_at'])) ?></dd>
                    <?php if (!empty($v['expires_at'])): ?>
                    <dt><?= t('expires_date_label') ?></dt>
                    <dd>
                        <?php if ($vacancyExpired): ?>
                            <span class="badge badge-danger"><?= t('vacancy_expired_badge') ?> <?= date('d.m.Y', strtotime($v['expires_at'])) ?></span>
                        <?php else:
                            $daysLeft = (int)ceil((strtotime($v['expires_at']) - time()) / 86400);
                        ?>
                            <?= date('d.m.Y', strtotime($v['expires_at'])) ?>
                            <span style="font-size:11px;color:var(--text-muted)">(<?= t('expires_days_left') ?> <?= $daysLeft ?> <?= t('expires_days_unit') ?>)</span>
                        <?php endif; ?>
                    </dd>
                    <?php endif; ?>
                    <dt><?= t('col_status') ?></dt>
                    <dd>
                        <span class="badge badge-<?= ($v['status']==='active' && !$vacancyExpired)?'success':'danger' ?>">
                            <?= $vacancyExpired ? t('vacancy_expired_badge') : t('status_'.$v['status']) ?>
                        </span>
                    </dd>
                </dl>
            </div>
        </div>

        <div class="card">
            <div class="card__header"><h3 class="card__title"><?= t('company') ?></h3></div>
            <div class="card__body">
                <div class="company-block">
                    <div class="company-logo"><?= strtoupper(substr($v['employer_name'],0,2)) ?></div>
                    <div>
                        <div class="company-name"><?= htmlspecialchars($v['company'] ?: $v['employer_name']) ?></div>
                        <div class="company-contact">
                            <a href="<?= BASE_URL ?>/pages/chat.php?with=<?= $v['employer_id'] ?>" class="btn btn-outline btn-sm">
                                <?= t('send_message') ?>
                            </a>
                            <?php if (!empty($v['contact_phone'])): ?>
                            <a href="tel:<?= htmlspecialchars($v['contact_phone']) ?>"
                               class="btn btn-outline btn-sm"
                               style="margin-top:8px;display:flex;align-items:center;gap:6px">
                                <i data-lucide="phone" width="14" height="14"></i>
                                <?= htmlspecialchars($v['contact_phone']) ?>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </aside>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
