<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/i18n.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/pages/dashboard.php');
    exit;
}

$error   = '';
$notice  = '';
$pendingEmail = '';

// Banners from registration / verification flow
if (isset($_GET['registered'])) {
    $notice = '📬 ' . t('notice_email_sent') . ' <strong>' . htmlspecialchars($_GET['email'] ?? '') . '</strong>. ' . t('notice_check_inbox');
}
if (isset($_GET['verified'])) {
    $notice = t('notice_email_verified');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action   = $_POST['action'] ?? 'login';
    $email    = trim($_POST['email']    ?? '');
    $password = trim($_POST['password'] ?? '');

    // Resend verification email
    if ($action === 'resend') {
        $stmt = $conn->prepare("SELECT id, name, status, verify_token FROM users WHERE email=?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $u = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($u && $u['status'] === 'pending') {
            $newToken = bin2hex(random_bytes(32));
            $upd = $conn->prepare("UPDATE users SET verify_token=? WHERE id=?");
            $upd->bind_param('si', $newToken, $u['id']); $upd->execute(); $upd->close();
            require_once __DIR__ . '/../includes/mailer.php';
            sendVerificationEmail($email, $u['name'], $newToken);
            $notice = '📬 ' . t('notice_email_resent') . ' <strong>' . htmlspecialchars($email) . '</strong>.';
        } else {
            $notice = t('notice_already_verified');
        }
    }

    // Normal login
    if ($action === 'login') {
        if (!$email || !$password) {
            $error = t('err_fill_all');
        } else {
            $stmt = $conn->prepare("SELECT id, name, email, password, role, status, avatar FROM users WHERE email = ?");
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($user && password_verify($password, $user['password'])) {
                if (($user['status'] ?? 'active') === 'pending') {
                    $pendingEmail = $email;
                    $error = t('err_account_pending');
                } else {
                    $_SESSION['user_id']     = $user['id'];
                    $_SESSION['user_name']   = $user['name'];
                    $_SESSION['user_role']   = $user['role'];
                    $_SESSION['user_email']  = $user['email'];
                    $_SESSION['user_avatar'] = $user['avatar'] ?? null;
                    $redirect = $user['role'] === 'admin'
                        ? BASE_URL . '/pages/admin.php'
                        : BASE_URL . '/pages/dashboard.php';
                    header('Location: ' . $redirect);
                    exit;
                }
            } else {
                $error = t('err_login_fail');
            }
        }
    }
}

$langBase = '?setlang=';
$currentParams = array_diff_key($_GET, ['setlang' => '']);
$paramStr = $currentParams ? '&' . http_build_query($currentParams) : '';
?>
<!DOCTYPE html>
<html lang="<?= currentLang() === 'kz' ? 'kk' : 'ru' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= t('sign_in') ?> — <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <script>(function(){var t=localStorage.getItem('nexio-theme')||'light';document.documentElement.setAttribute('data-theme',t);})()</script>
</head>
<body class="auth-body">

<div class="auth-layout">

    <!-- Lang + Theme controls -->
    <div class="auth-controls">
        <div class="lang-dropdown" id="langDropdownAuth">
            <button class="lang-dropdown__trigger" type="button"
                    onclick="document.getElementById('langDropdownAuth').classList.toggle('open')">
                <i data-lucide="globe" width="13" height="13"></i>
                <?= strtoupper(currentLang()) ?>
                <i data-lucide="chevron-down" width="10" height="10"></i>
            </button>
            <div class="lang-dropdown__menu">
                <a href="<?= $langBase ?>ru<?= $paramStr ?>" class="lang-dropdown__item <?= currentLang()==='ru'?'active':'' ?>">Русский</a>
                <a href="<?= $langBase ?>kz<?= $paramStr ?>" class="lang-dropdown__item <?= currentLang()==='kz'?'active':'' ?>">Қазақша</a>
                <a href="<?= $langBase ?>en<?= $paramStr ?>" class="lang-dropdown__item <?= currentLang()==='en'?'active':'' ?>">English</a>
            </div>
        </div>
        <button class="theme-btn" data-action="theme" title="Toggle theme">
            <i data-lucide="moon" width="14" height="14"></i>
        </button>
    </div>

    <!-- Form panel -->
    <div class="auth-panel">
        <div class="auth-brand">
            <a href="<?= BASE_URL ?>/" style="display:flex;align-items:center;text-decoration:none;color:inherit;">
                <svg viewBox="0 0 105 32" fill="none" height="28">
                    <defs>
                        <linearGradient id="nexio-g-login" x1="0" y1="0" x2="1" y2="1">
                            <stop offset="0%" stop-color="#60a5fa"/>
                            <stop offset="100%" stop-color="#2563eb"/>
                        </linearGradient>
                    </defs>
                    <path d="M4 27V7L22 27V7" stroke="url(#nexio-g-login)" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
                    <circle cx="22" cy="2.5" r="3" fill="#3b82f6"/>
                    <text x="32" y="24" font-family="-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif"
                          font-size="21" font-weight="800" fill="currentColor" letter-spacing="-0.3">exio</text>
                </svg>
            </a>
        </div>

        <h1 class="auth-title"><?= t('welcome_back') ?></h1>
        <p class="auth-subtitle"><?= t('sign_in_subtitle') ?></p>

        <?php if ($notice): ?>
            <div class="alert alert-success" style="margin-bottom:14px"><?= $notice ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-error" style="margin-bottom:4px"><?= htmlspecialchars($error) ?></div>
            <?php if ($pendingEmail): ?>
            <form method="POST" style="margin-bottom:14px">
                <input type="hidden" name="action" value="resend">
                <input type="hidden" name="email" value="<?= htmlspecialchars($pendingEmail) ?>">
                <button type="submit" style="background:none;border:none;padding:0;cursor:pointer;font-size:13px;color:var(--primary);text-decoration:underline">
                    <?= t('resend_email_btn') ?>
                </button>
            </form>
            <?php endif; ?>
        <?php endif; ?>

        <form method="POST" class="auth-form" novalidate>
            <input type="hidden" name="action" value="login">
            <div class="form-group">
                <label class="form-label" for="email"><?= t('email') ?></label>
                <input class="form-control" type="email" id="email" name="email"
                       value="<?= htmlspecialchars($_POST['email'] ?? $_GET['email'] ?? '') ?>"
                       placeholder="you@company.com" required autofocus>
            </div>
            <div class="form-group">
                <label class="form-label" for="password" style="display:flex;justify-content:space-between;align-items:center">
                    <?= t('password') ?>
                    <a href="<?= BASE_URL ?>/pages/forgot_password.php" style="font-size:12px;font-weight:500;color:var(--text-muted)"><?= t('forgot_password_link') ?></a>
                </label>
                <input class="form-control" type="password" id="password" name="password"
                       placeholder="••••••••" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block btn-lg"><?= t('sign_in') ?></button>
        </form>

        <div class="auth-footer">
            <?= t('no_account') ?>
            <a href="<?= BASE_URL ?>/pages/register.php"><?= t('create_account') ?></a>
        </div>

        <div class="auth-demo-box">
            <div class="auth-demo-box__title"><?= t('demo_credentials') ?></div>
            <div class="auth-demo-row">
                <span class="badge badge-blue"><?= t('employer') ?></span>
                <code>employer@demo.com</code> / <code>password</code>
            </div>
            <div class="auth-demo-row">
                <span class="badge badge-green"><?= t('employee') ?></span>
                <code>ivan@demo.com</code> / <code>password</code>
            </div>
        </div>
    </div>

    <!-- Visual panel -->
    <div class="auth-visual">
        <div class="auth-visual__content">
            <h2><?= t('auth_visual_login') ?></h2>
            <ul class="auth-features-list">
                <li><?= t('auth_feat_1') ?></li>
                <li><?= t('auth_feat_2') ?></li>
                <li><?= t('auth_feat_3') ?></li>
                <li><?= t('auth_feat_4') ?></li>
            </ul>
        </div>
    </div>

</div>

<script src="<?= BASE_URL ?>/assets/js/lucide.min.js?v=<?= asset_ver('assets/js/lucide.min.js') ?>"></script>
<script src="<?= BASE_URL ?>/assets/js/app.js?v=<?= asset_ver('assets/js/app.js') ?>"></script>
</body>
</html>
