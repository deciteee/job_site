<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

if (!isEmployee()) {
    header('Location: ' . BASE_URL . '/pages/dashboard.php');
    exit;
}

$uid = (int)$_SESSION['user_id'];

// Load user info
$userRow = $conn->query("SELECT name, email, position, phone, bio, company, avatar FROM users WHERE id=$uid")->fetch_assoc();

// Load resume
$resume = $conn->query("SELECT * FROM resumes WHERE user_id=$uid")->fetch_assoc();

// Load experiences
$exps = $conn->query("SELECT * FROM resume_experiences WHERE user_id=$uid ORDER BY sort_order, id DESC")->fetch_all(MYSQLI_ASSOC);

// Load educations
$edus = $conn->query("SELECT * FROM resume_educations WHERE user_id=$uid ORDER BY sort_order, id DESC")->fetch_all(MYSQLI_ASSOC);

// Load files
$files = $conn->query("SELECT * FROM resume_files WHERE user_id=$uid ORDER BY uploaded_at DESC")->fetch_all(MYSQLI_ASSOC);

// Skills as array
$skillsList = $resume ? array_filter(array_map('trim', explode(',', $resume['skills'] ?? ''))) : [];

$pageTitle = t('my_resume_title');
include __DIR__ . '/../includes/header.php';
?>

<style>
/* ── Layout ─────────────────────────────────────────── */
.res-layout { display: grid; grid-template-columns: 1fr 380px; gap: 24px; align-items: start; }
@media (max-width: 900px) { .res-layout { grid-template-columns: 1fr; } }

/* ── Section card ────────────────────────────────── */
.res-card {
    background: var(--card-bg); border: 1.5px solid var(--border);
    border-radius: 20px; overflow: hidden; margin-bottom: 20px;
}
.res-card__head {
    display: flex; align-items: center; justify-content: space-between;
    padding: 18px 22px 16px; border-bottom: 1px solid var(--border-light);
}
.res-card__title {
    display: flex; align-items: center; gap: 10px;
    font-size: 15px; font-weight: 700; color: var(--text-primary);
}
.res-card__icon {
    width: 32px; height: 32px; border-radius: 9px;
    display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.res-card__body { padding: 20px 22px; }

/* ── Hero / profile card ─────────────────────────── */
.res-hero {
    background: linear-gradient(135deg, #1e3a5f 0%, #0f172a 100%);
    border-radius: 20px; padding: 28px 26px; margin-bottom: 20px;
    display: flex; align-items: center; gap: 20px; position: relative; overflow: hidden;
}
.res-hero::before {
    content: ''; position: absolute; top: -40px; right: -40px;
    width: 200px; height: 200px; border-radius: 50%;
    background: rgba(59,130,246,.15); pointer-events: none;
}
.res-hero__avatar {
    width: 72px; height: 72px; border-radius: 18px; flex-shrink: 0;
    background: linear-gradient(135deg,#3b82f6,#1d4ed8);
    display: flex; align-items: center; justify-content: center;
    font-size: 22px; font-weight: 800; color: #fff; overflow: hidden;
    border: 3px solid rgba(255,255,255,.15); box-shadow: 0 4px 16px rgba(0,0,0,.3);
}
.res-hero__avatar img { width: 100%; height: 100%; object-fit: cover; }
.res-hero__name { font-size: 20px; font-weight: 800; color: #fff; margin-bottom: 3px; }
.res-hero__pos  { font-size: 13.5px; color: #93c5fd; margin-bottom: 10px; }
.res-hero__meta { display: flex; flex-wrap: wrap; gap: 10px; }
.res-hero__chip {
    display: inline-flex; align-items: center; gap: 5px;
    font-size: 12px; color: #cbd5e1; background: rgba(255,255,255,.08);
    border: 1px solid rgba(255,255,255,.12); border-radius: 100px; padding: 4px 11px;
}

/* ── Skill tags ──────────────────────────────────── */
.skills-wrap { display: flex; flex-wrap: wrap; gap: 8px; }
.skill-tag {
    display: inline-flex; align-items: center; gap: 6px;
    background: rgba(37,99,235,.09); color: #2563eb;
    border: 1.5px solid rgba(37,99,235,.2); border-radius: 100px;
    padding: 5px 13px; font-size: 13px; font-weight: 500;
}
.skill-tag__del {
    background: none; border: none; padding: 0; cursor: pointer;
    color: #2563eb; opacity: .6; line-height: 1; font-size: 14px;
    display: flex; align-items: center;
}
.skill-tag__del:hover { opacity: 1; }
.skill-input-wrap { display: flex; gap: 8px; margin-top: 10px; }
.skill-input-wrap input { flex: 1; }

/* ── Experience / Education items ────────────────── */
.exp-list { display: flex; flex-direction: column; gap: 14px; }
.exp-item {
    background: var(--body-bg); border: 1.5px solid var(--border);
    border-radius: 14px; padding: 16px 18px; position: relative;
}
.exp-item__head { display: flex; align-items: flex-start; gap: 10px; margin-bottom: 10px; }
.exp-item__dot {
    width: 36px; height: 36px; border-radius: 10px; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center;
}
.exp-item__title { font-size: 14.5px; font-weight: 700; color: var(--text-primary); }
.exp-item__sub   { font-size: 12.5px; color: var(--text-secondary); margin-top: 2px; }
.exp-item__del {
    position: absolute; top: 12px; right: 14px;
    background: none; border: none; cursor: pointer; color: var(--text-muted);
    padding: 4px; border-radius: 6px; transition: color .15s, background .15s;
}
.exp-item__del:hover { color: #ef4444; background: rgba(239,68,68,.1); }

/* ── Add block ───────────────────────────────────── */
.add-block {
    border: 2px dashed var(--border); border-radius: 14px;
    padding: 18px; display: none; margin-top: 14px;
}
.add-block.open { display: block; }
.add-block__grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
@media (max-width: 600px) { .add-block__grid { grid-template-columns: 1fr; } }

/* ── File upload area ────────────────────────────── */
.file-drop {
    border: 2px dashed var(--border); border-radius: 14px; padding: 28px 20px;
    text-align: center; cursor: pointer; transition: border-color .15s, background .15s;
    position: relative;
}
.file-drop:hover, .file-drop.drag { border-color: var(--primary); background: rgba(37,99,235,.04); }
.file-drop input[type=file] { position: absolute; inset: 0; opacity: 0; cursor: pointer; }
.file-drop__icon { font-size: 32px; margin-bottom: 8px; }
.file-drop__text { font-size: 13.5px; color: var(--text-secondary); }
.file-drop__sub  { font-size: 12px; color: var(--text-muted); margin-top: 4px; }

.file-list { display: flex; flex-direction: column; gap: 10px; margin-top: 14px; }
.file-item {
    display: flex; align-items: center; gap: 12px;
    background: var(--body-bg); border: 1.5px solid var(--border);
    border-radius: 12px; padding: 12px 14px;
}
.file-item__icon {
    width: 36px; height: 36px; border-radius: 10px; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center;
    font-size: 18px;
}
.file-item__name { flex: 1; font-size: 13.5px; font-weight: 500; color: var(--text-primary); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.file-item__type { font-size: 11.5px; color: var(--text-muted); margin-top: 2px; }
.file-item__del  { background: none; border: none; cursor: pointer; color: var(--text-muted); padding: 4px; border-radius: 6px; transition: color .15s; }
.file-item__del:hover { color: #ef4444; }

/* ── Save bar ────────────────────────────────────── */
.save-bar {
    position: sticky; bottom: 16px; z-index: 10;
    background: var(--card-bg); border: 1.5px solid var(--border);
    border-radius: 16px; padding: 14px 20px;
    display: flex; align-items: center; justify-content: space-between; gap: 14px;
    box-shadow: 0 8px 32px rgba(0,0,0,.12);
}
.save-bar__msg { font-size: 13px; color: var(--text-muted); }
.save-status { font-size: 13px; font-weight: 600; display: none; }
.save-status.ok  { color: #10b981; display: inline; }
.save-status.err { color: #ef4444; display: inline; }

/* ── Preview card (right column) ────────────────── */
.preview-card {
    background: var(--card-bg); border: 1.5px solid var(--border);
    border-radius: 20px; overflow: hidden; position: sticky; top: 16px;
}
.preview-card__head {
    background: linear-gradient(135deg,#3b82f6,#1d4ed8);
    padding: 20px; color: #fff;
}
.preview-card__name { font-size: 17px; font-weight: 800; margin-bottom: 2px; }
.preview-card__pos  { font-size: 13px; opacity: .85; }
.preview-card__body { padding: 18px; }
.preview-section { margin-bottom: 16px; }
.preview-section:last-child { margin-bottom: 0; }
.preview-label {
    font-size: 10px; font-weight: 700; text-transform: uppercase;
    letter-spacing: .08em; color: var(--text-muted); margin-bottom: 8px;
}
.preview-skills { display: flex; flex-wrap: wrap; gap: 6px; }
.preview-skill {
    font-size: 11.5px; padding: 3px 10px; border-radius: 100px;
    background: rgba(37,99,235,.09); color: #2563eb;
    border: 1px solid rgba(37,99,235,.18);
}
.preview-exp { display: flex; flex-direction: column; gap: 10px; }
.preview-exp-item__title { font-size: 13px; font-weight: 700; color: var(--text-primary); }
.preview-exp-item__sub   { font-size: 11.5px; color: var(--text-secondary); }
.preview-link {
    display: flex; align-items: center; justify-content: center; gap: 8px;
    margin: 16px; padding: 10px; border-radius: 12px;
    background: rgba(37,99,235,.07); color: var(--primary);
    font-size: 13px; font-weight: 600; text-decoration: none; border: 1.5px solid rgba(37,99,235,.2);
    transition: background .15s;
}
.preview-link:hover { background: rgba(37,99,235,.12); text-decoration: none; }
</style>

<div style="margin-bottom:24px">
    <h1 style="font-size:22px;font-weight:800;color:var(--text-primary);margin:0 0 4px"><?= t('my_resume_title') ?></h1>
    <p style="font-size:14px;color:var(--text-muted);margin:0"><?= t('my_resume_sub') ?></p>
</div>

<div class="res-layout">

<!-- ── LEFT: Editor ── -->
<div>

<!-- Profile hero -->
<div class="res-hero">
    <div class="res-hero__avatar">
        <?php if (!empty($userRow['avatar'])): ?>
            <img src="<?= BASE_URL ?>/assets/uploads/avatars/<?= htmlspecialchars($userRow['avatar']) ?>" alt="">
        <?php else: ?>
            <?= mb_strtoupper(mb_substr($userRow['name'], 0, 1)) ?>
        <?php endif; ?>
    </div>
    <div style="flex:1;min-width:0">
        <div class="res-hero__name"><?= htmlspecialchars($userRow['name']) ?></div>
        <div class="res-hero__pos" id="heroPos"><?= htmlspecialchars($userRow['position'] ?? t('no_position_set')) ?></div>
        <div class="res-hero__meta">
            <?php if ($userRow['email']): ?>
            <span class="res-hero__chip">
                <i data-lucide="mail" width="11" height="11"></i>
                <?= htmlspecialchars($userRow['email']) ?>
            </span>
            <?php endif; ?>
            <?php if ($userRow['phone']): ?>
            <span class="res-hero__chip">
                <i data-lucide="phone" width="11" height="11"></i>
                <?= htmlspecialchars($userRow['phone']) ?>
            </span>
            <?php endif; ?>
        </div>
    </div>
    <a href="<?= BASE_URL ?>/pages/profile.php"
       style="position:absolute;top:16px;right:16px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);border-radius:10px;padding:6px 12px;color:#fff;text-decoration:none;font-size:12.5px;font-weight:600;display:flex;align-items:center;gap:5px">
        <i data-lucide="square-pen" width="12" height="12"></i>
        <?= t('btn_edit') ?>
    </a>
</div>

<!-- About -->
<div class="res-card">
    <div class="res-card__head">
        <div class="res-card__title">
            <div class="res-card__icon" style="background:rgba(37,99,235,.1)">
                <i data-lucide="user" width="16" height="16" style="color:#2563eb"></i>
            </div>
            <?= t('section_about') ?>
        </div>
    </div>
    <div class="res-card__body">
        <textarea id="aboutText" class="form-control" rows="4"
                  placeholder="<?= t('about_placeholder') ?>"
                  style="resize:vertical;font-size:14px"><?= htmlspecialchars($resume['about'] ?? '') ?></textarea>
        <div style="font-size:12px;color:var(--text-muted);margin-top:6px"><?= t('about_hint') ?></div>
    </div>
</div>

<!-- Skills -->
<div class="res-card">
    <div class="res-card__head">
        <div class="res-card__title">
            <div class="res-card__icon" style="background:rgba(16,185,129,.1)">
                <i data-lucide="activity" width="16" height="16" style="color:#10b981"></i>
            </div>
            <?= t('section_skills') ?>
        </div>
    </div>
    <div class="res-card__body">
        <div class="skills-wrap" id="skillsWrap">
            <?php foreach ($skillsList as $sk): ?>
            <span class="skill-tag">
                <?= htmlspecialchars($sk) ?>
                <button class="skill-tag__del" type="button" onclick="removeSkill(this)" title="<?= t('btn_delete') ?>">
                    <i data-lucide="x" width="12" height="12" stroke-width="2.5"></i>
                </button>
            </span>
            <?php endforeach; ?>
        </div>
        <div class="skill-input-wrap">
            <input type="text" id="skillInput" class="form-control" placeholder="<?= t('skills_placeholder') ?>"
                   style="font-size:13.5px" onkeydown="if(event.key==='Enter'||event.key===','){event.preventDefault();addSkill()}">
            <button class="btn btn-outline btn-sm" type="button" onclick="addSkill()">+ <?= t('btn_add') ?></button>
        </div>
        <div style="font-size:12px;color:var(--text-muted);margin-top:6px"><?= t('skills_hint') ?></div>
    </div>
</div>

<!-- Experience -->
<div class="res-card">
    <div class="res-card__head">
        <div class="res-card__title">
            <div class="res-card__icon" style="background:rgba(139,92,246,.1)">
                <i data-lucide="briefcase" width="16" height="16" style="color:#8b5cf6"></i>
            </div>
            <?= t('section_experience') ?>
        </div>
        <button class="btn btn-ghost btn-sm" type="button" onclick="toggleAddBlock('expBlock')" style="gap:5px">
            <i data-lucide="circle-plus" width="13" height="13"></i>
            <?= t('btn_add') ?>
        </button>
    </div>
    <div class="res-card__body">

        <div class="exp-list" id="expList">
        <?php foreach ($exps as $ex): ?>
        <div class="exp-item" data-id="<?= $ex['id'] ?>">
            <button class="exp-item__del" type="button" onclick="deleteRecord('exp', <?= $ex['id'] ?>, this)" title="<?= t('btn_delete') ?>">
                <i data-lucide="trash-2" width="14" height="14"></i>
            </button>
            <div class="exp-item__head">
                <div class="exp-item__dot" style="background:rgba(139,92,246,.1)">
                    <i data-lucide="briefcase" width="16" height="16" style="color:#8b5cf6"></i>
                </div>
                <div>
                    <div class="exp-item__title"><?= htmlspecialchars($ex['position']) ?></div>
                    <div class="exp-item__sub"><?= htmlspecialchars($ex['company']) ?> &nbsp;·&nbsp; <?= htmlspecialchars($ex['date_from'] ?? '') ?> — <?= $ex['is_current'] ? t('present') : htmlspecialchars($ex['date_to'] ?? '') ?></div>
                </div>
            </div>
            <?php if ($ex['description']): ?>
            <div style="font-size:13px;color:var(--text-secondary);line-height:1.6"><?= nl2br(htmlspecialchars($ex['description'])) ?></div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
        <?php if (empty($exps)): ?>
        <div id="expEmpty" style="font-size:13.5px;color:var(--text-muted);text-align:center;padding:16px 0"><?= t('exp_empty') ?></div>
        <?php endif; ?>
        </div>

        <div class="add-block" id="expBlock">
            <div class="add-block__grid">
                <div class="form-group" style="margin:0">
                    <label class="form-label"><?= t('field_job_title') ?> <span class="req">*</span></label>
                    <input type="text" id="exp_position" class="form-control" placeholder="<?= t('exp_position_ph') ?>">
                </div>
                <div class="form-group" style="margin:0">
                    <label class="form-label"><?= t('field_company') ?> <span class="req">*</span></label>
                    <input type="text" id="exp_company" class="form-control" placeholder="McDonald's, Burger King...">
                </div>
                <div class="form-group" style="margin:0">
                    <label class="form-label"><?= t('date_from_label') ?></label>
                    <input type="text" id="exp_from" class="form-control" placeholder="<?= t('date_from_ph') ?>">
                </div>
                <div class="form-group" style="margin:0">
                    <label class="form-label"><?= t('date_to_label') ?></label>
                    <input type="text" id="exp_to" class="form-control" placeholder="<?= t('date_to_ph') ?>">
                    <label style="display:flex;align-items:center;gap:6px;margin-top:8px;font-size:13px;color:var(--text-secondary);cursor:pointer">
                        <input type="checkbox" id="exp_current"> <?= t('present') ?>
                    </label>
                </div>
            </div>
            <div class="form-group" style="margin-top:12px;margin-bottom:0">
                <label class="form-label"><?= t('exp_desc_label') ?></label>
                <textarea id="exp_desc" class="form-control" rows="3" placeholder="<?= t('exp_desc_ph') ?>"></textarea>
            </div>
            <div style="display:flex;gap:8px;margin-top:14px">
                <button class="btn btn-primary btn-sm" type="button" onclick="saveExp()"><?= t('btn_save') ?></button>
                <button class="btn btn-ghost btn-sm" type="button" onclick="toggleAddBlock('expBlock')"><?= t('btn_cancel') ?></button>
            </div>
        </div>

    </div>
</div>

<!-- Education -->
<div class="res-card">
    <div class="res-card__head">
        <div class="res-card__title">
            <div class="res-card__icon" style="background:rgba(245,158,11,.1)">
                <i data-lucide="graduation-cap" width="16" height="16" style="color:#f59e0b"></i>
            </div>
            <?= t('section_education') ?>
        </div>
        <button class="btn btn-ghost btn-sm" type="button" onclick="toggleAddBlock('eduBlock')" style="gap:5px">
            <i data-lucide="circle-plus" width="13" height="13"></i>
            <?= t('btn_add') ?>
        </button>
    </div>
    <div class="res-card__body">

        <div class="exp-list" id="eduList">
        <?php foreach ($edus as $ed): ?>
        <div class="exp-item" data-id="<?= $ed['id'] ?>">
            <button class="exp-item__del" type="button" onclick="deleteRecord('edu', <?= $ed['id'] ?>, this)" title="<?= t('btn_delete') ?>">
                <i data-lucide="trash-2" width="14" height="14"></i>
            </button>
            <div class="exp-item__head">
                <div class="exp-item__dot" style="background:rgba(245,158,11,.1)">
                    <i data-lucide="graduation-cap" width="16" height="16" style="color:#f59e0b"></i>
                </div>
                <div>
                    <div class="exp-item__title"><?= htmlspecialchars($ed['degree'] ?? $ed['institution']) ?></div>
                    <div class="exp-item__sub"><?= htmlspecialchars($ed['institution']) ?> &nbsp;·&nbsp; <?= $ed['year_from'] ?? '' ?><?= $ed['year_to'] ? ' — '.$ed['year_to'] : '' ?></div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        <?php if (empty($edus)): ?>
        <div id="eduEmpty" style="font-size:13.5px;color:var(--text-muted);text-align:center;padding:16px 0"><?= t('edu_empty') ?></div>
        <?php endif; ?>
        </div>

        <div class="add-block" id="eduBlock">
            <div class="add-block__grid">
                <div class="form-group" style="margin:0">
                    <label class="form-label"><?= t('edu_institution_label') ?> <span class="req">*</span></label>
                    <input type="text" id="edu_inst" class="form-control" placeholder="<?= t('edu_institution_ph') ?>">
                </div>
                <div class="form-group" style="margin:0">
                    <label class="form-label"><?= t('edu_degree_label') ?></label>
                    <input type="text" id="edu_degree" class="form-control" placeholder="<?= t('edu_degree_ph') ?>">
                </div>
                <div class="form-group" style="margin:0">
                    <label class="form-label"><?= t('edu_year_from') ?></label>
                    <input type="number" id="edu_from" class="form-control" placeholder="2018" min="1950" max="2099">
                </div>
                <div class="form-group" style="margin:0">
                    <label class="form-label"><?= t('edu_year_to') ?></label>
                    <input type="number" id="edu_to" class="form-control" placeholder="2022" min="1950" max="2099">
                </div>
            </div>
            <div style="display:flex;gap:8px;margin-top:14px">
                <button class="btn btn-primary btn-sm" type="button" onclick="saveEdu()"><?= t('btn_save') ?></button>
                <button class="btn btn-ghost btn-sm" type="button" onclick="toggleAddBlock('eduBlock')"><?= t('btn_cancel') ?></button>
            </div>
        </div>

    </div>
</div>

<!-- Documents -->
<div class="res-card">
    <div class="res-card__head">
        <div class="res-card__title">
            <div class="res-card__icon" style="background:rgba(239,68,68,.1)">
                <i data-lucide="file-text" width="16" height="16" style="color:#ef4444"></i>
            </div>
            <?= t('section_documents') ?>
        </div>
    </div>
    <div class="res-card__body">
        <label class="file-drop" id="fileDrop">
            <input type="file" id="fileInput" accept=".pdf,.jpg,.jpeg,.png" multiple onchange="uploadFiles(this.files)">
            <div class="file-drop__icon" style="color:var(--text-muted)"><i data-lucide="paperclip" width="32" height="32" stroke-width="1.5"></i></div>
            <div class="file-drop__text"><?= t('file_drop_text') ?></div>
            <div class="file-drop__sub"><?= t('file_drop_sub') ?></div>
        </label>

        <div class="file-list" id="fileList">
        <?php foreach ($files as $f):
            $iconName = $f['file_type'] === 'diploma' ? 'graduation-cap' : ($f['file_type'] === 'certificate' ? 'scroll' : 'file-text');
            $typeLabel = ['diploma' => t('file_type_diploma'), 'certificate' => t('file_type_certificate'), 'other' => t('file_type_other')][$f['file_type']];
        ?>
        <div class="file-item" data-id="<?= $f['id'] ?>">
            <div class="file-item__icon" style="background:rgba(239,68,68,.08);color:#ef4444"><i data-lucide="<?= $iconName ?>" width="18" height="18"></i></div>
            <div style="flex:1;min-width:0">
                <div class="file-item__name"><?= htmlspecialchars($f['original_name']) ?></div>
                <div class="file-item__type"><?= $typeLabel ?></div>
            </div>
            <a href="<?= BASE_URL ?>/assets/uploads/resume/<?= htmlspecialchars($f['filename']) ?>"
               target="_blank" class="file-item__del" title="<?= t('btn_open') ?>" style="color:var(--primary)">
                <i data-lucide="external-link" width="15" height="15"></i>
            </a>
            <button class="file-item__del" type="button" onclick="deleteFile(<?= $f['id'] ?>, this)" title="<?= t('btn_delete') ?>">
                <i data-lucide="trash-2" width="15" height="15"></i>
            </button>
        </div>
        <?php endforeach; ?>
        </div>

    </div>
</div>

<!-- Save bar -->
<div class="save-bar">
    <div>
        <span class="save-bar__msg"><?= t('autosave_msg') ?></span>
        <span class="save-status" id="saveStatus"></span>
    </div>
    <div style="display:flex;gap:10px;align-items:center">
        <a href="<?= BASE_URL ?>/pages/resume_view.php?id=<?= $uid ?>" target="_blank"
           class="btn btn-ghost btn-sm" style="gap:6px">
            <i data-lucide="eye" width="13" height="13"></i>
            <?= t('btn_view') ?>
        </a>
        <button class="btn btn-primary" type="button" id="saveBtn" onclick="saveResume()">
            <i data-lucide="save" width="14" height="14"></i>
            <?= t('btn_save') ?>
        </button>
    </div>
</div>

</div><!-- end left -->

<!-- ── RIGHT: Live Preview ── -->
<div>
<div class="preview-card">
    <div class="preview-card__head">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">
            <div style="width:44px;height:44px;border-radius:12px;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:16px;font-weight:800;color:#fff;flex-shrink:0;overflow:hidden">
                <?php if (!empty($userRow['avatar'])): ?>
                    <img src="<?= BASE_URL ?>/assets/uploads/avatars/<?= htmlspecialchars($userRow['avatar']) ?>" alt="" style="width:100%;height:100%;object-fit:cover">
                <?php else: ?>
                    <?= mb_strtoupper(mb_substr($userRow['name'], 0, 1)) ?>
                <?php endif; ?>
            </div>
            <div>
                <div class="preview-card__name"><?= htmlspecialchars($userRow['name']) ?></div>
                <div class="preview-card__pos"><?= htmlspecialchars($userRow['position'] ?? '') ?></div>
            </div>
        </div>
        <div style="font-size:11px;opacity:.7;display:flex;gap:12px;flex-wrap:wrap">
            <?php if ($userRow['email']): ?><span style="display:inline-flex;align-items:center;gap:4px"><i data-lucide="mail" width="12" height="12"></i><?= htmlspecialchars($userRow['email']) ?></span><?php endif; ?>
            <?php if ($userRow['phone']): ?><span style="display:inline-flex;align-items:center;gap:4px"><i data-lucide="phone" width="12" height="12"></i><?= htmlspecialchars($userRow['phone']) ?></span><?php endif; ?>
        </div>
    </div>
    <div class="preview-card__body">

        <div class="preview-section" id="prevAboutSection" <?= empty($resume['about']) ? 'style="display:none"' : '' ?>>
            <div class="preview-label"><?= mb_strtoupper(t('section_about')) ?></div>
            <div id="prevAbout" style="font-size:12.5px;color:var(--text-secondary);line-height:1.6"><?= nl2br(htmlspecialchars($resume['about'] ?? '')) ?></div>
        </div>

        <div class="preview-section" id="prevSkillsSection" <?= empty($skillsList) ? 'style="display:none"' : '' ?>>
            <div class="preview-label"><?= mb_strtoupper(t('section_skills')) ?></div>
            <div class="preview-skills" id="prevSkills">
                <?php foreach ($skillsList as $sk): ?>
                <span class="preview-skill"><?= htmlspecialchars($sk) ?></span>
                <?php endforeach; ?>
            </div>
        </div>

        <?php if (!empty($exps)): ?>
        <div class="preview-section">
            <div class="preview-label"><?= mb_strtoupper(t('section_experience')) ?></div>
            <div class="preview-exp">
                <?php foreach (array_slice($exps, 0, 3) as $ex): ?>
                <div class="preview-exp-item">
                    <div class="preview-exp-item__title"><?= htmlspecialchars($ex['position']) ?></div>
                    <div class="preview-exp-item__sub"><?= htmlspecialchars($ex['company']) ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($edus)): ?>
        <div class="preview-section">
            <div class="preview-label"><?= mb_strtoupper(t('section_education')) ?></div>
            <div class="preview-exp">
                <?php foreach (array_slice($edus, 0, 2) as $ed): ?>
                <div class="preview-exp-item">
                    <div class="preview-exp-item__title"><?= htmlspecialchars($ed['degree'] ?? $ed['institution']) ?></div>
                    <div class="preview-exp-item__sub"><?= htmlspecialchars($ed['institution']) ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($files)): ?>
        <div class="preview-section">
            <div class="preview-label"><?= mb_strtoupper(t('section_documents')) ?></div>
            <div style="display:flex;flex-direction:column;gap:6px">
                <?php foreach ($files as $f): ?>
                <div style="font-size:12px;color:var(--text-secondary);display:flex;align-items:center;gap:6px">
                    <span style="display:inline-flex"><i data-lucide="<?= $f['file_type'] === 'diploma' ? 'graduation-cap' : 'scroll' ?>" width="14" height="14"></i></span>
                    <?= htmlspecialchars($f['original_name']) ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

    </div>
    <a href="<?= BASE_URL ?>/pages/resume_view.php?id=<?= $uid ?>" target="_blank" class="preview-link">
        <i data-lucide="external-link" width="14" height="14"></i>
        <?= t('open_full_resume') ?>
    </a>
</div>
</div><!-- end right -->

</div><!-- end res-layout -->

<script>
window.nexioPage = {
    base: '<?= addslashes(BASE_URL) ?>',
    i18n: {
        expRequired:     <?= json_encode(t('exp_required_alert')) ?>,
        eduRequired:     <?= json_encode(t('edu_required_alert') ?: 'Укажите учебное заведение') ?>,
        confirmDelete:   <?= json_encode(t('confirm_delete_record')) ?>,
        confirmDeleteFile: <?= json_encode(t('confirm_delete_file')) ?>,
        present:         <?= json_encode(t('present')) ?>,
        delete:          <?= json_encode(t('btn_delete')) ?>,
        saving:          'Сохраняю...',
        saved:           '✓ Сохранено',
        error:           '✗ Ошибка',
        diploma:         'Диплом',
        certificate:     'Сертификат',
        other:           'Документ'
    }
};
</script>
<script type="module" src="<?= BASE_URL ?>/assets/js/pages/resume.js"></script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
