<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

$uid     = $_SESSION['user_id'];
$success = '';
$error   = '';

// ── Ensure optional columns exist ─────────────────────────────
foreach ([
    "ALTER TABLE users ADD COLUMN position VARCHAR(120)  DEFAULT '' AFTER role",
    "ALTER TABLE users ADD COLUMN company  VARCHAR(120)  DEFAULT '' AFTER position",
    "ALTER TABLE users ADD COLUMN bio      TEXT                     AFTER company",
    "ALTER TABLE users ADD COLUMN phone    VARCHAR(30)   DEFAULT '' AFTER bio",
    "ALTER TABLE users ADD COLUMN avatar   VARCHAR(255)  DEFAULT NULL AFTER phone",
] as $ddl) { try { $conn->query($ddl); } catch (\mysqli_sql_exception $e) {} }

// ── Load user ─────────────────────────────────────────────────
$stmt = $conn->prepare("SELECT * FROM users WHERE id=?");
$stmt->bind_param('i', $uid); $stmt->execute();
$user = $stmt->get_result()->fetch_assoc(); $stmt->close();
$user = array_merge(['position'=>'','company'=>'','bio'=>'','phone'=>'','created_at'=>date('Y-m-d H:i:s'),'avatar'=>null], $user ?? []);
$_SESSION['user_avatar'] = $user['avatar'];

// ── Handle POST ───────────────────────────────────────────────
$postAction = $_POST['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($postAction === 'update_profile') {
        $name     = trim($_POST['name']     ?? '');
        $company  = trim($_POST['company']  ?? '');
        $position = trim($_POST['position'] ?? '');
        $bio      = trim($_POST['bio']      ?? '');
        $phone    = trim($_POST['phone']    ?? '');

        if (!$name) {
            $error = t('err_fill_all');
        } else {
            $stmt = $conn->prepare("UPDATE users SET name=?,company=?,position=?,bio=?,phone=? WHERE id=?");
            $stmt->bind_param('sssssi', $name, $company, $position, $bio, $phone, $uid);
            if ($stmt->execute()) {
                $_SESSION['user_name'] = $name;
                $user = array_merge($user, compact('name','company','position','bio','phone'));
                $success = t('profile_updated');
            } else {
                $error = t('err_save_fail') . ' ' . $conn->error;
            }
            $stmt->close();
        }
    }

    if ($postAction === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $newPass = $_POST['new_password']      ?? '';
        $confirm = $_POST['confirm_password']  ?? '';

        if (!$current || !$newPass || !$confirm) {
            $error = t('err_fill_all');
        } elseif (!password_verify($current, $user['password'])) {
            $error = t('err_wrong_password');
        } elseif (strlen($newPass) < 6) {
            $error = t('err_short_password');
        } elseif ($newPass !== $confirm) {
            $error = t('err_pass_mismatch');
        } else {
            $hash = password_hash($newPass, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("UPDATE users SET password=? WHERE id=?");
            $stmt->bind_param('si', $hash, $uid);
            $stmt->execute() ? $success = t('password_changed') : $error = t('err_register_fail');
            $stmt->close();
            if ($success) $user['password'] = $hash;
        }
    }

    if ($postAction === 'upload_avatar') {
        if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
            $file    = $_FILES['avatar'];
            $allowed = ['image/jpeg','image/png','image/gif','image/webp'];
            $mime    = mime_content_type($file['tmp_name']);
            if ($file['size'] > 2 * 1024 * 1024) {
                $error = t('err_file_too_large');
            } elseif (!in_array($mime, $allowed)) {
                $error = t('err_invalid_image');
            } else {
                $ext       = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                $filename  = $uid . '_' . time() . '.' . $ext;
                $uploadDir = __DIR__ . '/../assets/uploads/avatars/';
                if ($user['avatar'] && file_exists($uploadDir . $user['avatar'])) unlink($uploadDir . $user['avatar']);
                if (move_uploaded_file($file['tmp_name'], $uploadDir . $filename)) {
                    $stmt = $conn->prepare("UPDATE users SET avatar=? WHERE id=?");
                    $stmt->bind_param('si', $filename, $uid);
                    $stmt->execute(); $stmt->close();
                    $user['avatar'] = $filename;
                    $_SESSION['user_avatar'] = $filename;
                    $success = t('avatar_updated');
                } else { $error = t('err_upload_fail'); }
            }
        } else { $error = t('err_select_file'); }
    }
}

// Reopen modal if profile edit had an error
$reopenModal = !empty($error) && $postAction === 'update_profile';

// ── Stats ─────────────────────────────────────────────────────
$stats = [];
if ($user['role'] === 'employer') {
    $s = $conn->prepare("SELECT COUNT(*) FROM vacancies WHERE employer_id=?");
    $s->bind_param('i',$uid); $s->execute(); $s->bind_result($stats['vacancies']); $s->fetch(); $s->close();
    $s = $conn->prepare("SELECT COUNT(*) FROM ratings WHERE employer_id=?");
    $s->bind_param('i',$uid); $s->execute(); $s->bind_result($stats['ratings']); $s->fetch(); $s->close();
} else {
    $s = $conn->prepare("SELECT COUNT(*) FROM applications WHERE employee_id=?");
    $s->bind_param('i',$uid); $s->execute(); $s->bind_result($stats['applications']); $s->fetch(); $s->close();
    $s = $conn->prepare("SELECT IFNULL(ROUND(AVG(score)*2,1),0) FROM ratings WHERE employee_id=?");
    $s->bind_param('i',$uid); $s->execute(); $s->bind_result($stats['avg_score']); $s->fetch(); $s->close();
}
$s = $conn->prepare("SELECT COUNT(*) FROM messages WHERE sender_id=? OR receiver_id=?");
$s->bind_param('ii',$uid,$uid); $s->execute(); $s->bind_result($stats['messages']); $s->fetch(); $s->close();

function profileColor(string $name): string {
    $c = ['#2563eb','#7c3aed','#db2777','#16a34a','#d97706','#0891b2','#dc2626','#4f46e5'];
    return $c[ord($name[0] ?? 'A') % count($c)];
}

$pageTitle   = t('profile');
$profileData = $user;
include __DIR__ . '/../includes/header.php';
$user = $profileData;

$section = in_array($_GET['section'] ?? '', ['info','security','account']) ? $_GET['section'] : 'info';
?>

<style>
/* ── Layout ── */
.profile-layout { display: grid; grid-template-columns: 280px 1fr; gap: 24px; align-items: start; }
@media (max-width: 860px) { .profile-layout { grid-template-columns: 1fr; } }

/* ── Sidebar card ── */
.pcard { border-radius: 20px; overflow: hidden; }
.pcard__cover { height: 80px; background: linear-gradient(135deg, #1e3a5f 0%, #2563eb 50%, #7c3aed 100%); position: relative; }
.pcard__top { padding: 0 20px 20px; display: flex; flex-direction: column; align-items: center; text-align: center; }
.pcard__avatar-wrap { position: relative; width: 84px; height: 84px; margin-top: -42px; margin-bottom: 12px; cursor: pointer; }
.pcard__avatar { width: 84px; height: 84px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 28px; font-weight: 800; color: #fff; border: 3px solid var(--card-bg); }
.pcard__avatar--img { width: 84px; height: 84px; border-radius: 50%; object-fit: cover; display: block; border: 3px solid var(--card-bg); }
.pcard__avatar-overlay { position: absolute; inset: 0; border-radius: 50%; background: rgba(0,0,0,.55); display: flex; align-items: center; justify-content: center; opacity: 0; transition: opacity .18s; color: #fff; pointer-events: none; }
.pcard__avatar-wrap:hover .pcard__avatar-overlay { opacity: 1; }
.pcard__name     { font-size: 18px; font-weight: 700; color: var(--text-primary); margin-bottom: 4px; }
.pcard__role     { margin-bottom: 6px; }
.pcard__position { font-size: 13px; color: var(--text-secondary); margin-top: 2px; }
.pcard__company  { font-size: 12px; color: var(--text-muted); margin-top: 2px; }

.pcard__stats { display: flex; justify-content: space-around; padding: 16px 20px; border-top: 1px solid var(--border-light); border-bottom: 1px solid var(--border-light); }
.pcard__stat strong { display: block; font-size: 20px; font-weight: 800; color: var(--text-primary); }
.pcard__stat span   { display: block; font-size: 11px; color: var(--text-muted); margin-top: 1px; }

.pcard__meta { padding: 14px 20px; font-size: 12px; color: var(--text-muted); display: flex; flex-direction: column; gap: 6px; }
.pcard__meta-row { display: flex; align-items: center; gap: 7px; }
.pcard__meta-row svg { flex-shrink: 0; opacity: .6; }

/* ── Tabs ── */
.profile-tabs { display: flex; gap: 2px; border-bottom: 1px solid var(--border); margin-bottom: 20px; }
.profile-tab { display: flex; align-items: center; gap: 6px; padding: 10px 16px; font-size: 13px; font-weight: 500; color: var(--text-muted); text-decoration: none; border-bottom: 2.5px solid transparent; margin-bottom: -1px; transition: color .14s, border-color .14s; border-radius: 6px 6px 0 0; }
.profile-tab:hover { color: var(--primary); text-decoration: none; background: var(--body-bg); }
.profile-tab.active { color: var(--primary); border-bottom-color: var(--primary); background: none; }

/* ── Info display ── */
.info-section { display: flex; flex-direction: column; }
.info-row { display: flex; align-items: flex-start; gap: 14px; padding: 15px 0; border-bottom: 1px solid var(--border-light); }
.info-row:last-child { border-bottom: none; }
.info-row__icon { width: 38px; height: 38px; border-radius: 11px; background: var(--body-bg); display: flex; align-items: center; justify-content: center; color: var(--primary); flex-shrink: 0; }
.info-row__body { flex: 1; min-width: 0; }
.info-row__label { font-size: 11px; color: var(--text-muted); font-weight: 600; text-transform: uppercase; letter-spacing: .6px; margin-bottom: 3px; }
.info-row__value { font-size: 14px; color: var(--text-primary); line-height: 1.5; word-break: break-word; }
.info-row__value--empty { color: var(--text-muted); font-style: italic; font-size: 13px; }

/* ── Edit modal ── */
.pmodal-overlay {
  position: fixed; inset: 0; z-index: 5000;
  background: rgba(0,0,0,.55); backdrop-filter: blur(4px);
  display: flex; align-items: center; justify-content: center; padding: 16px;
  opacity: 0; pointer-events: none;
  transition: opacity 220ms ease;
}
.pmodal-overlay.open { opacity: 1; pointer-events: auto; }
.pmodal-dialog {
  background: var(--card-bg); border-radius: 20px;
  box-shadow: 0 32px 80px rgba(0,0,0,.4);
  width: 580px; max-width: 100%; max-height: calc(100vh - 40px);
  overflow-y: auto; display: flex; flex-direction: column;
  transform: scale(.96) translateY(12px);
  transition: transform 220ms ease;
}
.pmodal-overlay.open .pmodal-dialog { transform: scale(1) translateY(0); }
.pmodal-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 20px 24px; border-bottom: 1px solid var(--border); flex-shrink: 0;
}
.pmodal-title { font-size: 16px; font-weight: 700; }
.pmodal-close {
  width: 32px; height: 32px; border: none; border-radius: 9px;
  background: var(--body-bg); cursor: pointer; color: var(--text-muted);
  display: flex; align-items: center; justify-content: center; transition: background .14s, color .14s;
}
.pmodal-close:hover { background: var(--border); color: var(--text-primary); }
.pmodal-body   { padding: 24px; flex: 1; }
.pmodal-footer { padding: 16px 24px; border-top: 1px solid var(--border); display: flex; gap: 10px; flex-shrink: 0; }

/* ── Form helpers ── */
.input-with-icon { position: relative; }
.input-with-icon svg { position: absolute; left: 11px; top: 50%; transform: translateY(-50%); color: var(--text-muted); pointer-events: none; }
.input-with-icon input, .input-with-icon textarea { padding-left: 36px; }
.form-hint { font-size: 11.5px; color: var(--text-muted); margin-top: 4px; }
.form-section { display: flex; flex-direction: column; gap: 16px; }

/* ── Security / account ── */
.danger-zone { border: 1px solid var(--danger-bg); border-radius: var(--radius-lg); padding: 16px 18px; background: var(--danger-bg); }
.danger-zone h4 { font-size: 14px; font-weight: 600; color: var(--danger); margin-bottom: 6px; }
.danger-zone p  { font-size: 13px; color: var(--text-secondary); }
</style>

<?php if ($error):   ?><div class="alert alert-error"><?=   htmlspecialchars($error)   ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<div class="profile-layout">

<!-- ── LEFT: Profile card ── -->
<aside>
    <div class="card pcard" style="padding:0">
        <div class="pcard__cover"></div>
        <div class="pcard__top">
            <!-- Avatar -->
            <div class="pcard__avatar-wrap" id="avatarWrap" title="<?= t('change_avatar_title') ?>">
                <?php if ($user['avatar']): ?>
                    <img id="previewAvatar" class="pcard__avatar pcard__avatar--img"
                         src="<?= BASE_URL ?>/assets/uploads/avatars/<?= htmlspecialchars($user['avatar']) ?>" alt="">
                <?php else: ?>
                    <div id="previewAvatar" class="pcard__avatar" style="background:<?= profileColor($user['name']) ?>">
                        <?= getUserInitials($user['name']) ?>
                    </div>
                <?php endif; ?>
                <div class="pcard__avatar-overlay">
                    <i data-lucide="camera" width="20" height="20"></i>
                </div>
            </div>
            <form method="post" enctype="multipart/form-data" id="avatarUploadForm" style="display:none">
                <input type="hidden" name="action" value="upload_avatar">
                <input type="file" name="avatar" id="avatarFileInput" accept="image/jpeg,image/png,image/gif,image/webp">
            </form>

            <div class="pcard__name"><?= htmlspecialchars($user['name']) ?></div>
            <div class="pcard__role">
                <span class="badge badge-<?= $user['role']==='employer'?'blue':'success' ?>"><?= t($user['role']) ?></span>
            </div>
            <?php if ($user['position']): ?>
                <div class="pcard__position"><?= htmlspecialchars($user['position']) ?></div>
            <?php endif; ?>
            <?php if ($user['company']): ?>
                <div class="pcard__company" style="display:inline-flex;align-items:center;gap:5px"><i data-lucide="building-2" width="14" height="14"></i><?= htmlspecialchars($user['company']) ?></div>
            <?php endif; ?>
        </div>

        <!-- Stats -->
        <div class="pcard__stats">
            <?php if ($user['role'] === 'employer'): ?>
            <div class="pcard__stat"><strong><?= $stats['vacancies'] ?></strong><span><?= t('stat_vacancies') ?></span></div>
            <div class="pcard__stat"><strong><?= $stats['ratings'] ?></strong><span><?= t('stat_ratings') ?></span></div>
            <?php else: ?>
            <div class="pcard__stat"><strong><?= $stats['applications'] ?></strong><span><?= t('stat_applications') ?></span></div>
            <div class="pcard__stat"><strong><?= $stats['avg_score'] ?>/10</strong><span><?= t('stat_rating') ?></span></div>
            <?php endif; ?>
            <div class="pcard__stat"><strong><?= $stats['messages'] ?></strong><span><?= t('stat_messages') ?></span></div>
        </div>

        <!-- Meta -->
        <div class="pcard__meta">
            <div class="pcard__meta-row">
                <i data-lucide="calendar" width="13" height="13"></i>
                <?= t('member_since') ?> <?= date('M Y', strtotime($user['created_at'])) ?>
            </div>
            <div class="pcard__meta-row">
                <i data-lucide="mail" width="13" height="13"></i>
                <?= htmlspecialchars($user['email']) ?>
            </div>
            <?php if ($user['phone']): ?>
            <div class="pcard__meta-row">
                <i data-lucide="phone" width="13" height="13"></i>
                <?= htmlspecialchars($user['phone']) ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</aside>

<!-- ── RIGHT: Content ── -->
<div>
    <!-- Tabs -->
    <div class="profile-tabs">
        <a href="?section=info" class="profile-tab <?= $section==='info' ? 'active' : '' ?>">
            <i data-lucide="user" width="14" height="14"></i>
            <?= t('tab_main') ?>
        </a>
        <a href="?section=security" class="profile-tab <?= $section==='security' ? 'active' : '' ?>">
            <i data-lucide="lock" width="14" height="14"></i>
            <?= t('tab_security') ?>
        </a>
        <a href="?section=account" class="profile-tab <?= $section==='account' ? 'active' : '' ?>">
            <i data-lucide="info" width="14" height="14"></i>
            <?= t('tab_account') ?>
        </a>
    </div>

    <?php if ($section === 'info'): ?>
    <!-- ── INFO TAB: read-only display ── -->
    <div class="card">
        <div class="card__header">
            <h3 class="card__title">Основная информация</h3>
            <button class="btn btn-primary btn-sm" onclick="openProfileModal()" type="button">
                <i data-lucide="square-pen" width="13" height="13" style="margin-right:5px"></i>
                Редактировать
            </button>
        </div>
        <div class="card__body">
            <div class="info-section">
                <!-- Name -->
                <div class="info-row">
                    <div class="info-row__icon">
                        <i data-lucide="user" width="18" height="18"></i>
                    </div>
                    <div class="info-row__body">
                        <div class="info-row__label"><?= t('full_name') ?></div>
                        <div class="info-row__value"><?= htmlspecialchars($user['name']) ?></div>
                    </div>
                </div>
                <!-- Position -->
                <div class="info-row">
                    <div class="info-row__icon">
                        <i data-lucide="briefcase" width="18" height="18"></i>
                    </div>
                    <div class="info-row__body">
                        <div class="info-row__label"><?= t('position') ?></div>
                        <?php if ($user['position']): ?>
                            <div class="info-row__value"><?= htmlspecialchars($user['position']) ?></div>
                        <?php else: ?>
                            <div class="info-row__value info-row__value--empty">Не указано</div>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- Company -->
                <div class="info-row">
                    <div class="info-row__icon">
                        <i data-lucide="building-2" width="18" height="18"></i>
                    </div>
                    <div class="info-row__body">
                        <div class="info-row__label"><?= t('company') ?></div>
                        <?php if ($user['company']): ?>
                            <div class="info-row__value"><?= htmlspecialchars($user['company']) ?></div>
                        <?php else: ?>
                            <div class="info-row__value info-row__value--empty">Не указано</div>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- Phone -->
                <div class="info-row">
                    <div class="info-row__icon">
                        <i data-lucide="phone" width="18" height="18"></i>
                    </div>
                    <div class="info-row__body">
                        <div class="info-row__label"><?= t('phone') ?></div>
                        <?php if ($user['phone']): ?>
                            <div class="info-row__value">
                                <a href="tel:<?= htmlspecialchars($user['phone']) ?>" style="color:var(--primary)">
                                    <?= htmlspecialchars($user['phone']) ?>
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="info-row__value info-row__value--empty">Не указан</div>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- Bio -->
                <div class="info-row">
                    <div class="info-row__icon">
                        <i data-lucide="align-left" width="18" height="18"></i>
                    </div>
                    <div class="info-row__body">
                        <div class="info-row__label"><?= t('bio') ?></div>
                        <?php if ($user['bio']): ?>
                            <div class="info-row__value" style="white-space:pre-line"><?= htmlspecialchars($user['bio']) ?></div>
                        <?php else: ?>
                            <div class="info-row__value info-row__value--empty">Не заполнено</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ── EDIT MODAL ── -->
    <div class="pmodal-overlay" id="profileModal">
        <div class="pmodal-dialog">
            <div class="pmodal-header">
                <span class="pmodal-title">
                    <i data-lucide="square-pen" width="16" height="16" style="margin-right:6px;vertical-align:-3px;color:var(--primary)"></i>
                    Редактировать профиль
                </span>
                <button class="pmodal-close" onclick="closeProfileModal()" type="button">
                    <i data-lucide="x" width="16" height="16" stroke-width="2.5"></i>
                </button>
            </div>
            <div class="pmodal-body">
                <form method="POST" id="profileForm" class="form-section" novalidate>
                    <input type="hidden" name="action" value="update_profile">

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="name"><?= t('full_name') ?> <span class="req">*</span></label>
                            <div class="input-with-icon">
                                <i data-lucide="user" width="15" height="15"></i>
                                <input class="form-control" type="text" id="name" name="name"
                                       value="<?= htmlspecialchars($user['name']) ?>" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="phone"><?= t('phone') ?></label>
                            <div class="input-with-icon">
                                <i data-lucide="phone" width="15" height="15"></i>
                                <input class="form-control" type="text" id="phone" name="phone"
                                       value="<?= htmlspecialchars($user['phone']) ?>"
                                       placeholder="+7 999 000-00-00">
                            </div>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="position"><?= t('position') ?></label>
                            <div class="input-with-icon">
                                <i data-lucide="briefcase" width="15" height="15"></i>
                                <input class="form-control" type="text" id="position" name="position"
                                       value="<?= htmlspecialchars($user['position']) ?>"
                                       placeholder="PHP Developer, Designer...">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="company"><?= t('company') ?></label>
                            <div class="input-with-icon">
                                <i data-lucide="building-2" width="15" height="15"></i>
                                <input class="form-control" type="text" id="company" name="company"
                                       value="<?= htmlspecialchars($user['company']) ?>"
                                       placeholder="<?= t('field_company_employer') ?>">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="bio"><?= t('bio') ?></label>
                        <textarea class="form-control" id="bio" name="bio" rows="4"
                                  placeholder="<?= t('bio_placeholder') ?>"><?= htmlspecialchars($user['bio']) ?></textarea>
                        <div class="form-hint"><?= t('bio_hint') ?></div>
                    </div>
                </form>
            </div>
            <div class="pmodal-footer">
                <button type="submit" form="profileForm" class="btn btn-primary">
                    <i data-lucide="check" width="14" height="14" stroke-width="2.5" style="margin-right:5px"></i>
                    <?= t('save_changes') ?>
                </button>
                <button type="button" class="btn btn-ghost" onclick="closeProfileModal()"><?= t('cancel') ?></button>
            </div>
        </div>
    </div>

    <?php elseif ($section === 'security'): ?>
    <!-- ── SECURITY TAB ── -->
    <div class="card">
        <div class="card__header"><h3 class="card__title"><?= t('change_password') ?></h3></div>
        <div class="card__body">
            <form method="POST" class="form-section" novalidate>
                <input type="hidden" name="action" value="change_password">
                <div class="form-group">
                    <label class="form-label" for="current_password"><?= t('current_password') ?> <span class="req">*</span></label>
                    <div class="input-with-icon">
                        <i data-lucide="lock" width="15" height="15"></i>
                        <input class="form-control" type="password" id="current_password" name="current_password" placeholder="••••••••">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="new_password"><?= t('new_password') ?> <span class="req">*</span></label>
                        <div class="input-with-icon">
                            <i data-lucide="shield" width="15" height="15"></i>
                            <input class="form-control" type="password" id="new_password" name="new_password"
                                   placeholder="<?= t('reset_new_pass_ph') ?>" oninput="checkPassStrength(this.value)">
                        </div>
                        <div id="passStrength" class="form-hint" style="margin-top:6px"></div>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="confirm_password"><?= t('confirm_password') ?> <span class="req">*</span></label>
                        <div class="input-with-icon">
                            <i data-lucide="shield" width="15" height="15"></i>
                            <input class="form-control" type="password" id="confirm_password" name="confirm_password" placeholder="••••••••">
                        </div>
                    </div>
                </div>
                <div style="height:4px;background:var(--border-light);border-radius:100px;overflow:hidden;margin:-6px 0 4px">
                    <div id="strengthBar" style="height:100%;width:0%;background:var(--danger);border-radius:100px;transition:width .3s,background .3s"></div>
                </div>
                <button type="submit" class="btn btn-primary" style="width:fit-content">
                    <i data-lucide="lock" width="14" height="14" stroke-width="2.5" style="margin-right:5px"></i>
                    <?= t('update_password') ?>
                </button>
            </form>
        </div>
    </div>

    <?php elseif ($section === 'account'): ?>
    <!-- ── ACCOUNT TAB ── -->
    <div class="card">
        <div class="card__header"><h3 class="card__title"><?= t('account_info') ?></h3></div>
        <div class="card__body">
            <dl class="info-list">
                <dt><?= t('email') ?></dt>
                <dd><?= htmlspecialchars($user['email']) ?></dd>
                <dt><?= t('nav_account') ?></dt>
                <dd><?= t($user['role']) ?></dd>
                <dt><?= t('member_since') ?></dt>
                <dd><?= date('d F Y', strtotime($user['created_at'])) ?></dd>
                <?php if ($user['phone']): ?>
                <dt><?= t('phone') ?></dt>
                <dd><?= htmlspecialchars($user['phone']) ?></dd>
                <?php endif; ?>
            </dl>
            <p class="text-muted small" style="margin-top:12px"><?= t('email_change_note') ?></p>
        </div>
    </div>
    <div class="card" style="margin-top:16px">
        <div class="card__header"><h3 class="card__title" style="color:var(--danger)"><?= t('danger_zone') ?></h3></div>
        <div class="card__body">
            <div class="danger-zone">
                <h4><?= t('delete_account') ?></h4>
                <p><?= t('delete_warning') ?></p>
                <button class="btn btn-ghost" style="margin-top:12px;color:var(--danger);border-color:var(--danger)"
                        onclick="alert('<?= t('delete_account_msg') ?>')">
                    <?= t('delete_btn') ?>
                </button>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

</div><!-- /.profile-layout -->

<script>
window.nexioPage = {
    reopenModal: <?= $reopenModal ? 'true' : 'false' ?>,
    i18n: {
        weak:       <?= json_encode(t('pass_strength_weak'))   ?>,
        medium:     <?= json_encode(t('pass_strength_medium')) ?>,
        good:       <?= json_encode(t('pass_strength_good'))   ?>,
        strong:     <?= json_encode(t('pass_strength_strong')) ?>,
        veryStrong: <?= json_encode(t('pass_strength_very'))   ?>
    }
};
</script>
<script src="<?= BASE_URL ?>/assets/js/pages/profile.js?v=<?= asset_ver('assets/js/pages/profile.js') ?>"></script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
