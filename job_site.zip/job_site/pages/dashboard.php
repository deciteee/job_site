<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

$user = currentUser();
$uid  = $user['id'];
$role = $user['role'];

// ── Stats ─────────────────────────────────────────────────────
$recent_vacancies = $recent_applications = $my_applications = $my_ratings = [];

if ($role === 'employer') {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM vacancies WHERE employer_id=?");
    $stmt->bind_param('i',$uid); $stmt->execute(); $stmt->bind_result($stat_vacancies); $stmt->fetch(); $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) FROM applications a JOIN vacancies v ON a.vacancy_id=v.id WHERE v.employer_id=?");
    $stmt->bind_param('i',$uid); $stmt->execute(); $stmt->bind_result($stat_applications); $stmt->fetch(); $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) FROM ratings WHERE employer_id=?");
    $stmt->bind_param('i',$uid); $stmt->execute(); $stmt->bind_result($stat_ratings); $stmt->fetch(); $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) FROM messages WHERE receiver_id=? AND is_read=0");
    $stmt->bind_param('i',$uid); $stmt->execute(); $stmt->bind_result($stat_unread); $stmt->fetch(); $stmt->close();

    $stmt = $conn->prepare("SELECT id,title,location,employment_type,status,created_at FROM vacancies WHERE employer_id=? ORDER BY created_at DESC LIMIT 5");
    $stmt->bind_param('i',$uid); $stmt->execute();
    $recent_vacancies = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();

    $stmt = $conn->prepare("SELECT a.id,a.status,a.applied_at,a.employee_id,u.name AS candidate,v.title AS vacancy FROM applications a JOIN users u ON a.employee_id=u.id JOIN vacancies v ON a.vacancy_id=v.id WHERE v.employer_id=? ORDER BY a.applied_at DESC LIMIT 5");
    $stmt->bind_param('i',$uid); $stmt->execute();
    $recent_applications = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();

} else {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM applications WHERE employee_id=?");
    $stmt->bind_param('i',$uid); $stmt->execute(); $stmt->bind_result($stat_applications); $stmt->fetch(); $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) FROM ratings WHERE employee_id=?");
    $stmt->bind_param('i',$uid); $stmt->execute(); $stmt->bind_result($stat_ratings); $stmt->fetch(); $stmt->close();

    $stmt = $conn->prepare("SELECT IFNULL(ROUND(AVG(score)*2,1),0) FROM ratings WHERE employee_id=?");
    $stmt->bind_param('i',$uid); $stmt->execute(); $stmt->bind_result($stat_avg_score); $stmt->fetch(); $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) FROM messages WHERE receiver_id=? AND is_read=0");
    $stmt->bind_param('i',$uid); $stmt->execute(); $stmt->bind_result($stat_unread); $stmt->fetch(); $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) FROM vacancies WHERE status='active'");
    $stmt->execute(); $stmt->bind_result($stat_vacancies); $stmt->fetch(); $stmt->close();

    $stmt = $conn->prepare("SELECT a.id,a.status,a.applied_at,v.title,v.location,v.employment_type,u.name AS employer FROM applications a JOIN vacancies v ON a.vacancy_id=v.id JOIN users u ON v.employer_id=u.id WHERE a.employee_id=? ORDER BY a.applied_at DESC LIMIT 5");
    $stmt->bind_param('i',$uid); $stmt->execute();
    $my_applications = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();

    $stmt = $conn->prepare("SELECT r.score,r.category,r.comment,r.created_at,u.name AS employer_name FROM ratings r JOIN users u ON r.employer_id=u.id WHERE r.employee_id=? ORDER BY r.created_at DESC LIMIT 5");
    $stmt->bind_param('i',$uid); $stmt->execute();
    $my_ratings = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
}

// ── Profile completion ─────────────────────────────────────────
foreach ([
    "ALTER TABLE users ADD COLUMN position VARCHAR(120) DEFAULT '' AFTER role",
    "ALTER TABLE users ADD COLUMN company  VARCHAR(120) DEFAULT '' AFTER position",
    "ALTER TABLE users ADD COLUMN bio      TEXT                    AFTER company",
    "ALTER TABLE users ADD COLUMN phone    VARCHAR(30)  DEFAULT '' AFTER bio",
    "ALTER TABLE users ADD COLUMN avatar   VARCHAR(255) DEFAULT NULL AFTER phone",
] as $_ddl) { try { $conn->query($_ddl); } catch (\mysqli_sql_exception $_e) {} }

$_prow = ['position'=>'','company'=>'','bio'=>'','phone'=>'','avatar'=>null];
$_ps   = $conn->prepare("SELECT position,company,bio,phone,avatar FROM users WHERE id=?");
if ($_ps) { $_ps->bind_param('i',$uid); $_ps->execute(); $_r = $_ps->get_result()->fetch_assoc(); $_ps->close(); if ($_r) $_prow = array_merge($_prow,$_r); }

if ($role === 'employer') {
    $profileChecks = [
        ['done' => !empty($_prow['bio']),     'label' => 'О себе'],
        ['done' => !empty($_prow['phone']),   'label' => 'Контактные данные'],
        ['done' => !empty($_prow['company']), 'label' => 'Описание компании'],
        ['done' => !empty($_prow['avatar']),  'label' => 'Логотип компании'],
    ];
} else {
    $profileChecks = [
        ['done' => !empty($_prow['bio']),      'label' => 'О себе'],
        ['done' => !empty($_prow['phone']),    'label' => 'Контактные данные'],
        ['done' => !empty($_prow['position']), 'label' => 'Должность'],
        ['done' => !empty($_prow['avatar']),   'label' => 'Фото профиля'],
    ];
}
$profileDone = 1 + array_sum(array_column($profileChecks,'done'));
$profilePct  = (int)round($profileDone / 5 * 100);

// ── Chart: 7-day activity ──────────────────────────────────────
$chartLabels = []; $chartDates = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $chartDates[$d] = 0;
    $chartLabels[]  = date('d M', strtotime($d));
}

if ($role === 'employer') {
    $stmt = $conn->prepare("SELECT DATE(applied_at) d, COUNT(*) c FROM applications a JOIN vacancies v ON a.vacancy_id=v.id WHERE v.employer_id=? AND applied_at >= DATE_SUB(NOW(),INTERVAL 7 DAY) GROUP BY DATE(applied_at)");
} else {
    $stmt = $conn->prepare("SELECT DATE(applied_at) d, COUNT(*) c FROM applications WHERE employee_id=? AND applied_at >= DATE_SUB(NOW(),INTERVAL 7 DAY) GROUP BY DATE(applied_at)");
}
$stmt->bind_param('i',$uid); $stmt->execute();
foreach ($stmt->get_result()->fetch_all(MYSQLI_ASSOC) as $row) {
    if (isset($chartDates[$row['d']])) $chartDates[$row['d']] = (int)$row['c'];
}
$stmt->close();
$chartValues = array_values($chartDates);

$chartVacs = [];
if ($role === 'employer') {
    $vacDates = $chartDates; array_walk($vacDates, fn(&$v) => $v = 0);
    $stmt = $conn->prepare("SELECT DATE(created_at) d, COUNT(*) c FROM vacancies WHERE employer_id=? AND created_at >= DATE_SUB(NOW(),INTERVAL 7 DAY) GROUP BY DATE(created_at)");
    $stmt->bind_param('i',$uid); $stmt->execute();
    foreach ($stmt->get_result()->fetch_all(MYSQLI_ASSOC) as $row) {
        if (isset($vacDates[$row['d']])) $vacDates[$row['d']] = (int)$row['c'];
    }
    $stmt->close();
    $chartVacs = array_values($vacDates);
}
$hasChartData = array_sum($chartValues) > 0 || array_sum($chartVacs) > 0;

// ── Activity feed ──────────────────────────────────────────────
$activity = [];
if ($role === 'employer') {
    foreach ($recent_applications as $a) {
        $activity[] = ['color'=>'green','icon'=>'apply','text'=> htmlspecialchars($a['candidate']).' '.t('act_applied_to').' «'.htmlspecialchars($a['vacancy']).'»','ts'=>$a['applied_at']];
    }
    foreach ($recent_vacancies as $v) {
        $activity[] = ['color'=>'blue','icon'=>'vacancy','text'=> t('act_vacancy_prefix').' «'.htmlspecialchars($v['title']).'» — '.t('status_'.$v['status']),'ts'=>$v['created_at']];
    }
} else {
    foreach ($my_applications as $a) {
        $label = match($a['status']) { 'accepted'=>t('act_status_accepted'),'rejected'=>t('act_status_rejected'),'reviewed'=>t('act_status_reviewed'), default=>t('act_status_pending') };
        $activity[] = ['color'=>'blue','icon'=>'apply','text'=> t('act_my_apply').' «'.htmlspecialchars($a['title']).'» — '.$label,'ts'=>$a['applied_at']];
    }
    foreach ($my_ratings as $r) {
        $activity[] = ['color'=>'yellow','icon'=>'rating','text'=> htmlspecialchars($r['employer_name']).' '.t('act_rated_you').' '.($r['score']*2).'/10'.($r['category'] ? ' '.t('act_rated_for').' '.$r['category'] : ''),'ts'=>$r['created_at']];
    }
}
usort($activity, fn($a,$b) => strtotime($b['ts']) - strtotime($a['ts']));
$activity = array_slice($activity, 0, 8);

function relativeTime(string $ts): string {
    $diff = time() - strtotime($ts);
    if ($diff < 60)     return t('time_just_now');
    if ($diff < 3600)   return floor($diff/60).' '.t('time_min_ago');
    if ($diff < 86400)  return floor($diff/3600).' '.t('time_hr_ago');
    if ($diff < 172800) return t('time_yesterday');
    return date('d M', strtotime($ts));
}

// ── Trend deltas (this week vs last week) ──────────────────────
function statDelta(int $now, int $prev): array {
    if ($prev === 0) return ['text' => '', 'up' => true];
    $pct = round(($now - $prev) / $prev * 100);
    return ['text' => ($pct >= 0 ? '+' : '') . $pct . '%', 'up' => $pct >= 0];
}

if ($role === 'employer') {
    $stmt = $conn->prepare("SELECT SUM(applied_at >= DATE_SUB(NOW(),INTERVAL 7 DAY)) n, SUM(applied_at >= DATE_SUB(NOW(),INTERVAL 14 DAY) AND applied_at < DATE_SUB(NOW(),INTERVAL 7 DAY)) p FROM applications a JOIN vacancies v ON a.vacancy_id=v.id WHERE v.employer_id=?");
    $stmt->bind_param('i',$uid); $stmt->execute(); $stmt->bind_result($dn,$dp); $stmt->fetch(); $stmt->close();
    $deltaApps = statDelta((int)$dn, (int)$dp);

    $stmt = $conn->prepare("SELECT SUM(sent_at >= DATE_SUB(NOW(),INTERVAL 7 DAY)) n, SUM(sent_at >= DATE_SUB(NOW(),INTERVAL 14 DAY) AND sent_at < DATE_SUB(NOW(),INTERVAL 7 DAY)) p FROM messages WHERE receiver_id=?");
    $stmt->bind_param('i',$uid); $stmt->execute(); $stmt->bind_result($mn,$mp); $stmt->fetch(); $stmt->close();
    $deltaMsg  = statDelta((int)$mn, (int)$mp);
} else {
    $stmt = $conn->prepare("SELECT SUM(applied_at >= DATE_SUB(NOW(),INTERVAL 7 DAY)) n, SUM(applied_at >= DATE_SUB(NOW(),INTERVAL 14 DAY) AND applied_at < DATE_SUB(NOW(),INTERVAL 7 DAY)) p FROM applications WHERE employee_id=?");
    $stmt->bind_param('i',$uid); $stmt->execute(); $stmt->bind_result($dn,$dp); $stmt->fetch(); $stmt->close();
    $deltaApps = statDelta((int)$dn, (int)$dp);
    $deltaMsg  = ['text'=>'', 'up'=>true];
}

// ── Greeting & date ────────────────────────────────────────────
$hour      = (int)date('H');
$greeting  = $hour < 12 ? t('good_morning') : ($hour < 18 ? t('good_afternoon') : t('good_evening'));
$firstName = explode(' ', $user['name'])[0];

$ruMonths  = ['','января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];
$ruWeekday = ['воскресенье','понедельник','вторник','среда','четверг','пятница','суббота'];
$todayStr  = date('j') . ' ' . $ruMonths[(int)date('n')] . ' ' . date('Y') . ', ' . $ruWeekday[(int)date('w')];

$msgSub = $stat_unread > 0 ? $stat_unread . ' ' . t('unread_count') : t('no_new_messages');

$pageTitle = t('dashboard');
include __DIR__ . '/../includes/header.php';
?>

<style>
/* ── Hero banner ──────────────────────────────────────────────── */
.dash-hero {
    background: linear-gradient(135deg, #dbeafe 0%, #eff6ff 55%, #e0f2fe 100%);
    border-radius: 24px;
    padding: 28px 32px 24px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    overflow: hidden;
    position: relative;
    margin-bottom: 0;
    min-height: 224px;
    height: 100%;
}
[data-theme="dark"] .dash-hero {
    background: linear-gradient(135deg, rgba(37,99,235,.18) 0%, rgba(30,32,40,0) 55%, rgba(14,116,144,.12) 100%);
    border: 1px solid rgba(59,130,246,.15);
}
.dash-hero__body { position: relative; z-index: 1; }
.dash-hero__label {
    font-size: 11px; font-weight: 700; letter-spacing: .12em;
    text-transform: uppercase; color: #2563eb; margin-bottom: 6px;
}
[data-theme="dark"] .dash-hero__label { color: #60a5fa; }
.dash-hero__name {
    font-size: 26px; font-weight: 800; color: #0f172a; line-height: 1.15; margin-bottom: 5px;
}
[data-theme="dark"] .dash-hero__name { color: #f1f5f9; }
.dash-hero__date { font-size: 13px; color: #64748b; margin-bottom: 18px; }
[data-theme="dark"] .dash-hero__date { color: #94a3b8; }
.dash-hero__btns { display: flex; gap: 10px; flex-wrap: wrap; }
.dash-hero__btn-primary {
    display: inline-flex; align-items: center; gap: 7px;
    padding: 9px 18px; border-radius: 12px; font-size: 13px; font-weight: 600;
    background: #2563eb; color: #fff; text-decoration: none;
    transition: background .15s;
}
.dash-hero__btn-primary:hover { background: #1d4ed8; text-decoration: none; color: #fff; }
.dash-hero__btn-ghost {
    display: inline-flex; align-items: center; gap: 7px;
    padding: 9px 18px; border-radius: 12px; font-size: 13px; font-weight: 600;
    background: rgba(255,255,255,.7); color: #1e3a5f; text-decoration: none;
    border: 1.5px solid rgba(37,99,235,.2);
    transition: background .15s, transform .15s;
    backdrop-filter: blur(4px);
}
.dash-hero__btn-ghost:hover { background: #fff; transform: translateY(-1px); text-decoration: none; color: #1e3a5f; }
[data-theme="dark"] .dash-hero__btn-ghost { background: rgba(255,255,255,.08); color: #e2e8f0; border-color: rgba(255,255,255,.12); }

/* Hero illustration */
.dash-hero__art {
    position: absolute; right: 0; top: 0; bottom: 0;
    width: 280px; pointer-events: none; overflow: hidden;
    border-radius: 0 24px 24px 0;
}
@media (max-width: 680px) { .dash-hero__art { display: none; } }

/* ── Top section: hero (left) + stat column (right) ───────────── */
.dash-top {
    display: grid;
    grid-template-columns: minmax(0, 1fr) 322px;
    gap: 18px;
    margin-bottom: 20px;
    align-items: stretch;
}
@media (max-width: 900px) { .dash-top { grid-template-columns: 1fr; } }

/* ── Stat cards (compact, stacked beside hero) ────────────────── */
.dash-stats {
    display: flex;
    flex-direction: column;
    gap: 14px;
}
@media (max-width: 900px) {
    .dash-stats { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
}
@media (max-width: 480px) { .dash-stats { grid-template-columns: 1fr 1fr; } }

.dash-stat {
    background: var(--card-bg);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 10px 12px;
    display: flex;
    align-items: center;
    gap: 10px;
    position: relative;
    overflow: hidden;
    transition: box-shadow .15s;
}
.dash-stat::before {
    content: '';
    position: absolute;
    left: 0; top: 0; bottom: 0; width: 3px;
}
.dash-stat--blue::before   { background: #2563eb; }
.dash-stat--green::before  { background: #16a34a; }
.dash-stat--yellow::before { background: #d97706; }
.dash-stat--purple::before { background: #7c3aed; }
.dash-stat:hover { box-shadow: 0 4px 14px rgba(0,0,0,.07); }
[data-theme="dark"] .dash-stat:hover { box-shadow: 0 4px 14px rgba(0,0,0,.3); }

.dash-stat__info { flex: 1 1 auto; min-width: 0; }
.dash-stat__icon {
    width: 32px; height: 32px; border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
}
.dash-stat--blue   .dash-stat__icon { background: rgba(37,99,235,.10);  color:#2563eb; }
.dash-stat--green  .dash-stat__icon { background: rgba(22,163,74,.10);  color:#16a34a; }
.dash-stat--yellow .dash-stat__icon { background: rgba(217,119,6,.11);  color:#d97706; }
.dash-stat--purple .dash-stat__icon { background: rgba(124,58,237,.10); color:#7c3aed; }
[data-theme="dark"] .dash-stat--blue   .dash-stat__icon { background: rgba(59,130,246,.15);  color:#60a5fa; }
[data-theme="dark"] .dash-stat--green  .dash-stat__icon { background: rgba(34,197,94,.15);   color:#4ade80; }
[data-theme="dark"] .dash-stat--yellow .dash-stat__icon { background: rgba(245,158,11,.15);  color:#fbbf24; }
[data-theme="dark"] .dash-stat--purple .dash-stat__icon { background: rgba(139,92,246,.16);  color:#a78bfa; }

.dash-stat__val {
    font-size: 18px; font-weight: 800; color: var(--text-primary);
    line-height: 1; letter-spacing: -.02em;
}
.dash-stat__lbl { font-size: 11px; color: var(--text-muted); font-weight: 500; margin-top: 2px; }

.dash-stat__delta {
    font-size: 10.5px; font-weight: 700; padding: 2px 7px;
    border-radius: 100px; white-space: nowrap; align-self: center;
}
.dash-stat__delta--up   { background: #dcfce7; color: #16a34a; }
.dash-stat__delta--down { background: #fee2e2; color: #dc2626; }
[data-theme="dark"] .dash-stat__delta--up   { background: rgba(22,163,74,.2);  color: #4ade80; }
[data-theme="dark"] .dash-stat__delta--down { background: rgba(220,38,38,.2); color: #f87171; }

/* ── Main 2-column layout ─────────────────────────────────────── */
.dash-main {
    display: grid;
    grid-template-columns: 1fr 284px;
    gap: 20px;
    align-items: start;
}
@media (max-width: 960px) { .dash-main { grid-template-columns: 1fr; } }
.dash-main__left  { display: flex; flex-direction: column; gap: 18px; }
.dash-main__right { display: flex; flex-direction: column; gap: 16px; position: sticky; top: 16px; }
@media (max-width: 960px) { .dash-main__right { position: static; } }

/* ── Quick action tiles ──────────────────────────────────────── */
.qa-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    padding: 16px;
}
.qa-tile {
    border-radius: 18px;
    border: 1.5px solid var(--border-light);
    padding: 16px 14px 14px;
    display: flex;
    flex-direction: column;
    gap: 8px;
    text-decoration: none;
    color: var(--text-primary);
    transition: border-color .14s, background .14s, transform .14s, box-shadow .14s;
    position: relative;
}
.qa-tile:hover {
    border-color: var(--primary);
    background: var(--primary-light);
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(37,99,235,.1);
    text-decoration: none;
}
.qa-tile__icon {
    width: 40px; height: 40px; border-radius: 13px;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
}
.qa-tile__title { font-size: 13px; font-weight: 700; line-height: 1.2; color: var(--text-primary); }
.qa-tile__sub   { font-size: 11.5px; color: var(--text-muted); }
.qai--blue   { background: rgba(37,99,235,.12);  color:#2563eb; }
.qai--green  { background: rgba(22,163,74,.12);  color:#16a34a; }
.qai--purple { background: rgba(124,58,237,.12); color:#7c3aed; }
.qai--yellow { background: rgba(217,119,6,.13);  color:#d97706; }
[data-theme="dark"] .qai--blue   { background: rgba(59,130,246,.16); color:#60a5fa; }
[data-theme="dark"] .qai--green  { background: rgba(34,197,94,.16);  color:#4ade80; }
[data-theme="dark"] .qai--purple { background: rgba(139,92,246,.18); color:#a78bfa; }
[data-theme="dark"] .qai--yellow { background: rgba(245,158,11,.16); color:#fbbf24; }

.qa-badge {
    position: absolute; top: 12px; right: 12px;
    background: #ef4444; color: #fff;
    font-size: 10px; font-weight: 700;
    padding: 2px 6px; border-radius: 100px; line-height: 1.4;
}

/* ── Profile card (right) ─────────────────────────────────────── */
.profile-prog-track { height: 7px; background: var(--border); border-radius: 100px; overflow: hidden; margin-bottom: 14px; }
.profile-prog-fill  { height: 100%; border-radius: 100px; background: var(--primary); transition: width .7s ease; }
.profile-checklist  { display: flex; flex-direction: column; gap: 8px; }
.profile-check-item { display: flex; align-items: center; gap: 9px; font-size: 12.5px; color: var(--text-secondary); }
.profile-check-item--done { color: var(--text-muted); }
.profile-check-dot {
    width: 19px; height: 19px; border-radius: 50%; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center;
    font-size: 10px; font-weight: 700;
}
.profile-check-dot--done { background: #dcfce7; color: #16a34a; }
.profile-check-dot--todo { background: var(--border-light); border: 1.5px dashed var(--border); }
[data-theme="dark"] .profile-check-dot--done { background: rgba(22,163,74,.2); color: #4ade80; }

/* ── Chart ────────────────────────────────────────────────────── */
.card--chart { border-radius: 26px !important; }
.chart-wrap { padding: 6px 6px 2px; }
.chart-box { position: relative; height: 190px; }
.chart-legend-dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 4px; }
.chart-empty { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 28px 20px; color: var(--text-muted); text-align: center; gap: 6px; }
.chart-empty__icon { opacity: .25; margin-bottom: 4px; }
.chart-empty p { font-size: 13px; }

/* ── Card overrides ───────────────────────────────────────────── */
.card { border-radius: 20px !important; }

/* ── Feed list ────────────────────────────────────────────────── */
.feed-list { padding: 4px 0; }
.feed-item { display: flex; align-items: flex-start; gap: 12px; padding: 10px 16px; position: relative; }
.feed-item:not(:last-child)::after { content:''; position:absolute; left:27px; top:36px; bottom:-2px; width:1.5px; background:var(--border-light); }
.feed-icon { width:24px; height:24px; border-radius:50%; flex-shrink:0; margin-top:1px; display:flex; align-items:center; justify-content:center; position:relative; z-index:1; }
.feed-icon--green  { background:#dcfce7; color:#16a34a; }
.feed-icon--blue   { background:#dbeafe; color:#2563eb; }
.feed-icon--yellow { background:#fef9c3; color:#d97706; }
[data-theme="dark"] .feed-icon--green  { background:rgba(22,163,74,.18); color:#4ade80; }
[data-theme="dark"] .feed-icon--blue   { background:rgba(59,130,246,.18); color:#60a5fa; }
[data-theme="dark"] .feed-icon--yellow { background:rgba(217,119,6,.18); color:#fbbf24; }
.feed-body { min-width:0; }
.feed-text { font-size:12.5px; color:var(--text-primary); line-height:1.45; }
.feed-time { font-size:11px; color:var(--text-muted); margin-top:2px; }
</style>

<!-- ═══ TOP: HERO + STAT COLUMN ═══ -->
<div class="dash-top">

<!-- ═══ HERO BANNER ═══ -->
<div class="dash-hero">
    <div class="dash-hero__body">
        <div class="dash-hero__label"><?= mb_strtoupper($greeting) ?>,</div>
        <div class="dash-hero__name"><?= htmlspecialchars($firstName) ?> 👋</div>
        <div class="dash-hero__date"><?= $todayStr ?></div>
        <div class="dash-hero__btns">
            <?php if ($role === 'employer'): ?>
            <a href="<?= BASE_URL ?>/pages/vacancy_create.php" class="dash-hero__btn-primary">
                <i data-lucide="circle-plus" width="14" height="14"></i>
                <?= t('post_vacancy') ?>
            </a>
            <a href="<?= BASE_URL ?>/pages/vacancies.php" class="dash-hero__btn-ghost">
                <i data-lucide="briefcase" width="14" height="14"></i>
                <?= t('nav_vacancies') ?>
            </a>
            <?php else: ?>
            <a href="<?= BASE_URL ?>/pages/vacancies.php" class="dash-hero__btn-primary">
                <i data-lucide="search" width="14" height="14"></i>
                <?= t('browse_jobs') ?>
            </a>
            <a href="<?= BASE_URL ?>/pages/resume.php" class="dash-hero__btn-ghost">
                <i data-lucide="file-text" width="14" height="14"></i>
                <?= t('nav_resume') ?>
            </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Abstract illustration -->
    <div class="dash-hero__art" aria-hidden="true">
        <svg viewBox="0 0 280 148" fill="none" xmlns="http://www.w3.org/2000/svg" width="280" height="148" preserveAspectRatio="xMaxYMid slice">
            <circle cx="210" cy="54" r="96" fill="rgba(255,255,255,0.40)"/>
            <circle cx="210" cy="54" r="68" fill="rgba(255,255,255,0.30)"/>
            <circle cx="210" cy="54" r="44" fill="rgba(255,255,255,0.25)"/>
            <path d="M0 105 C50 88 100 118 150 100 C200 82 250 108 280 92 L280 148 L0 148 Z" fill="rgba(255,255,255,0.22)"/>
            <path d="M0 120 C60 104 120 130 185 116 C235 105 265 122 280 112 L280 148 L0 148 Z" fill="rgba(255,255,255,0.16)"/>
            <circle cx="52" cy="24" r="3.5" fill="rgba(37,99,235,0.25)"/>
            <circle cx="88" cy="14" r="2.5" fill="rgba(37,99,235,0.18)"/>
            <circle cx="30" cy="48" r="2"   fill="rgba(37,99,235,0.15)"/>
            <circle cx="140" cy="18" r="3"  fill="rgba(99,102,241,0.2)"/>
        </svg>
    </div>
</div>

<!-- ═══ STAT CARDS ═══ -->
<div class="dash-stats">

    <?php if ($role === 'employer'):
        $cards = [
            ['label'=>t('stat_vacancies_posted'), 'val'=>$stat_vacancies,   'color'=>'blue',   'delta'=>['text'=>'','up'=>true],
             'icon'=>'<i data-lucide="briefcase" width="20" height="20"></i>'],
            ['label'=>t('stat_apps_received'),    'val'=>$stat_applications, 'color'=>'green',  'delta'=>$deltaApps,
             'icon'=>'<i data-lucide="users" width="20" height="20"></i>'],
            ['label'=>t('stat_ratings_given'),    'val'=>$stat_ratings,     'color'=>'yellow', 'delta'=>['text'=>'','up'=>true],
             'icon'=>'<i data-lucide="star" width="20" height="20" fill="currentColor"></i>'],
            ['label'=>t('stat_unread'),           'val'=>$stat_unread,      'color'=>'purple', 'delta'=>$deltaMsg,
             'icon'=>'<i data-lucide="message-square" width="20" height="20"></i>'],
        ];
    else:
        $cards = [
            ['label'=>t('stat_open_vacancies'), 'val'=>$stat_vacancies,    'color'=>'blue',   'delta'=>['text'=>'','up'=>true],
             'icon'=>'<i data-lucide="briefcase" width="20" height="20"></i>'],
            ['label'=>t('stat_apps_sent'),       'val'=>$stat_applications, 'color'=>'green', 'delta'=>$deltaApps,
             'icon'=>'<i data-lucide="square-check" width="20" height="20"></i>'],
            ['label'=>t('stat_avg_rating'),      'val'=>$stat_avg_score,   'color'=>'yellow', 'delta'=>['text'=>'','up'=>true],
             'icon'=>'<i data-lucide="star" width="20" height="20" fill="currentColor"></i>'],
            ['label'=>t('stat_unread'),          'val'=>$stat_unread,      'color'=>'purple', 'delta'=>['text'=>'','up'=>true],
             'icon'=>'<i data-lucide="message-square" width="20" height="20"></i>'],
        ];
    endif; ?>

    <?php foreach ($cards as $card): ?>
    <div class="dash-stat dash-stat--<?= $card['color'] ?>">
        <div class="dash-stat__icon"><?= $card['icon'] ?></div>
        <div class="dash-stat__info">
            <div class="dash-stat__val stat-card__value"><?= $card['val'] ?><?php if ($card['color']==='yellow' && $role==='employee'): ?><span style="font-size:13px;color:var(--text-muted);font-weight:500">/10</span><?php endif; ?></div>
            <div class="dash-stat__lbl"><?= $card['label'] ?></div>
        </div>
        <?php if ($card['delta']['text']): ?>
        <span class="dash-stat__delta dash-stat__delta--<?= $card['delta']['up'] ? 'up' : 'down' ?>">
            <?= $card['delta']['text'] ?>
        </span>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
</div>
</div><!-- /.dash-top -->

<!-- ═══ MAIN LAYOUT ═══ -->
<div class="dash-main">

<!-- LEFT column -->
<div class="dash-main__left">

    <!-- Chart -->
    <div class="card card--chart">
        <div class="card__header">
            <h3 class="card__title"><?= $role === 'employer' ? t('activity_7d_employer') : t('activity_7d_employee') ?></h3>
            <div style="display:flex;align-items:center;gap:10px;font-size:11.5px;color:var(--text-muted)">
                <span><span class="chart-legend-dot" style="background:#3b82f6"></span><?= t('chart_apps') ?></span>
                <?php if ($role === 'employer'): ?>
                <span><span class="chart-legend-dot" style="background:#22c55e"></span><?= t('chart_vacs') ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="card__body chart-wrap">
            <?php if ($hasChartData): ?>
                <div class="chart-box"><canvas id="activityChart"></canvas></div>
            <?php else: ?>
                <div class="chart-empty">
                    <div class="chart-empty__icon">
                        <i data-lucide="bar-chart-2" width="60" height="60"></i>
                    </div>
                    <p>Нет активности за последние 7 дней</p>
                    <a href="<?= BASE_URL ?>/pages/vacancies.php" class="btn btn-sm btn-ghost" style="margin-top:4px">
                        <?= $role === 'employer' ? t('post_vacancy').' →' : t('browse_jobs').' →' ?>
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Actions 2×2 grid -->
    <div class="card">
        <div class="card__header">
            <h3 class="card__title"><?= t('quick_actions') ?></h3>
        </div>
        <div class="qa-grid">
        <?php if ($role === 'employer'): ?>
            <a href="<?= BASE_URL ?>/pages/vacancy_create.php" class="qa-tile">
                <div class="qa-tile__icon qai--blue">
                    <i data-lucide="circle-plus" width="20" height="20"></i>
                </div>
                <div class="qa-tile__title"><?= t('post_vacancy') ?></div>
                <div class="qa-tile__sub"><?= t('create_new_vacancy') ?></div>
            </a>
            <a href="<?= BASE_URL ?>/pages/vacancies.php" class="qa-tile">
                <div class="qa-tile__icon qai--green">
                    <i data-lucide="briefcase" width="20" height="20"></i>
                </div>
                <div class="qa-tile__title"><?= t('my_vacancies_short') ?></div>
                <div class="qa-tile__sub"><?= $stat_vacancies ?> <?= t('active_count') ?></div>
            </a>
            <a href="<?= BASE_URL ?>/pages/chat.php" class="qa-tile">
                <?php if ($stat_unread > 0): ?>
                <span class="qa-badge"><?= $stat_unread > 99 ? '99+' : $stat_unread ?></span>
                <?php endif; ?>
                <div class="qa-tile__icon qai--purple">
                    <i data-lucide="message-square" width="20" height="20"></i>
                </div>
                <div class="qa-tile__title"><?= t('nav_messages') ?></div>
                <div class="qa-tile__sub"><?= $msgSub ?></div>
            </a>
            <a href="<?= BASE_URL ?>/pages/ratings.php" class="qa-tile">
                <div class="qa-tile__icon qai--yellow">
                    <i data-lucide="star" width="20" height="20" fill="currentColor"></i>
                </div>
                <div class="qa-tile__title"><?= t('nav_ratings') ?></div>
                <div class="qa-tile__sub"><?= t('rate_employee') ?></div>
            </a>
        <?php else: ?>
            <a href="<?= BASE_URL ?>/pages/vacancies.php" class="qa-tile">
                <div class="qa-tile__icon qai--blue">
                    <i data-lucide="search" width="20" height="20"></i>
                </div>
                <div class="qa-tile__title"><?= t('find_job') ?></div>
                <div class="qa-tile__sub"><?= $stat_vacancies ?> <?= t('open_positions_count') ?></div>
            </a>
            <a href="<?= BASE_URL ?>/pages/resume.php" class="qa-tile">
                <div class="qa-tile__icon qai--green">
                    <i data-lucide="file-text" width="20" height="20"></i>
                </div>
                <div class="qa-tile__title"><?= t('nav_resume') ?></div>
                <div class="qa-tile__sub"><?= t('edit_profile_short') ?></div>
            </a>
            <a href="<?= BASE_URL ?>/pages/chat.php" class="qa-tile">
                <?php if ($stat_unread > 0): ?>
                <span class="qa-badge"><?= $stat_unread > 99 ? '99+' : $stat_unread ?></span>
                <?php endif; ?>
                <div class="qa-tile__icon qai--purple">
                    <i data-lucide="message-square" width="20" height="20"></i>
                </div>
                <div class="qa-tile__title"><?= t('nav_messages') ?></div>
                <div class="qa-tile__sub"><?= $msgSub ?></div>
            </a>
            <a href="<?= BASE_URL ?>/pages/ratings.php" class="qa-tile">
                <div class="qa-tile__icon qai--yellow">
                    <i data-lucide="star" width="20" height="20" fill="currentColor"></i>
                </div>
                <div class="qa-tile__title"><?= t('nav_ratings') ?></div>
                <div class="qa-tile__sub"><?= $stat_avg_score ?>/10</div>
            </a>
        <?php endif; ?>
        </div>
    </div>

    <!-- ── Tables ── -->
    <?php if ($role === 'employer'): ?>

    <div class="card">
        <div class="card__header">
            <h3 class="card__title"><?= t('recent_vacancies') ?></h3>
            <a href="<?= BASE_URL ?>/pages/vacancies.php" class="btn btn-sm btn-ghost"><?= t('view_all') ?></a>
        </div>
        <div class="card__body card__body--no-pad">
            <?php if (empty($recent_vacancies)): ?>
                <div class="empty-state"><?= t('no_vacancies_yet') ?> <a href="<?= BASE_URL ?>/pages/vacancy_create.php"><?= t('post_first') ?></a></div>
            <?php else: ?>
            <table class="data-table">
                <thead><tr><th><?= t('col_title') ?></th><th><?= t('col_location') ?></th><th><?= t('col_type') ?></th><th><?= t('col_status') ?></th><th><?= t('col_date') ?></th></tr></thead>
                <tbody>
                    <?php foreach ($recent_vacancies as $v): ?>
                    <tr>
                        <td><a href="<?= BASE_URL ?>/pages/vacancy_detail.php?id=<?= $v['id'] ?>"><?= htmlspecialchars($v['title']) ?></a></td>
                        <td><?= htmlspecialchars($v['location'] ?: '—') ?></td>
                        <td><span class="tag"><?= htmlspecialchars($v['employment_type']) ?></span></td>
                        <td><span class="badge badge-<?= $v['status']==='active'?'success':($v['status']==='closed'?'danger':'warning') ?>"><?= t('status_'.$v['status']) ?></span></td>
                        <td class="text-muted"><?= date('d M Y', strtotime($v['created_at'])) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>

    <div class="card">
        <div class="card__header">
            <h3 class="card__title"><?= t('recent_applications') ?></h3>
            <a href="<?= BASE_URL ?>/pages/vacancies.php" class="btn btn-sm btn-ghost"><?= t('manage') ?></a>
        </div>
        <div class="card__body card__body--no-pad">
            <?php if (empty($recent_applications)): ?>
                <div class="empty-state"><?= t('no_applications_yet') ?></div>
            <?php else: ?>
            <table class="data-table">
                <thead><tr><th><?= t('col_candidate') ?></th><th><?= t('col_vacancy') ?></th><th><?= t('col_status') ?></th><th><?= t('col_applied') ?></th><th></th></tr></thead>
                <tbody>
                    <?php foreach ($recent_applications as $a): ?>
                    <tr>
                        <td><?= htmlspecialchars($a['candidate']) ?></td>
                        <td class="text-muted"><?= htmlspecialchars($a['vacancy']) ?></td>
                        <td><span class="badge badge-<?= match($a['status']){'accepted'=>'success','rejected'=>'danger','reviewed'=>'blue',default=>'warning'} ?>"><?= t('status_'.$a['status']) ?></span></td>
                        <td class="text-muted"><?= date('d M', strtotime($a['applied_at'])) ?></td>
                        <td>
                            <a href="<?= BASE_URL ?>/pages/resume_view.php?id=<?= $a['employee_id'] ?>"
                               style="display:inline-flex;align-items:center;gap:4px;font-size:12px;color:var(--primary);text-decoration:none;font-weight:500;padding:3px 8px;border-radius:8px;border:1px solid rgba(37,99,235,.2);background:rgba(37,99,235,.06);white-space:nowrap"
                               title="<?= t('open_resume_title') ?>">
                                <i data-lucide="file-text" width="11" height="11"></i>
                                <?= t('nav_resume') ?>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>

    <?php else: /* Employee */ ?>

    <div class="card">
        <div class="card__header">
            <h3 class="card__title"><?= t('my_applications') ?></h3>
            <a href="<?= BASE_URL ?>/pages/vacancies.php" class="btn btn-sm btn-ghost"><?= t('browse_jobs') ?></a>
        </div>
        <div class="card__body card__body--no-pad">
            <?php if (empty($my_applications)): ?>
                <div class="empty-state"><?= t('no_my_applications') ?> <a href="<?= BASE_URL ?>/pages/vacancies.php"><?= t('browse_positions') ?></a>.</div>
            <?php else: ?>
            <table class="data-table">
                <thead><tr><th><?= t('col_vacancy') ?></th><th><?= t('col_employer') ?></th><th><?= t('col_type') ?></th><th><?= t('col_status') ?></th><th><?= t('col_date') ?></th></tr></thead>
                <tbody>
                    <?php foreach ($my_applications as $a): ?>
                    <tr>
                        <td><?= htmlspecialchars($a['title']) ?></td>
                        <td class="text-muted"><?= htmlspecialchars($a['employer']) ?></td>
                        <td><span class="tag"><?= htmlspecialchars($a['employment_type']) ?></span></td>
                        <td><span class="badge badge-<?= match($a['status']){'accepted'=>'success','rejected'=>'danger','reviewed'=>'blue',default=>'warning'} ?>"><?= t('status_'.$a['status']) ?></span></td>
                        <td class="text-muted"><?= date('d M Y', strtotime($a['applied_at'])) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>

    <div class="card">
        <div class="card__header">
            <h3 class="card__title"><?= t('my_ratings') ?></h3>
            <a href="<?= BASE_URL ?>/pages/ratings.php" class="btn btn-sm btn-ghost"><?= t('view_all') ?></a>
        </div>
        <div class="card__body card__body--no-pad">
            <?php if (empty($my_ratings)): ?>
                <div class="empty-state"><?= t('no_ratings_yet') ?></div>
            <?php else: ?>
            <table class="data-table">
                <thead><tr><th><?= t('col_employer') ?></th><th><?= t('col_category') ?></th><th><?= t('col_score') ?></th><th><?= t('col_date') ?></th></tr></thead>
                <tbody>
                    <?php foreach ($my_ratings as $r): ?>
                    <tr>
                        <td><?= htmlspecialchars($r['employer_name']) ?></td>
                        <td class="text-muted"><?= htmlspecialchars($r['category'] ?: t('general_category')) ?></td>
                        <td><strong style="color:var(--primary)"><?= $r['score']*2 ?></strong><span style="color:var(--text-muted);font-size:12px">/10</span></td>
                        <td class="text-muted"><?= date('d M Y', strtotime($r['created_at'])) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>

    <?php endif; ?>

</div><!-- /.dash-main__left -->

<!-- RIGHT column -->
<div class="dash-main__right">

    <!-- Profile completion -->
    <div class="card">
        <div class="card__header" style="padding-bottom:8px">
            <h3 class="card__title" style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--text-muted)">
                <?= t('nav_profile') ?>
            </h3>
            <span style="font-size:14px;font-weight:800;color:<?= $profilePct>=80?'#16a34a':($profilePct>=50?'#2563eb':'#f59e0b') ?>">
                <?= $profilePct ?>%
            </span>
        </div>
        <div class="card__body" style="padding-top:4px">
            <p style="font-size:12px;color:var(--text-muted);margin-bottom:10px"><?= t('profile_completion_label') ?></p>

            <div class="profile-prog-track">
                <div class="profile-prog-fill" style="width:<?= $profilePct ?>%"></div>
            </div>
            <div class="profile-checklist">
                <div class="profile-check-item profile-check-item--done">
                    <div class="profile-check-dot profile-check-dot--done"><i data-lucide="check" width="12" height="12"></i></div>
                    <?= t('profile_check_basic') ?>
                </div>
                <?php foreach ($profileChecks as $pc): ?>
                <div class="profile-check-item <?= $pc['done'] ? 'profile-check-item--done' : '' ?>">
                    <div class="profile-check-dot <?= $pc['done'] ? 'profile-check-dot--done' : 'profile-check-dot--todo' ?>">
                        <?php if ($pc['done']): ?><i data-lucide="check" width="12" height="12"></i><?php endif; ?>
                    </div>
                    <?= $pc['label'] ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php if ($profilePct < 100): ?>
            <a href="<?= BASE_URL ?>/pages/profile.php"
               class="btn btn-primary btn-sm"
               style="width:100%;justify-content:center;margin-top:14px;display:flex">
                <?= t('fill_profile') ?>
            </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Activity feed -->
    <?php if (!empty($activity)): ?>
    <div class="card">
        <div class="card__header">
            <h3 class="card__title" style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--text-muted)"><?= t('recent_events') ?></h3>
        </div>
        <div class="card__body card__body--no-pad">
            <?php
            $feedIcons = [
                'apply'   => '<i data-lucide="square-check" width="11" height="11"></i>',
                'vacancy' => '<i data-lucide="briefcase" width="11" height="11"></i>',
                'rating'  => '<i data-lucide="star" width="11" height="11" fill="currentColor"></i>',
            ];
            ?>
            <div class="feed-list">
            <?php foreach ($activity as $ev): ?>
                <div class="feed-item">
                    <div class="feed-icon feed-icon--<?= $ev['color'] ?>">
                        <?= $feedIcons[$ev['icon']] ?? $feedIcons['apply'] ?>
                    </div>
                    <div class="feed-body">
                        <div class="feed-text"><?= $ev['text'] ?></div>
                        <div class="feed-time"><?= relativeTime($ev['ts']) ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

</div><!-- /.dash-main__right -->
</div><!-- /.dash-main -->

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
window.nexioPage = {
    chartLabels: <?= json_encode($chartLabels) ?>,
    appsData:    <?= json_encode($chartValues) ?>,
    <?php if ($role === 'employer'): ?>
    vacsData:    <?= json_encode($chartVacs) ?>,
    <?php endif; ?>
    labels: {
        apps: <?= json_encode(t('chart_apps')) ?>,
        vacs: <?= json_encode(t('chart_vacs')) ?>
    }
};
</script>
<script type="module" src="<?= BASE_URL ?>/assets/js/pages/dashboard.js"></script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
