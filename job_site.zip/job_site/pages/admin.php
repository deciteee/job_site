<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/i18n.php';
requireAdmin();

$success = '';
$error   = '';

// ── Actions ───────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $myId   = (int)$_SESSION['user_id'];

    if ($action === 'delete_user') {
        $userId = (int)($_POST['user_id'] ?? 0);
        if ($userId && $userId !== $myId) {
            $stmt = $conn->prepare("DELETE FROM users WHERE id=? AND role != 'admin'");
            $stmt->bind_param('i', $userId);
            $stmt->execute() ? $success = 'Пользователь удалён.' : $error = 'Ошибка удаления.';
            $stmt->close();
        }
    }
    if ($action === 'change_role') {
        $userId  = (int)($_POST['user_id'] ?? 0);
        $newRole = $_POST['new_role'] ?? '';
        if ($userId && in_array($newRole, ['employer','employee']) && $userId !== $myId) {
            $stmt = $conn->prepare("UPDATE users SET role=? WHERE id=? AND role != 'admin'");
            $stmt->bind_param('si', $newRole, $userId);
            $stmt->execute() ? $success = 'Роль изменена.' : $error = 'Ошибка изменения роли.';
            $stmt->close();
        }
    }
    if ($action === 'delete_vacancy') {
        $vacId = (int)($_POST['vacancy_id'] ?? 0);
        if ($vacId) {
            $stmt = $conn->prepare("DELETE FROM vacancies WHERE id=?");
            $stmt->bind_param('i', $vacId);
            $stmt->execute() ? $success = 'Вакансия удалена.' : $error = 'Ошибка удаления.';
            $stmt->close();
        }
    }
    if ($action === 'delete_application') {
        $appId = (int)($_POST['app_id'] ?? 0);
        if ($appId) {
            $stmt = $conn->prepare("DELETE FROM applications WHERE id=?");
            $stmt->bind_param('i', $appId);
            $stmt->execute() ? $success = 'Отклик удалён.' : $error = 'Ошибка удаления.';
            $stmt->close();
        }
    }

    header('Location: ' . BASE_URL . '/pages/admin.php?tab=' . ($_POST['tab'] ?? 'users') . ($success ? '&ok=1' : '&fail=1'));
    exit;
}

if (isset($_GET['ok']))   $success = 'Операция выполнена успешно.';
if (isset($_GET['fail'])) $error   = 'Произошла ошибка. Попробуйте ещё раз.';

$tab = in_array($_GET['tab'] ?? '', ['users','vacancies','applications']) ? $_GET['tab'] : 'users';

// ── Stats ─────────────────────────────────────────────────────
$stats = [];
foreach ([
    'employers'    => "SELECT COUNT(*) FROM users WHERE role='employer'",
    'employees'    => "SELECT COUNT(*) FROM users WHERE role='employee'",
    'vacancies'    => "SELECT COUNT(*) FROM vacancies",
    'active_vac'   => "SELECT COUNT(*) FROM vacancies WHERE status='active'",
    'applications' => "SELECT COUNT(*) FROM applications",
    'ratings'      => "SELECT COUNT(*) FROM ratings",
    'messages'     => "SELECT COUNT(*) FROM messages",
] as $key => $sql) {
    $stats[$key] = $conn->query($sql)->fetch_row()[0];
}
$stats['total_users'] = $stats['employers'] + $stats['employees'];

// ── Chart: registrations per day (7 days) ─────────────────────
$chartLabels = []; $regDates = []; $appDates = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $chartLabels[] = date('d M', strtotime($d));
    $regDates[$d]  = 0;
    $appDates[$d]  = 0;
}
$r = $conn->query("SELECT DATE(created_at) d, COUNT(*) c FROM users WHERE created_at >= DATE_SUB(NOW(),INTERVAL 7 DAY) GROUP BY DATE(created_at)");
foreach ($r->fetch_all(MYSQLI_ASSOC) as $row) { if (isset($regDates[$row['d']])) $regDates[$row['d']] = (int)$row['c']; }
$r = $conn->query("SELECT DATE(applied_at) d, COUNT(*) c FROM applications WHERE applied_at >= DATE_SUB(NOW(),INTERVAL 7 DAY) GROUP BY DATE(applied_at)");
foreach ($r->fetch_all(MYSQLI_ASSOC) as $row) { if (isset($appDates[$row['d']])) $appDates[$row['d']] = (int)$row['c']; }
$chartReg = array_values($regDates);
$chartApp = array_values($appDates);

// ── Tab data ──────────────────────────────────────────────────
$users = $conn->query(
    "SELECT id,name,email,role,company,position,created_at FROM users ORDER BY created_at DESC"
)->fetch_all(MYSQLI_ASSOC);

$vacancies = $conn->query(
    "SELECT v.id,v.title,v.status,v.employment_type,v.location,v.created_at,
            u.name AS employer_name, u.company,
            (SELECT COUNT(*) FROM applications a WHERE a.vacancy_id=v.id) AS app_count
     FROM vacancies v JOIN users u ON v.employer_id=u.id ORDER BY v.created_at DESC"
)->fetch_all(MYSQLI_ASSOC);

$applications = $conn->query(
    "SELECT a.id,a.status,a.applied_at,
            ue.name AS employee_name, ue.email AS employee_email,
            v.title AS vacancy_title, uer.name AS employer_name
     FROM applications a
     JOIN users ue    ON a.employee_id=ue.id
     JOIN vacancies v ON a.vacancy_id=v.id
     JOIN users uer   ON v.employer_id=uer.id
     ORDER BY a.applied_at DESC LIMIT 200"
)->fetch_all(MYSQLI_ASSOC);

$pageTitle = 'Администратор';
include __DIR__ . '/../includes/header.php';
?>

<style>
/* ── Admin layout ── */
.admin-layout { display: grid; grid-template-columns: 1fr 250px; gap: 20px; align-items: start; margin-top: 20px; }
.admin-left  { display: flex; flex-direction: column; gap: 18px; min-width: 0; }
.admin-right { display: flex; flex-direction: column; gap: 14px; position: sticky; top: 16px; }
@media (max-width: 960px) { .admin-layout { grid-template-columns: 1fr; } .admin-right { position: static; } }

/* Stat cards row */
.admin-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 0; }
@media (max-width: 800px) { .admin-stats { grid-template-columns: repeat(2, 1fr); } }

/* Tabs */
.admin-tabs { display: flex; gap: 6px; flex-wrap: wrap; }
.admin-tab { display: inline-flex; align-items: center; gap: 6px; padding: 8px 18px; border-radius: 100px; font-size: 13px; font-weight: 500; text-decoration: none; border: 1.5px solid var(--border); color: var(--text-secondary); background: var(--card-bg); transition: all .14s; white-space: nowrap; }
.admin-tab:hover { border-color: var(--primary); color: var(--primary); text-decoration: none; }
.admin-tab.active { background: var(--primary); border-color: var(--primary); color: #fff; }
.admin-tab__cnt { font-size: 11px; font-weight: 700; opacity: .8; }

/* Summary cards on right */
.admin-summary { display: flex; flex-direction: column; }
.admin-summary__row { display: flex; justify-content: space-between; align-items: center; padding: 11px 16px; border-bottom: 1px solid var(--border-light); font-size: 13px; }
.admin-summary__row:last-child { border-bottom: none; }
.admin-summary__label { color: var(--text-secondary); }
.admin-summary__val { font-weight: 700; color: var(--primary); }

/* Quick actions right */
.admin-quick { display: flex; flex-direction: column; gap: 6px; padding: 10px; }
.admin-quick__item { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: var(--radius-lg); border: 1.5px solid var(--border); font-size: 13px; font-weight: 500; color: var(--text-primary); text-decoration: none; transition: all .14s; }
.admin-quick__item:hover { border-color: var(--primary); background: var(--primary-light); color: var(--primary); text-decoration: none; transform: translateX(2px); }

/* danger button */
.danger-btn:hover { color: var(--danger) !important; border-color: var(--danger) !important; }
</style>

<!-- ── Welcome banner ── -->
<div class="dash-welcome">
    <div class="dash-welcome__left">
        <div class="dash-welcome__greeting">Панель управления</div>
        <div class="dash-welcome__name" style="font-size:22px;display:inline-flex;align-items:center;gap:8px">Администратор <i data-lucide="shield" width="20" height="20"></i></div>
        <div class="dash-welcome__sub">Управление пользователями, вакансиями и откликами платформы.</div>
    </div>
    <div class="dash-welcome__actions">
        <a href="<?= BASE_URL ?>/pages/vacancies.php" class="btn-welcome-primary">Все вакансии</a>
        <a href="<?= BASE_URL ?>/pages/ratings.php"   class="btn-welcome-ghost">Оценки</a>
    </div>
</div>

<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-error"><?=   htmlspecialchars($error)   ?></div><?php endif; ?>

<!-- ── Stat cards ── -->
<div class="admin-stats">
    <div class="stat-card stat-card--blue">
        <div class="stat-card__icon stat-icon--blue">
            <i data-lucide="users" width="22" height="22"></i>
        </div>
        <div class="stat-card__body">
            <div class="stat-card__value"><?= $stats['total_users'] ?></div>
            <div class="stat-card__label">Пользователей</div>
        </div>
    </div>
    <div class="stat-card stat-card--green">
        <div class="stat-card__icon stat-icon--green">
            <i data-lucide="briefcase" width="22" height="22"></i>
        </div>
        <div class="stat-card__body">
            <div class="stat-card__value"><?= $stats['active_vac'] ?><span style="font-size:14px;color:#94a3b8"> / <?= $stats['vacancies'] ?></span></div>
            <div class="stat-card__label">Активных вакансий</div>
        </div>
    </div>
    <div class="stat-card stat-card--yellow">
        <div class="stat-card__icon stat-icon--yellow">
            <i data-lucide="square-check" width="22" height="22"></i>
        </div>
        <div class="stat-card__body">
            <div class="stat-card__value"><?= $stats['applications'] ?></div>
            <div class="stat-card__label">Откликов</div>
        </div>
    </div>
    <div class="stat-card stat-card--purple">
        <div class="stat-card__icon stat-icon--purple">
            <i data-lucide="message-square" width="22" height="22"></i>
        </div>
        <div class="stat-card__body">
            <div class="stat-card__value"><?= $stats['messages'] ?></div>
            <div class="stat-card__label">Сообщений</div>
        </div>
    </div>
</div>

<!-- ── Main layout ── -->
<div class="admin-layout">

<!-- LEFT: chart + tabs + tables -->
<div class="admin-left">

    <!-- Chart -->
    <div class="card">
        <div class="card__header">
            <h3 class="card__title">Активность платформы за 7 дней</h3>
            <span style="font-size:11px;color:var(--text-muted)">
                <span style="color:#2563eb">●</span> Регистрации &nbsp;
                <span style="color:#16a34a">●</span> Отклики
            </span>
        </div>
        <div class="card__body" style="padding:4px 4px 0">
            <canvas id="adminChart" height="90"></canvas>
        </div>
    </div>

    <!-- Tabs -->
    <div class="admin-tabs">
        <a href="?tab=users"        class="admin-tab <?= $tab==='users'        ? 'active':'' ?>">
            Пользователи <span class="admin-tab__cnt"><?= count($users) ?></span>
        </a>
        <a href="?tab=vacancies"    class="admin-tab <?= $tab==='vacancies'    ? 'active':'' ?>">
            Вакансии <span class="admin-tab__cnt"><?= count($vacancies) ?></span>
        </a>
        <a href="?tab=applications" class="admin-tab <?= $tab==='applications' ? 'active':'' ?>">
            Отклики <span class="admin-tab__cnt"><?= count($applications) ?></span>
        </a>
    </div>

    <!-- ── USERS ── -->
    <?php if ($tab === 'users'): ?>
    <div class="card">
        <div class="card__header">
            <h3 class="card__title">Все пользователи</h3>
            <span class="text-muted" style="font-size:12px"><?= count($users) ?> записей</span>
        </div>
        <div class="card__body card__body--no-pad">
            <table class="data-table">
                <thead>
                    <tr><th>ID</th><th>Имя</th><th>Email</th><th>Роль</th><th>Компания / Должность</th><th>Регистрация</th><th>Действия</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $u): ?>
                    <tr>
                        <td class="text-muted small"><?= $u['id'] ?></td>
                        <td><strong><?= htmlspecialchars($u['name']) ?></strong></td>
                        <td class="text-muted small"><?= htmlspecialchars($u['email']) ?></td>
                        <td>
                            <?php if ($u['role']==='admin'): ?>
                                <span class="badge badge-danger">Админ</span>
                            <?php elseif ($u['role']==='employer'): ?>
                                <span class="badge badge-blue">Работодатель</span>
                            <?php else: ?>
                                <span class="badge badge-success">Соискатель</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-muted small">
                            <?= htmlspecialchars($u['company'] ?: '—') ?>
                            <?php if ($u['position']): ?> · <?= htmlspecialchars($u['position']) ?><?php endif; ?>
                        </td>
                        <td class="text-muted small"><?= date('d.m.Y', strtotime($u['created_at'])) ?></td>
                        <td>
                            <?php if ($u['role'] !== 'admin'): ?>
                            <div style="display:flex;gap:6px;align-items:center">
                                <form method="POST" class="inline-form">
                                    <input type="hidden" name="action"  value="change_role">
                                    <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                    <input type="hidden" name="tab"     value="users">
                                    <select name="new_role" class="form-control form-control--sm" onchange="this.form.submit()">
                                        <option value="employer" <?= $u['role']==='employer'?'selected':'' ?>>Работодатель</option>
                                        <option value="employee" <?= $u['role']==='employee'?'selected':'' ?>>Соискатель</option>
                                    </select>
                                </form>
                                <form method="POST" class="inline-form" onsubmit="return confirm('Удалить пользователя «<?= htmlspecialchars(addslashes($u['name'])) ?>»?')">
                                    <input type="hidden" name="action"  value="delete_user">
                                    <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                    <input type="hidden" name="tab"     value="users">
                                    <button type="submit" class="btn btn-ghost btn-sm danger-btn" title="Удалить">
                                        <i data-lucide="trash-2" width="13" height="13"></i>
                                    </button>
                                </form>
                            </div>
                            <?php else: ?><span class="text-muted small">—</span><?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ── VACANCIES ── -->
    <?php elseif ($tab === 'vacancies'): ?>
    <div class="card">
        <div class="card__header">
            <h3 class="card__title">Все вакансии</h3>
            <span class="text-muted" style="font-size:12px"><?= count($vacancies) ?> записей</span>
        </div>
        <div class="card__body card__body--no-pad">
            <?php if (empty($vacancies)): ?>
                <div class="empty-state">Вакансий пока нет.</div>
            <?php else: ?>
            <table class="data-table">
                <thead>
                    <tr><th>ID</th><th>Вакансия</th><th>Работодатель</th><th>Тип / Место</th><th>Статус</th><th>Откликов</th><th>Дата</th><th></th></tr>
                </thead>
                <tbody>
                    <?php foreach ($vacancies as $vac): ?>
                    <tr>
                        <td class="text-muted small"><?= $vac['id'] ?></td>
                        <td><a href="<?= BASE_URL ?>/pages/vacancy_detail.php?id=<?= $vac['id'] ?>" target="_blank"><strong><?= htmlspecialchars($vac['title']) ?></strong></a></td>
                        <td class="text-muted small"><?= htmlspecialchars($vac['company'] ?: $vac['employer_name']) ?></td>
                        <td class="text-muted small"><?= htmlspecialchars(ucfirst(str_replace('-',' ',$vac['employment_type']))) ?><?php if ($vac['location']): ?> · <?= htmlspecialchars($vac['location']) ?><?php endif; ?></td>
                        <td><span class="badge badge-<?= $vac['status']==='active'?'success':($vac['status']==='closed'?'danger':'warning') ?>"><?= ucfirst($vac['status']) ?></span></td>
                        <td class="text-muted small"><?= $vac['app_count'] ?></td>
                        <td class="text-muted small"><?= date('d.m.Y', strtotime($vac['created_at'])) ?></td>
                        <td>
                            <form method="POST" class="inline-form" onsubmit="return confirm('Удалить «<?= htmlspecialchars(addslashes($vac['title'])) ?>»?')">
                                <input type="hidden" name="action"     value="delete_vacancy">
                                <input type="hidden" name="vacancy_id" value="<?= $vac['id'] ?>">
                                <input type="hidden" name="tab"        value="vacancies">
                                <button type="submit" class="btn btn-ghost btn-sm danger-btn">
                                    <i data-lucide="trash-2" width="13" height="13"></i>
                                    Удалить
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>

    <!-- ── APPLICATIONS ── -->
    <?php elseif ($tab === 'applications'): ?>
    <div class="card">
        <div class="card__header">
            <h3 class="card__title">Все отклики</h3>
            <span class="text-muted" style="font-size:12px">последние 200</span>
        </div>
        <div class="card__body card__body--no-pad">
            <?php if (empty($applications)): ?>
                <div class="empty-state">Откликов пока нет.</div>
            <?php else: ?>
            <table class="data-table">
                <thead>
                    <tr><th>ID</th><th>Соискатель</th><th>Вакансия</th><th>Работодатель</th><th>Статус</th><th>Дата</th><th></th></tr>
                </thead>
                <tbody>
                    <?php foreach ($applications as $app): ?>
                    <tr>
                        <td class="text-muted small"><?= $app['id'] ?></td>
                        <td><strong><?= htmlspecialchars($app['employee_name']) ?></strong><br><span class="text-muted small"><?= htmlspecialchars($app['employee_email']) ?></span></td>
                        <td><?= htmlspecialchars($app['vacancy_title']) ?></td>
                        <td class="text-muted small"><?= htmlspecialchars($app['employer_name']) ?></td>
                        <td><span class="badge badge-<?= match($app['status']){'accepted'=>'success','rejected'=>'danger','reviewed'=>'blue',default=>'warning'} ?>"><?= ucfirst($app['status']) ?></span></td>
                        <td class="text-muted small"><?= date('d.m.Y', strtotime($app['applied_at'])) ?></td>
                        <td>
                            <form method="POST" class="inline-form" onsubmit="return confirm('Удалить этот отклик?')">
                                <input type="hidden" name="action" value="delete_application">
                                <input type="hidden" name="app_id" value="<?= $app['id'] ?>">
                                <input type="hidden" name="tab"    value="applications">
                                <button type="submit" class="btn btn-ghost btn-sm danger-btn">
                                    <i data-lucide="trash-2" width="13" height="13"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

</div><!-- /.admin-left -->

<!-- RIGHT: summary + quick links -->
<div class="admin-right">

    <!-- Platform summary -->
    <div class="card">
        <div class="card__header" style="padding-bottom:4px">
            <h3 class="card__title" style="font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:var(--text-muted)">Сводка платформы</h3>
        </div>
        <div class="admin-summary">
            <div class="admin-summary__row">
                <span class="admin-summary__label">Работодателей</span>
                <span class="admin-summary__val" style="color:var(--icon-blue-clr)"><?= $stats['employers'] ?></span>
            </div>
            <div class="admin-summary__row">
                <span class="admin-summary__label">Соискателей</span>
                <span class="admin-summary__val" style="color:var(--icon-green-clr)"><?= $stats['employees'] ?></span>
            </div>
            <div class="admin-summary__row">
                <span class="admin-summary__label">Всего вакансий</span>
                <span class="admin-summary__val" style="color:var(--icon-purple-clr)"><?= $stats['vacancies'] ?></span>
            </div>
            <div class="admin-summary__row">
                <span class="admin-summary__label">Оценок выставлено</span>
                <span class="admin-summary__val" style="color:#fbbf24"><?= $stats['ratings'] ?></span>
            </div>
            <div class="admin-summary__row">
                <span class="admin-summary__label">Сообщений</span>
                <span class="admin-summary__val" style="color:var(--info)"><?= $stats['messages'] ?></span>
            </div>
        </div>
    </div>

    <!-- Quick nav -->
    <div class="card">
        <div class="card__header" style="padding-bottom:4px">
            <h3 class="card__title" style="font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:var(--text-muted)">Перейти</h3>
        </div>
        <div class="admin-quick">
            <a href="?tab=users"        class="admin-quick__item <?= $tab==='users'?'active':'' ?>">
                <i data-lucide="users" width="16" height="16"></i>
                Пользователи
            </a>
            <a href="?tab=vacancies"    class="admin-quick__item <?= $tab==='vacancies'?'active':'' ?>">
                <i data-lucide="briefcase" width="16" height="16"></i>
                Вакансии
            </a>
            <a href="?tab=applications" class="admin-quick__item <?= $tab==='applications'?'active':'' ?>">
                <i data-lucide="square-check" width="16" height="16"></i>
                Отклики
            </a>
            <a href="<?= BASE_URL ?>/pages/dashboard.php" class="admin-quick__item">
                <i data-lucide="layout-grid" width="16" height="16"></i>
                Дашборд
            </a>
            <a href="<?= BASE_URL ?>/" class="admin-quick__item">
                <i data-lucide="home" width="16" height="16"></i>
                Главная страница
            </a>
        </div>
    </div>

</div><!-- /.admin-right -->
</div><!-- /.admin-layout -->

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
window.nexioPage = {
    chartLabels: <?= json_encode($chartLabels) ?>,
    chartReg:    <?= json_encode($chartReg) ?>,
    chartApp:    <?= json_encode($chartApp) ?>
};
</script>
<script type="module" src="<?= BASE_URL ?>/assets/js/pages/admin.js"></script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
