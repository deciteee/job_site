<?php
session_start();
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();

header('Content-Type: application/json');
$uid = (int)$_SESSION['user_id'];
$vid = (int)($_POST['vacancy_id'] ?? 0);
if (!$vid) { echo json_encode(['error' => 'invalid']); exit; }

$check = $conn->prepare("SELECT id FROM saved_vacancies WHERE user_id=? AND vacancy_id=?");
$check->bind_param('ii', $uid, $vid);
$check->execute();
$exists = $check->get_result()->fetch_assoc();
$check->close();

if ($exists) {
    $s = $conn->prepare("DELETE FROM saved_vacancies WHERE user_id=? AND vacancy_id=?");
    $s->bind_param('ii', $uid, $vid); $s->execute(); $s->close();
    echo json_encode(['saved' => false]);
} else {
    $s = $conn->prepare("INSERT IGNORE INTO saved_vacancies (user_id, vacancy_id) VALUES (?,?)");
    $s->bind_param('ii', $uid, $vid); $s->execute(); $s->close();
    echo json_encode(['saved' => true]);
}
