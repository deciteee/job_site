<?php
session_start();
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();

header('Content-Type: application/json');

if (!isEmployer()) { echo json_encode(['error' => 'forbidden']); exit; }

$uid = (int)$_SESSION['user_id'];
$vid = (int)($_POST['vacancy_id'] ?? 0);
$act = $_POST['action'] ?? 'hide'; // hide | show

if (!$vid) { echo json_encode(['error' => 'invalid']); exit; }

// Only the owner can hide/show
$chk = $conn->prepare("SELECT status FROM vacancies WHERE id=? AND employer_id=?");
$chk->bind_param('ii', $vid, $uid);
$chk->execute();
$row = $chk->get_result()->fetch_assoc();
$chk->close();

if (!$row) { echo json_encode(['error' => 'not_found']); exit; }

$newStatus = $act === 'hide' ? 'closed' : 'active';
$upd = $conn->prepare("UPDATE vacancies SET status=? WHERE id=? AND employer_id=?");
$upd->bind_param('sii', $newStatus, $vid, $uid);
$upd->execute();
$upd->close();

echo json_encode(['status' => $newStatus]);
