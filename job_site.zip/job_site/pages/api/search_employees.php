<?php
session_start();
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();

header('Content-Type: application/json');

if (!isEmployer()) { echo json_encode([]); exit; }

$q = trim($_GET['q'] ?? '');
if (strlen($q) < 1) { echo json_encode([]); exit; }

$like = '%' . $q . '%';
$stmt = $conn->prepare(
    "SELECT id, name, position, avatar
     FROM users WHERE role='employee' AND name LIKE ?
     ORDER BY name LIMIT 10"
);
$stmt->bind_param('s', $like);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

echo json_encode($rows);
