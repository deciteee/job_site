<?php
session_start();
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();

if (!isEmployee()) {
    header('Location: ' . BASE_URL . '/pages/dashboard.php');
    exit;
}

$uid      = (int)$_SESSION['user_id'];
$vacancyId = (int)($_POST['vacancy_id'] ?? 0);

if (!$vacancyId) {
    header('Location: ' . BASE_URL . '/pages/vacancies.php');
    exit;
}

// Only allow withdrawal of pending applications
$stmt = $conn->prepare(
    "DELETE FROM applications WHERE vacancy_id=? AND employee_id=? AND status='pending'"
);
$stmt->bind_param('ii', $vacancyId, $uid);
$stmt->execute();
$stmt->close();

header('Location: ' . BASE_URL . '/pages/vacancy_detail.php?id=' . $vacancyId . '&withdrawn=1');
exit;
