<?php
session_start();
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();

header('Content-Type: application/json');

if (!isEmployee()) { echo json_encode(['error' => 'forbidden']); exit; }

$uid = (int)$_SESSION['user_id'];

if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['error' => 'no_file']); exit;
}

$file      = $_FILES['file'];
$maxSize   = 5 * 1024 * 1024; // 5 MB
$allowed   = ['application/pdf', 'image/jpeg', 'image/png'];
$allowedExt = ['pdf', 'jpg', 'jpeg', 'png'];

if ($file['size'] > $maxSize) { echo json_encode(['error' => 'too_large']); exit; }

$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if (!in_array($ext, $allowedExt)) { echo json_encode(['error' => 'bad_type']); exit; }

// Validate MIME via finfo
$finfo = new finfo(FILEINFO_MIME_TYPE);
$mime  = $finfo->file($file['tmp_name']);
if (!in_array($mime, $allowed)) { echo json_encode(['error' => 'bad_mime']); exit; }

$fileType    = trim($_POST['file_type'] ?? 'other');
if (!in_array($fileType, ['diploma','certificate','other'])) $fileType = 'other';

$origName  = basename($file['name']);
$safeName  = $uid . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
$destDir   = __DIR__ . '/../../assets/uploads/resume/';
$dest      = $destDir . $safeName;

if (!move_uploaded_file($file['tmp_name'], $dest)) {
    echo json_encode(['error' => 'move_failed']); exit;
}

$stmt = $conn->prepare("INSERT INTO resume_files (user_id, filename, original_name, file_type) VALUES (?,?,?,?)");
$stmt->bind_param('isss', $uid, $safeName, $origName, $fileType);
$stmt->execute();
$newId = $conn->insert_id;

echo json_encode([
    'id'            => $newId,
    'filename'      => $safeName,
    'original_name' => $origName,
    'file_type'     => $fileType,
]);
