<?php
session_start();
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();

header('Content-Type: application/json');

if (!isEmployee()) { echo json_encode(['error' => 'forbidden']); exit; }

$uid  = (int)$_SESSION['user_id'];
$type = $_POST['type'] ?? '';

switch ($type) {

    case 'main':
        $about  = trim($_POST['about']  ?? '');
        $skills = trim($_POST['skills'] ?? '');
        $conn->prepare("INSERT INTO resumes (user_id,about,skills) VALUES (?,?,?)
            ON DUPLICATE KEY UPDATE about=VALUES(about), skills=VALUES(skills), updated_at=NOW()")
            ->execute_query([$uid, $about, $skills]);
        echo json_encode(['ok' => true]);
        break;

    case 'exp':
        $pos   = trim($_POST['position']    ?? '');
        $comp  = trim($_POST['company']     ?? '');
        $from  = trim($_POST['date_from']   ?? '');
        $to    = trim($_POST['date_to']     ?? '');
        $curr  = (int)($_POST['is_current'] ?? 0);
        $desc  = trim($_POST['description'] ?? '');
        if (!$pos || !$comp) { echo json_encode(['error' => 'invalid']); exit; }
        $stmt = $conn->prepare("INSERT INTO resume_experiences (user_id,position,company,date_from,date_to,is_current,description) VALUES (?,?,?,?,?,?,?)");
        $stmt->bind_param('issssss', $uid, $pos, $comp, $from, $to, $curr, $desc);
        $stmt->execute();
        echo json_encode(['id' => $conn->insert_id]);
        break;

    case 'edu':
        $inst   = trim($_POST['institution'] ?? '');
        $degree = trim($_POST['degree']      ?? '');
        $yfrom  = (int)($_POST['year_from']  ?? 0) ?: null;
        $yto    = (int)($_POST['year_to']    ?? 0) ?: null;
        if (!$inst) { echo json_encode(['error' => 'invalid']); exit; }
        $stmt = $conn->prepare("INSERT INTO resume_educations (user_id,institution,degree,year_from,year_to) VALUES (?,?,?,?,?)");
        $stmt->bind_param('issss', $uid, $inst, $degree, $yfrom, $yto);
        $stmt->execute();
        echo json_encode(['id' => $conn->insert_id]);
        break;

    case 'delete_exp':
        $id = (int)($_POST['id'] ?? 0);
        $conn->prepare("DELETE FROM resume_experiences WHERE id=? AND user_id=?")->execute_query([$id, $uid]);
        echo json_encode(['ok' => true]);
        break;

    case 'delete_edu':
        $id = (int)($_POST['id'] ?? 0);
        $conn->prepare("DELETE FROM resume_educations WHERE id=? AND user_id=?")->execute_query([$id, $uid]);
        echo json_encode(['ok' => true]);
        break;

    case 'delete_file':
        $id = (int)($_POST['id'] ?? 0);
        $row = $conn->prepare("SELECT filename FROM resume_files WHERE id=? AND user_id=?");
        $row->bind_param('ii', $id, $uid); $row->execute();
        $file = $row->get_result()->fetch_assoc(); $row->close();
        if ($file) {
            $path = __DIR__ . '/../../assets/uploads/resume/' . $file['filename'];
            if (file_exists($path)) unlink($path);
            $conn->prepare("DELETE FROM resume_files WHERE id=? AND user_id=?")->execute_query([$id, $uid]);
        }
        echo json_encode(['ok' => true]);
        break;

    default:
        echo json_encode(['error' => 'unknown_type']);
}
