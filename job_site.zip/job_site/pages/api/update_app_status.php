<?php
session_start();
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();

header('Content-Type: application/json');

if (!isEmployer()) { echo json_encode(['error' => 'forbidden']); exit; }

$uid    = (int)$_SESSION['user_id'];
$appId  = (int)($_POST['app_id']     ?? 0);
$status = trim($_POST['new_status']  ?? '');
$allowed = ['pending', 'reviewed', 'accepted', 'rejected'];

if (!$appId || !in_array($status, $allowed)) {
    echo json_encode(['error' => 'invalid']); exit;
}

// Only allow update if this employer owns the vacancy
$stmt = $conn->prepare(
    "UPDATE applications a
     JOIN vacancies v ON a.vacancy_id = v.id
     SET a.status = ?
     WHERE a.id = ? AND v.employer_id = ?"
);
$stmt->bind_param('sii', $status, $appId, $uid);
$stmt->execute();

$ok = $stmt->affected_rows > 0;
$stmt->close();

// Send email notification to employee on meaningful status changes
if ($ok && in_array($status, ['accepted', 'rejected', 'reviewed'])) {
    $stmt2 = $conn->prepare(
        "SELECT u.email, u.name, v.title, v.id AS vac_id
         FROM applications a
         JOIN users u ON a.employee_id = u.id
         JOIN vacancies v ON a.vacancy_id = v.id
         WHERE a.id = ?"
    );
    $stmt2->bind_param('i', $appId);
    $stmt2->execute();
    $row = $stmt2->get_result()->fetch_assoc();
    $stmt2->close();

    if ($row) {
        require_once __DIR__ . '/../../includes/mailer.php';
        $url = BASE_URL . '/pages/vacancy_detail.php?id=' . $row['vac_id'];
        sendStatusUpdateNotification($row['email'], $row['name'], $row['title'], $status, $url);
    }
}

echo json_encode(['ok' => true, 'status' => $status]);
