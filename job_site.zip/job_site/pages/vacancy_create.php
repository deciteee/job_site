<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('employer');

$uid   = $_SESSION['user_id'];
$error = '';
$success = '';

try { $conn->query("ALTER TABLE vacancies ADD COLUMN contact_phone VARCHAR(30) DEFAULT '' AFTER expires_at"); } catch (\mysqli_sql_exception $e) {}

// ── Edit mode ─────────────────────────────────────────────────
$editId = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$editing = false;
$vacancy = [];

if ($editId) {
    $stmt = $conn->prepare("SELECT * FROM vacancies WHERE id=? AND employer_id=?");
    $stmt->bind_param('ii', $editId, $uid);
    $stmt->execute();
    $vacancy = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($vacancy) $editing = true;
    else { header('Location: ' . BASE_URL . '/pages/vacancies.php'); exit; }
}

// ── Handle POST ───────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title     = trim($_POST['title']   ?? '');
    $desc      = trim($_POST['description'] ?? '');
    $req       = trim($_POST['requirements'] ?? '');
    $salMin    = (int)($_POST['salary_min'] ?? 0);
    $salMax    = (int)($_POST['salary_max'] ?? 0);
    $loc       = trim($_POST['location'] ?? '');
    $type      = $_POST['employment_type'] ?? 'full-time';
    $status    = $_POST['status'] ?? 'active';
    $expiresAt    = trim($_POST['expires_at'] ?? '');
    if ($expiresAt && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $expiresAt)) $expiresAt = '';
    if ($expiresAt && (int)substr($expiresAt, 0, 4) < (int)date('Y')) $expiresAt = '';
    $expiresAtBind  = $expiresAt ?: null;
    $contactPhone   = trim($_POST['contact_phone'] ?? '');
    // Keep existing cover unless a new cropped image was submitted
    $coverImage = $editing ? ($vacancy['cover_image'] ?? 'default') : 'default';
    $base64Raw  = trim($_POST['cover_base64'] ?? '');
    if ($base64Raw && str_starts_with($base64Raw, 'data:image/')) {
        $data = base64_decode(preg_replace('/^data:image\/\w+;base64,/', '', $base64Raw));
        if ($data !== false && strlen($data) <= 5 * 1024 * 1024) {
            $uploadDir = __DIR__ . '/../assets/uploads/covers/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            $filename = 'cover_' . $uid . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.jpg';
            if (file_put_contents($uploadDir . $filename, $data)) {
                if ($editing && isset($vacancy['cover_image']) && str_contains($vacancy['cover_image'], '.')) {
                    $old = $uploadDir . $vacancy['cover_image'];
                    if (file_exists($old)) unlink($old);
                }
                $coverImage = $filename;
            }
        }
    } elseif (isset($_POST['cover_remove'])) {
        $coverImage = 'default';
    }

    $allowed_types   = ['full-time','part-time','remote','contract'];
    $allowed_status  = ['active','closed','draft'];

    if (!$title || !$desc) {
        $error = t('err_fill_all');
    } elseif (!in_array($type, $allowed_types) || !in_array($status, $allowed_status)) {
        $error = t('err_fill_all');
    } else {
        if ($editing) {
            $salMinBind = $salMin ?: null;
            $salMaxBind = $salMax ?: null;
            $expiresAtBind = $expiresAt ?: null;
            $stmt = $conn->prepare(
                "UPDATE vacancies SET title=?, description=?, requirements=?,
                 salary_min=?, salary_max=?, location=?, employment_type=?, status=?,
                 expires_at=?, contact_phone=?, cover_image=?
                 WHERE id=? AND employer_id=?"
            );
            $stmt->bind_param('sssiissssssii',
                $title, $desc, $req, $salMinBind, $salMaxBind, $loc, $type, $status, $expiresAtBind, $contactPhone, $coverImage,
                $editId, $uid
            );
            $stmt->execute();
            $stmt->close();
            $success = t('save_changes') . ' ✓';
            $vacancy = array_merge($vacancy, [
                'title'=>$title,'description'=>$desc,'requirements'=>$req,
                'salary_min'=>$salMin,'salary_max'=>$salMax,'location'=>$loc,
                'employment_type'=>$type,'status'=>$status,'expires_at'=>$expiresAt
            ]);
        } else {
            $stmt = $conn->prepare(
                "INSERT INTO vacancies (employer_id,title,description,requirements,salary_min,salary_max,location,employment_type,status,expires_at,contact_phone,cover_image)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"
            );
            $salMinBind = $salMin ?: null;
            $salMaxBind = $salMax ?: null;
            $stmt->bind_param('isssiissssss',
                $uid, $title, $desc, $req, $salMinBind, $salMaxBind, $loc, $type, $status, $expiresAtBind, $contactPhone, $coverImage
            );
            if ($stmt->execute()) {
                $newId = $stmt->insert_id;
                $stmt->close();
                header('Location: ' . BASE_URL . '/pages/vacancy_detail.php?id=' . $newId . '&created=1');
                exit;
            } else {
                $error = t('err_register_fail');
                $stmt->close();
            }
        }
    }
}

$pageTitle = $editing ? t('edit_vacancy') : t('post_new_vacancy');
include __DIR__ . '/../includes/header.php';

$typeOptions = [
    'full-time' => t('type_full_time'),
    'part-time'  => t('type_part_time'),
    'remote'     => t('type_remote'),
    'contract'   => t('type_contract'),
];
$statusOptions = [
    'active' => t('status_active'),
    'draft'  => t('status_draft'),
    'closed' => t('status_closed'),
];
?>

<div class="page-header">
    <div>
        <h2 class="page-title"><?= $editing ? t('edit_vacancy') : t('post_new_vacancy') ?></h2>
        <p class="page-subtitle">
            <?= $editing ? t('vac_edit_subtitle') : t('vac_create_subtitle') ?>
        </p>
    </div>
    <a href="<?= BASE_URL ?>/pages/vacancies.php" class="btn btn-ghost"><?= t('back_to_vacancies') ?></a>
</div>

<?php if ($error): ?>
    <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>
<?php if ($success): ?>
    <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<div class="form-page-layout">
    <div class="card form-card">
        <div class="card__header">
            <h3 class="card__title"><?= t('vac_job_details') ?></h3>
        </div>
        <div class="card__body">
            <form method="POST" enctype="multipart/form-data" novalidate>

                <div class="form-group">
                    <label class="form-label" for="title"><?= t('job_title') ?> <span class="req">*</span></label>
                    <input class="form-control" type="text" id="title" name="title"
                           value="<?= htmlspecialchars($vacancy['title'] ?? '') ?>"
                           placeholder="<?= t('job_title_ph') ?>" required>
                </div>

                <?php
                require_once __DIR__ . '/../includes/covers.php';
                $existingCover = $vacancy['cover_image'] ?? '';
                $hasUpload = $existingCover && str_contains($existingCover, '.');
                ?>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.2/cropper.min.css">

                <div class="form-group">
                    <label class="form-label">
                        Обложка вакансии
                        <span style="font-weight:400;color:var(--text-muted)">(JPG/PNG/WebP, макс. 5 МБ)</span>
                    </label>

                    <!-- Preview zone -->
                    <div id="coverZone"
                         onclick="document.getElementById('coverFile').click()"
                         style="margin-top:8px;border:2px dashed var(--border);border-radius:14px;
                                overflow:hidden;cursor:pointer;transition:border-color .15s;
                                height:180px;position:relative;display:flex;align-items:center;justify-content:center;
                                background:var(--border-light)"
                         onmouseenter="this.style.borderColor='var(--primary)'"
                         onmouseleave="this.style.borderColor='var(--border)'">
                        <?php if ($hasUpload): ?>
                            <img src="<?= BASE_URL ?>/assets/uploads/covers/<?= htmlspecialchars($existingCover) ?>"
                                 style="width:100%;height:100%;object-fit:cover;display:block">
                            <button type="button" onclick="event.stopPropagation();removeCover()"
                                    style="position:absolute;top:8px;right:8px;width:30px;height:30px;
                                           border-radius:50%;background:rgba(0,0,0,.6);border:none;color:#fff;
                                           cursor:pointer;font-size:18px;line-height:1;display:flex;align-items:center;justify-content:center">×</button>
                        <?php else: ?>
                            <div id="coverPlaceholder" style="text-align:center;pointer-events:none;padding:24px">
                                <i data-lucide="image" width="40" height="40" stroke-width="1.5" style="color:var(--text-muted);margin-bottom:10px"></i>
                                <div style="font-size:14px;font-weight:600;color:var(--text-primary);margin-bottom:4px">Нажмите чтобы выбрать фото</div>
                                <div style="font-size:12px;color:var(--text-muted)">JPG, PNG или WebP</div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <input type="file" id="coverFile" accept="image/jpeg,image/png,image/webp"
                           style="display:none" onchange="openCropper(this)">
                    <input type="hidden" name="cover_base64" id="coverBase64">
                    <input type="hidden" name="cover_remove"  id="coverRemoveFlag" value="">
                </div>

                <!-- Cropper modal -->
                <div id="cropModal" style="display:none;position:fixed;inset:0;z-index:9999;
                     background:rgba(0,0,0,.75);align-items:center;justify-content:center">
                    <div style="background:var(--card-bg);border-radius:18px;padding:24px;
                                width:min(680px,95vw);max-height:92vh;overflow:auto;box-shadow:0 24px 64px rgba(0,0,0,.4)">
                        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
                            <span style="font-size:16px;font-weight:700;color:var(--text-primary)">Обрезать фото</span>
                            <button type="button" onclick="cancelCrop()"
                                    style="width:30px;height:30px;border-radius:50%;border:1px solid var(--border);
                                           background:var(--border-light);cursor:pointer;font-size:18px;color:var(--text-muted);
                                           display:flex;align-items:center;justify-content:center">×</button>
                        </div>
                        <div style="max-height:420px;overflow:hidden;border-radius:10px;background:#000">
                            <img id="cropImage" style="max-width:100%;display:block">
                        </div>
                        <div style="display:flex;gap:8px;margin-top:16px;flex-wrap:wrap">
                            <button type="button" onclick="setCropRatio(NaN)"
                                    class="btn btn-ghost btn-sm" style="font-size:12px">Свободно</button>
                            <button type="button" onclick="setCropRatio(1)"
                                    class="btn btn-ghost btn-sm" style="font-size:12px">1:1</button>
                            <button type="button" onclick="setCropRatio(16/9)"
                                    class="btn btn-ghost btn-sm" style="font-size:12px">16:9</button>
                            <button type="button" onclick="setCropRatio(4/3)"
                                    class="btn btn-ghost btn-sm" style="font-size:12px">4:3</button>
                            <div style="flex:1"></div>
                            <button type="button" onclick="cancelCrop()" class="btn btn-ghost">Отмена</button>
                            <button type="button" onclick="applyCrop()" class="btn btn-primary">Применить</button>
                        </div>
                    </div>
                </div>

                <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.2/cropper.min.js"></script>
                <script>
                let cropper = null;

                function openCropper(input) {
                    if (!input.files || !input.files[0]) return;
                    const reader = new FileReader();
                    reader.onload = e => {
                        const img = document.getElementById('cropImage');
                        img.src = e.target.result;
                        document.getElementById('cropModal').style.display = 'flex';
                        if (cropper) { cropper.destroy(); cropper = null; }
                        cropper = new Cropper(img, {
                            viewMode: 1, autoCropArea: 1,
                            movable: true, zoomable: true, rotatable: false,
                            background: false,
                        });
                    };
                    reader.readAsDataURL(input.files[0]);
                }

                function setCropRatio(ratio) {
                    if (cropper) cropper.setAspectRatio(ratio);
                }

                function applyCrop() {
                    if (!cropper) return;
                    const canvas = cropper.getCroppedCanvas({ maxWidth: 1200, maxHeight: 900, imageSmoothingQuality: 'high' });
                    document.getElementById('coverBase64').value = canvas.toDataURL('image/jpeg', 0.88);
                    document.getElementById('coverRemoveFlag').value = '';

                    // Show preview
                    const zone = document.getElementById('coverZone');
                    zone.innerHTML = `
                        <img src="${canvas.toDataURL('image/jpeg', 0.88)}"
                             style="width:100%;height:100%;object-fit:cover;display:block">
                        <button type="button" onclick="event.stopPropagation();removeCover()"
                                style="position:absolute;top:8px;right:8px;width:30px;height:30px;
                                       border-radius:50%;background:rgba(0,0,0,.6);border:none;color:#fff;
                                       cursor:pointer;font-size:18px;display:flex;align-items:center;justify-content:center">×</button>`;
                    cancelCrop();
                }

                function cancelCrop() {
                    document.getElementById('cropModal').style.display = 'none';
                    document.getElementById('coverFile').value = '';
                    if (cropper) { cropper.destroy(); cropper = null; }
                }

                function removeCover() {
                    document.getElementById('coverBase64').value = '';
                    document.getElementById('coverRemoveFlag').value = '1';
                    const zone = document.getElementById('coverZone');
                    zone.innerHTML = `
                        <div style="text-align:center;pointer-events:none;padding:24px">
                            <i data-lucide="image" width="40" height="40" stroke-width="1.5" style="color:var(--text-muted);margin-bottom:10px"></i>
                            <div style="font-size:14px;font-weight:600;color:var(--text-primary);margin-bottom:4px">Нажмите чтобы выбрать фото</div>
                            <div style="font-size:12px;color:var(--text-muted)">JPG, PNG или WebP</div>
                        </div>`;
                    window.refreshIcons?.();
                }
                </script>

                <div class="form-group">
                    <label class="form-label" for="description"><?= t('description') ?> <span class="req">*</span></label>
                    <textarea class="form-control" id="description" name="description"
                              rows="6" placeholder="<?= t('description_ph') ?>" required><?= htmlspecialchars($vacancy['description'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label" for="requirements"><?= t('requirements') ?></label>
                    <textarea class="form-control" id="requirements" name="requirements"
                              rows="4" placeholder="<?= t('requirements_ph') ?>"><?= htmlspecialchars($vacancy['requirements'] ?? '') ?></textarea>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="salary_min"><?= t('salary_min') ?></label>
                        <input class="form-control" type="number" id="salary_min" name="salary_min"
                               value="<?= htmlspecialchars($vacancy['salary_min'] ?? '') ?>"
                               placeholder="100 000" min="0">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="salary_max"><?= t('salary_max') ?></label>
                        <input class="form-control" type="number" id="salary_max" name="salary_max"
                               value="<?= htmlspecialchars($vacancy['salary_max'] ?? '') ?>"
                               placeholder="200 000" min="0">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="location"><?= t('location') ?></label>
                        <input class="form-control" type="text" id="location" name="location"
                               value="<?= htmlspecialchars($vacancy['location'] ?? '') ?>"
                               placeholder="<?= t('location_placeholder') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="employment_type"><?= t('employment_type') ?></label>
                        <select class="form-control" id="employment_type" name="employment_type">
                            <?php foreach ($typeOptions as $val => $label): ?>
                                <option value="<?= $val ?>"
                                    <?= ($vacancy['employment_type'] ?? 'full-time') === $val ? 'selected' : '' ?>>
                                    <?= $label ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="contact_phone">
                            Контактный телефон
                            <span class="text-muted" style="font-weight:400">(Необязательно)</span>
                        </label>
                        <input class="form-control" type="tel" id="contact_phone" name="contact_phone"
                               value="<?= htmlspecialchars($vacancy['contact_phone'] ?? '') ?>"
                               placeholder="+7 777 123 45 67">
                        <p class="form-hint">Кандидаты смогут позвонить напрямую по этому номеру</p>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="expires_at"><?= t('expires_vac_field') ?> <span class="text-muted" style="font-weight:400">(<?= t('cover_letter_optional') ?>)</span></label>
                        <input class="form-control" type="date" id="expires_at" name="expires_at"
                               value="<?= htmlspecialchars($vacancy['expires_at'] ?? '') ?>"
                               min="<?= date('Y-m-d', strtotime('+1 day')) ?>">
                        <p class="form-hint"><?= t('expires_vac_hint') ?></p>
                    </div>
                </div>

                <?php if ($editing): ?>
                <div class="form-group">
                    <label class="form-label" for="status"><?= t('status') ?></label>
                    <select class="form-control" id="status" name="status">
                        <?php foreach ($statusOptions as $val => $label): ?>
                            <option value="<?= $val ?>" <?= ($vacancy['status'] ?? 'active') === $val ? 'selected' : '' ?>>
                                <?= $label ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php else: ?>
                    <input type="hidden" name="status" value="active">
                <?php endif; ?>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <?= $editing ? t('save_changes') : t('publish') ?>
                    </button>
                    <a href="<?= BASE_URL ?>/pages/vacancies.php" class="btn btn-ghost"><?= t('cancel') ?></a>
                </div>
            </form>
        </div>
    </div>

    <div class="form-sidebar-tips">
        <div class="card tips-card">
            <div class="card__header"><h3 class="card__title"><?= t('tips_title') ?></h3></div>
            <div class="card__body">
                <ul class="tips-list">
                    <li><?= t('tip_1') ?></li>
                    <li><?= t('tip_2') ?></li>
                    <li><?= t('tip_3') ?></li>
                    <li><?= t('tip_4') ?></li>
                    <li><?= t('tip_5') ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
