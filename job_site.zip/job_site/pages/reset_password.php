<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/i18n.php';

if (isLoggedIn()) { header('Location: ' . BASE_URL . '/pages/dashboard.php'); exit; }

$token = trim($_GET['token'] ?? '');
$error = ''; $success = false;
$validToken = false;
$resetEmail = '';

// Verify token
if ($token) {
    $stmt = $conn->prepare(
        "SELECT email FROM password_resets WHERE token=? AND expires_at > NOW()"
    );
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $stmt->bind_result($resetEmail);
    $validToken = (bool)$stmt->fetch();
    $stmt->close();
}

if (!$token || !$validToken) {
    $error = t('reset_invalid_msg');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $validToken) {
    $newPass  = $_POST['password']  ?? '';
    $confPass = $_POST['password2'] ?? '';

    if (strlen($newPass) < 6) {
        $error = t('err_pass_min6');
    } elseif ($newPass !== $confPass) {
        $error = t('err_pass_mismatch');
    } else {
        $hash = password_hash($newPass, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password=? WHERE email=?");
        $stmt->bind_param('ss', $hash, $resetEmail);
        $stmt->execute(); $stmt->close();

        // Delete used token
        $stmt = $conn->prepare("DELETE FROM password_resets WHERE token=?");
        $stmt->bind_param('s', $token);
        $stmt->execute(); $stmt->close();

        $success = true;
    }
}
?>
<!DOCTYPE html>
<html lang="<?= $_SESSION['lang'] ?? 'ru' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= t('reset_title') ?> — <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <script>(function(){var t=localStorage.getItem('nexio-theme')||'light';document.documentElement.setAttribute('data-theme',t);})()</script>
</head>
<body class="auth-body">

<div class="auth-layout">

    <div class="auth-controls">
        <button class="theme-btn" data-action="theme" title="Toggle theme">
            <i data-lucide="moon" width="14" height="14"></i>
        </button>
    </div>

    <div class="auth-panel">
        <div class="auth-brand">
            <a href="<?= BASE_URL ?>/" style="display:flex;align-items:center;text-decoration:none;color:inherit;">
                <svg viewBox="0 0 105 32" fill="none" height="28">
                    <defs>
                        <linearGradient id="nexio-g-rp" x1="0" y1="0" x2="1" y2="1">
                            <stop offset="0%" stop-color="#60a5fa"/>
                            <stop offset="100%" stop-color="#2563eb"/>
                        </linearGradient>
                    </defs>
                    <path d="M4 27V7L22 27V7" stroke="url(#nexio-g-rp)" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
                    <circle cx="22" cy="2.5" r="3" fill="#3b82f6"/>
                    <text x="32" y="24" font-family="-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif"
                          font-size="21" font-weight="800" fill="currentColor" letter-spacing="-0.3">exio</text>
                </svg>
            </a>
        </div>

        <h1 class="auth-title"><?= t('reset_title') ?></h1>
        <p class="auth-subtitle"><?= t('reset_subtitle') ?></p>

        <?php if ($error): ?>
            <div class="alert alert-error" style="margin-bottom:18px"><?= htmlspecialchars($error) ?></div>
            <?php if (!$validToken): ?>
            <div class="auth-footer" style="margin-top:8px">
                <a href="<?= BASE_URL ?>/pages/forgot_password.php"><?= t('request_new_link') ?></a>
            </div>
            <?php endif; ?>
        <?php elseif ($success): ?>
            <div class="alert alert-success" style="margin-bottom:18px">
                <?= t('reset_success_msg') ?>
            </div>
            <a href="<?= BASE_URL ?>/pages/login.php" class="btn btn-primary btn-block btn-lg"><?= t('sign_in') ?></a>
        <?php endif; ?>

        <?php if ($validToken && !$success): ?>
        <form method="POST" class="auth-form" novalidate>
            <div class="form-group">
                <label class="form-label" for="password"><?= t('reset_new_pass_label') ?></label>
                <input class="form-control" type="password" id="password" name="password"
                       placeholder="<?= t('reset_new_pass_ph') ?>" required autofocus minlength="6">
            </div>
            <div class="form-group">
                <label class="form-label" for="password2"><?= t('reset_confirm_label') ?></label>
                <input class="form-control" type="password" id="password2" name="password2"
                       placeholder="••••••••" required minlength="6">
            </div>
            <button type="submit" class="btn btn-primary btn-block btn-lg"><?= t('reset_btn') ?></button>
        </form>
        <?php endif; ?>

        <?php if (!$success): ?>
        <div class="auth-footer" style="margin-top:20px">
            <a href="<?= BASE_URL ?>/pages/login.php"><?= t('back_to_login') ?></a>
        </div>
        <?php endif; ?>
    </div>

    <div class="auth-visual">
        <div class="auth-visual__content">
            <h2><?= t('security_visual_title') ?></h2>
            <ul class="auth-features-list">
                <li><?= t('security_feat_1') ?></li>
                <li><?= t('security_feat_2') ?></li>
                <li><?= t('security_feat_3') ?></li>
            </ul>
        </div>
    </div>

</div>

<script src="<?= BASE_URL ?>/assets/js/lucide.min.js?v=<?= asset_ver('assets/js/lucide.min.js') ?>"></script>
<script src="<?= BASE_URL ?>/assets/js/app.js?v=<?= asset_ver('assets/js/app.js') ?>"></script>
</body>
</html>
