<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/i18n.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/pages/dashboard.php');
    exit;
}

$token  = trim($_GET['token'] ?? '');
$status = 'invalid'; // invalid | already | success

if ($token) {
    $stmt = $conn->prepare("SELECT id, name, status FROM users WHERE verify_token = ?");
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row) {
        $status = 'invalid';
    } elseif ($row['status'] === 'active') {
        $status = 'already';
    } else {
        $upd = $conn->prepare("UPDATE users SET status='active', verify_token=NULL WHERE id=?");
        $upd->bind_param('i', $row['id']);
        $upd->execute(); $upd->close();
        $status = 'success';
    }
}
?>
<!DOCTYPE html>
<html lang="<?= $_SESSION['lang'] ?? 'ru' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= t('verify_title') ?> — <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <script>(function(){var t=localStorage.getItem('nexio-theme')||'light';document.documentElement.setAttribute('data-theme',t);})()</script>
    <style>
        .verify-wrap {
            min-height: 100vh; display: flex; align-items: center; justify-content: center;
            background: var(--bg-page); padding: 24px;
        }
        .verify-card {
            background: var(--bg-card); border: 1px solid var(--border);
            border-radius: 16px; padding: 48px 40px; text-align: center;
            max-width: 440px; width: 100%;
            box-shadow: 0 8px 40px rgba(0,0,0,.08);
        }
        .verify-icon { font-size: 56px; margin-bottom: 20px; line-height: 1; }
        .verify-title { font-size: 22px; font-weight: 700; color: var(--text-primary); margin-bottom: 10px; }
        .verify-sub   { font-size: 14px; color: var(--text-secondary); line-height: 1.6; margin-bottom: 28px; }
    </style>
</head>
<body class="auth-body">
<div class="verify-wrap">
    <div class="verify-card">
        <?php if ($status === 'success'): ?>
            <div class="verify-icon" style="color:#22c55e"><i data-lucide="party-popper" width="56" height="56"></i></div>
            <div class="verify-title"><?= t('verify_success_title') ?></div>
            <div class="verify-sub">
                <?= t('verify_success_sub') ?>
            </div>
            <a href="<?= BASE_URL ?>/pages/login.php?verified=1" class="btn btn-primary" style="width:100%">
                <?= t('verify_login_btn') ?>
            </a>
            <script>setTimeout(() => location.href = '<?= BASE_URL ?>/pages/login.php?verified=1', 3000);</script>

        <?php elseif ($status === 'already'): ?>
            <div class="verify-icon" style="color:#2563eb"><i data-lucide="circle-check" width="56" height="56"></i></div>
            <div class="verify-title"><?= t('verify_already_title') ?></div>
            <div class="verify-sub"><?= t('verify_already_sub') ?></div>
            <a href="<?= BASE_URL ?>/pages/login.php" class="btn btn-primary" style="width:100%"><?= t('login_btn') ?></a>

        <?php else: ?>
            <div class="verify-icon" style="color:#ef4444"><i data-lucide="circle-x" width="56" height="56"></i></div>
            <div class="verify-title"><?= t('verify_invalid_title') ?></div>
            <div class="verify-sub">
                <?= t('verify_invalid_sub') ?>
            </div>
            <a href="<?= BASE_URL ?>/pages/login.php" class="btn btn-ghost" style="width:100%"><?= t('back_to_login') ?></a>
        <?php endif; ?>
    </div>
</div>
<script src="<?= BASE_URL ?>/assets/js/lucide.min.js?v=<?= asset_ver('assets/js/lucide.min.js') ?>"></script>
<script src="<?= BASE_URL ?>/assets/js/app.js?v=<?= asset_ver('assets/js/app.js') ?>"></script>
</body>
</html>
