<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

if (!isEmployer() && !isAdmin()) {
    header('Location: ' . BASE_URL . '/pages/dashboard.php'); exit;
}

$uid = (int)$_SESSION['user_id'];

// ── Filters ───────────────────────────────────────────────────
$search   = trim($_GET['q']      ?? '');
$skillQ   = trim($_GET['skill']  ?? '');
$minRating = (float)($_GET['rating'] ?? 0);
$perPage  = 12;
$page     = max(1, (int)($_GET['page'] ?? 1));
$offset   = ($page - 1) * $perPage;

// ── Build query ───────────────────────────────────────────────
$where  = ["u.role = 'employee'"];
$params = [];
$types  = '';

if ($search) {
    $like = "%$search%";
    $where[]  = "(u.name LIKE ? OR u.position LIKE ? OR u.bio LIKE ?)";
    $params[] = $like; $params[] = $like; $params[] = $like;
    $types   .= 'sss';
}
if ($skillQ) {
    $like     = "%$skillQ%";
    $where[]  = "r.skills LIKE ?";
    $params[] = $like;
    $types   .= 's';
}
if ($minRating > 0) {
    $where[]  = "IFNULL(AVG(rt.score)*2, 0) >= ?";
    $params[] = $minRating;
    $types   .= 'd';
}

$whereSQL = 'WHERE ' . implode(' AND ', $where);

$baseSQL = "FROM users u
            LEFT JOIN resumes r ON r.user_id = u.id
            LEFT JOIN ratings rt ON rt.employee_id = u.id
            $whereSQL
            GROUP BY u.id";

// Total count
$countStmt = $conn->prepare("SELECT COUNT(*) FROM (SELECT u.id $baseSQL) sub");
if ($params) $countStmt->bind_param($types, ...$params);
$countStmt->execute();
$total = (int)$countStmt->get_result()->fetch_row()[0];
$countStmt->close();

$totalPages = max(1, (int)ceil($total / $perPage));
$page = min($page, $totalPages);

// Main query
$sql = "SELECT u.id, u.name, u.position, u.avatar, u.created_at,
               r.skills, r.about, r.updated_at AS resume_updated,
               IFNULL(ROUND(AVG(rt.score)*2,1), 0) AS avg_rating,
               COUNT(DISTINCT rt.id) AS rating_cnt,
               COUNT(DISTINCT re.id) AS exp_cnt,
               COUNT(DISTINCT rf.id) AS file_cnt
        $baseSQL
        ORDER BY avg_rating DESC, u.name ASC
        LIMIT ? OFFSET ?";

$allParams = $params;
$allParams[] = $perPage;
$allParams[] = $offset;
$allTypes = $types . 'ii';

// Need LEFT JOINs for exp/files
$sql = "SELECT u.id, u.name, u.position, u.avatar, u.created_at,
               r.skills, r.about,
               IFNULL(ROUND(AVG(rt.score)*2,1), 0) AS avg_rating,
               COUNT(DISTINCT rt.id) AS rating_cnt,
               COUNT(DISTINCT rex.id) AS exp_cnt,
               COUNT(DISTINCT rf.id) AS file_cnt
        FROM users u
        LEFT JOIN resumes r ON r.user_id = u.id
        LEFT JOIN ratings rt ON rt.employee_id = u.id
        LEFT JOIN resume_experiences rex ON rex.user_id = u.id
        LEFT JOIN resume_files rf ON rf.user_id = u.id
        $whereSQL
        GROUP BY u.id
        HAVING 1=1
        ORDER BY avg_rating DESC, u.name ASC
        LIMIT ? OFFSET ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param($allTypes, ...$allParams);
$stmt->execute();
$employees = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Popular skills for filter chips
$popSkills = [];
$sr = $conn->query("SELECT skills FROM resumes WHERE skills IS NOT NULL AND skills != '' LIMIT 200");
$skillFreq = [];
while ($row = $sr->fetch_row()) {
    foreach (array_filter(array_map('trim', explode(',', $row[0]))) as $sk) {
        $skillFreq[$sk] = ($skillFreq[$sk] ?? 0) + 1;
    }
}
arsort($skillFreq);
$popSkills = array_slice(array_keys($skillFreq), 0, 10);

function empGrad(string $name): string {
    $p = [['#3b82f6','#1d4ed8'],['#8b5cf6','#6d28d9'],['#ec4899','#be185d'],
          ['#10b981','#047857'],['#f59e0b','#b45309'],['#06b6d4','#0e7490'],
          ['#ef4444','#b91c1c'],['#6366f1','#4338ca']];
    $i = ord($name[0] ?? 'A') % count($p);
    return "linear-gradient(135deg,{$p[$i][0]},{$p[$i][1]})";
}

$pageTitle = t('search_employees_title');
include __DIR__ . '/../includes/header.php';
?>

<style>
/* ── Layout ─────────────────────────────────────────── */
.emp-layout { display: grid; grid-template-columns: 240px 1fr; gap: 22px; align-items: start; }
@media (max-width: 860px) { .emp-layout { grid-template-columns: 1fr; } .emp-sidebar { display: none; } }

/* ── Sidebar ─────────────────────────────────────────── */
.emp-sidebar { position: sticky; top: 16px; display: flex; flex-direction: column; gap: 14px; }
.emp-filter-card { background: var(--card-bg); border: 1.5px solid var(--border); border-radius: 18px; overflow: hidden; }
.emp-filter-card__head { padding: 13px 16px; border-bottom: 1px solid var(--border-light); font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .08em; color: var(--text-muted); }
.emp-filter-card__body { padding: 14px 16px; }

.skill-chips { display: flex; flex-wrap: wrap; gap: 6px; }
.skill-chip {
    font-size: 12px; padding: 4px 10px; border-radius: 100px; cursor: pointer;
    border: 1.5px solid var(--border); color: var(--text-secondary); background: var(--card-bg);
    text-decoration: none; transition: all .13s;
}
.skill-chip:hover { border-color: var(--primary); color: var(--primary); background: rgba(37,99,235,.05); text-decoration: none; }
.skill-chip.active { background: var(--primary); border-color: var(--primary); color: #fff; }

.rating-filter { display: flex; flex-direction: column; gap: 6px; }
.rating-opt { display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 13px; color: var(--text-secondary); padding: 5px 0; }
.rating-opt input { accent-color: var(--primary); cursor: pointer; }
.rating-opt:hover { color: var(--text-primary); }

/* ── Search bar ──────────────────────────────────────── */
.emp-searchbar { display: flex; gap: 8px; background: var(--card-bg); border: 1.5px solid var(--border); border-radius: 16px; padding: 12px 14px; margin-bottom: 16px; }
.emp-searchbar input { flex: 1; background: var(--border-light); border: 1.5px solid transparent; border-radius: 10px; padding: 8px 14px; font-size: 14px; color: var(--text-primary); outline: none; transition: border-color .15s; }
.emp-searchbar input:focus { border-color: var(--primary); background: var(--card-bg); }

/* ── Grid ────────────────────────────────────────────── */
.emp-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; }

/* ── Employee card ───────────────────────────────────── */
.emp-card {
    background: var(--card-bg); border: 1.5px solid var(--border);
    border-radius: 20px; overflow: hidden; display: flex; flex-direction: column;
    transition: transform .2s, box-shadow .2s, border-color .2s;
}
.emp-card:hover { transform: translateY(-3px); box-shadow: 0 12px 36px rgba(0,0,0,.10); border-color: rgba(37,99,235,.3); }
[data-theme="dark"] .emp-card:hover { box-shadow: 0 12px 36px rgba(0,0,0,.28); }

.emp-card__top {
    padding: 20px 20px 16px;
    background: linear-gradient(160deg, var(--body-bg) 0%, var(--card-bg) 100%);
    display: flex; gap: 14px; align-items: flex-start;
}
.emp-card__ava {
    width: 52px; height: 52px; border-radius: 15px; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center;
    font-size: 18px; font-weight: 800; color: #fff; overflow: hidden;
    box-shadow: 0 4px 12px rgba(0,0,0,.18);
}
.emp-card__ava img { width: 100%; height: 100%; object-fit: cover; }
.emp-card__name { font-size: 15px; font-weight: 700; color: var(--text-primary); margin-bottom: 2px; }
.emp-card__pos  { font-size: 12.5px; color: var(--text-secondary); margin-bottom: 8px; }
.emp-card__rating {
    display: inline-flex; align-items: center; gap: 4px;
    font-size: 12px; font-weight: 700; color: #f59e0b;
    background: rgba(245,158,11,.1); border: 1px solid rgba(245,158,11,.25);
    border-radius: 100px; padding: 3px 9px;
}

.emp-card__skills { padding: 0 20px 14px; display: flex; flex-wrap: wrap; gap: 6px; min-height: 36px; }
.emp-card__skill-tag {
    font-size: 11.5px; padding: 3px 9px; border-radius: 100px;
    background: rgba(37,99,235,.08); color: #2563eb;
    border: 1px solid rgba(37,99,235,.18);
}
.emp-card__skill-more { font-size: 11.5px; color: var(--text-muted); padding: 3px 0; }

.emp-card__about {
    padding: 0 20px 14px; font-size: 12.5px; color: var(--text-secondary);
    line-height: 1.6; display: -webkit-box; -webkit-line-clamp: 2;
    -webkit-box-orient: vertical; overflow: hidden;
}

.emp-card__meta {
    padding: 10px 20px; border-top: 1px solid var(--border-light);
    display: flex; gap: 12px; font-size: 11.5px; color: var(--text-muted);
}
.emp-card__meta-item { display: flex; align-items: center; gap: 4px; }

.emp-card__footer {
    padding: 12px 16px; border-top: 1px solid var(--border-light);
    display: flex; gap: 8px; margin-top: auto;
}
.emp-card__btn {
    flex: 1; display: flex; align-items: center; justify-content: center; gap: 6px;
    padding: 8px 10px; border-radius: 10px; font-size: 12.5px; font-weight: 600;
    text-decoration: none; transition: all .15s; border: 1.5px solid transparent;
}
.emp-card__btn:hover { transform: translateY(-1px); text-decoration: none; }
.emp-card__btn--primary { background: linear-gradient(135deg,#3b82f6,#1d4ed8); color: #fff; box-shadow: 0 2px 8px rgba(37,99,235,.25); }
.emp-card__btn--primary:hover { box-shadow: 0 4px 14px rgba(37,99,235,.35); color: #fff; }
.emp-card__btn--ghost { background: transparent; color: var(--text-secondary); border-color: var(--border); }
.emp-card__btn--ghost:hover { background: var(--border-light); color: var(--text-primary); border-color: var(--border); }

/* ── Pagination ──────────────────────────────────────── */
.pagination { display: flex; align-items: center; justify-content: center; gap: 6px; margin-top: 28px; flex-wrap: wrap; }
.page-btn {
    display: inline-flex; align-items: center; justify-content: center;
    min-width: 36px; height: 36px; padding: 0 10px; border-radius: 10px;
    font-size: 13.5px; font-weight: 600; text-decoration: none;
    border: 1.5px solid var(--border); color: var(--text-secondary);
    background: var(--card-bg); transition: all .13s;
}
.page-btn:hover { border-color: var(--primary); color: var(--primary); background: rgba(37,99,235,.06); text-decoration: none; }
.page-btn.active { background: var(--primary); border-color: var(--primary); color: #fff; box-shadow: 0 2px 8px rgba(37,99,235,.3); }
.page-btn.disabled { opacity: .38; pointer-events: none; }
.page-dots { color: var(--text-muted); font-size: 14px; padding: 0 4px; }

/* ── Empty ───────────────────────────────────────────── */
.emp-empty { text-align: center; padding: 60px 20px; background: var(--card-bg); border: 1.5px dashed var(--border); border-radius: 20px; }
</style>

<!-- Header -->
<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:22px;flex-wrap:wrap">
    <div>
        <h1 style="font-size:22px;font-weight:800;color:var(--text-primary);margin:0 0 4px"><?= t('search_employees_title') ?></h1>
        <p style="font-size:14px;color:var(--text-muted);margin:0"><?= t('emp_found_count_pre') ?> <strong style="color:var(--text-primary)"><?= $total ?></strong> <?= t('emp_found_count_post') ?></p>
    </div>
</div>

<?php
// Build base URL for pagination/filters
$qParams = array_filter(['q' => $search, 'skill' => $skillQ, 'rating' => $minRating ?: '']);
$qStr = $qParams ? '?' . http_build_query($qParams) . '&' : '?';
?>

<div class="emp-layout">

<!-- ── Sidebar filters ── -->
<aside class="emp-sidebar">

    <div class="emp-filter-card">
        <div class="emp-filter-card__head"><?= t('emp_popular_skills') ?></div>
        <div class="emp-filter-card__body">
            <div class="skill-chips">
                <?php foreach ($popSkills as $sk): ?>
                <a href="?<?= http_build_query(array_merge($qParams, ['skill' => $skillQ === $sk ? '' : $sk, 'page' => 1])) ?>"
                   class="skill-chip <?= $skillQ === $sk ? 'active' : '' ?>">
                    <?= htmlspecialchars($sk) ?>
                </a>
                <?php endforeach; ?>
                <?php if (empty($popSkills)): ?>
                <span style="font-size:12.5px;color:var(--text-muted)"><?= t('emp_skills_empty') ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="emp-filter-card">
        <div class="emp-filter-card__head"><?= t('filter_min_rating') ?></div>
        <div class="emp-filter-card__body">
            <div class="rating-filter">
                <?php foreach ([0 => t('any_rating'), 6 => '6+', 7 => '7+', 8 => '8+', 9 => '9+'] as $val => $lbl): ?>
                <label class="rating-opt">
                    <input type="radio" name="rating_filter" value="<?= $val ?>"
                           <?= (int)$minRating === $val ? 'checked' : '' ?>
                           onchange="applyRating(<?= $val ?>)">
                    <?php if ($val > 0): ?>
                    <span style="color:#f59e0b;font-weight:700;display:inline-flex;align-items:center;gap:4px"><i data-lucide="star" width="13" height="13" fill="currentColor"></i><?= $lbl ?></span>
                    <?php else: ?><span><?= $lbl ?></span><?php endif; ?>
                </label>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <?php if ($search || $skillQ || $minRating): ?>
    <a href="<?= BASE_URL ?>/pages/employees.php"
       class="btn btn-ghost" style="width:100%;justify-content:center;gap:6px;border-radius:12px">
        <i data-lucide="x" width="13" height="13"></i>
        <?= t('clear') ?>
    </a>
    <?php endif; ?>

</aside>

<!-- ── Main ── -->
<div>

    <!-- Search bar -->
    <form method="GET" class="emp-searchbar">
        <input type="text" name="q" placeholder="🔍  <?= t('emp_search_placeholder') ?>"
               value="<?= htmlspecialchars($search) ?>" autofocus>
        <?php if ($skillQ): ?><input type="hidden" name="skill" value="<?= htmlspecialchars($skillQ) ?>"><?php endif; ?>
        <?php if ($minRating): ?><input type="hidden" name="rating" value="<?= $minRating ?>"><?php endif; ?>
        <button type="submit" class="btn btn-primary" style="border-radius:10px;padding:8px 20px"><?= t('filter_apply_btn') ?></button>
        <?php if ($search || $skillQ || $minRating): ?>
        <a href="<?= BASE_URL ?>/pages/employees.php" class="btn btn-ghost" style="border-radius:10px"><?= t('clear') ?></a>
        <?php endif; ?>
    </form>

    <!-- Grid -->
    <?php if (empty($employees)): ?>
    <div class="emp-empty">
        <div style="margin-bottom:12px;color:var(--text-muted)"><i data-lucide="search" width="44" height="44" stroke-width="1.5"></i></div>
        <div style="font-size:16px;font-weight:700;color:var(--text-primary);margin-bottom:6px"><?= t('emp_not_found_title') ?></div>
        <div style="font-size:13px;color:var(--text-muted)"><?= t('emp_not_found_sub') ?></div>
    </div>
    <?php else: ?>

    <div class="emp-grid">
    <?php foreach ($employees as $e):
        $skills = array_filter(array_map('trim', explode(',', $e['skills'] ?? '')));
        $visSkills = array_slice($skills, 0, 3);
        $moreSkills = count($skills) - count($visSkills);
        $grad = empGrad($e['name']);
        $init = mb_strtoupper(mb_substr($e['name'], 0, 1));
    ?>
    <div class="emp-card">
        <div class="emp-card__top">
            <div class="emp-card__ava" style="background:<?= $grad ?>">
                <?php if (!empty($e['avatar'])): ?>
                    <img src="<?= BASE_URL ?>/assets/uploads/avatars/<?= htmlspecialchars($e['avatar']) ?>" alt="">
                <?php else: ?>
                    <?= $init ?>
                <?php endif; ?>
            </div>
            <div style="flex:1;min-width:0">
                <div class="emp-card__name"><?= htmlspecialchars($e['name']) ?></div>
                <div class="emp-card__pos"><?= htmlspecialchars($e['position'] ?? t('no_position_set')) ?></div>
                <?php if ($e['avg_rating'] > 0): ?>
                <div class="emp-card__rating"><i data-lucide="star" width="13" height="13" fill="currentColor"></i><?= $e['avg_rating'] ?>/10
                    <span style="font-weight:400;opacity:.7">(<?= $e['rating_cnt'] ?>)</span>
                </div>
                <?php else: ?>
                <div style="font-size:12px;color:var(--text-muted)"><?= t('emp_no_ratings') ?></div>
                <?php endif; ?>
            </div>
        </div>

        <?php if (!empty($visSkills)): ?>
        <div class="emp-card__skills">
            <?php foreach ($visSkills as $sk): ?>
            <span class="emp-card__skill-tag"><?= htmlspecialchars($sk) ?></span>
            <?php endforeach; ?>
            <?php if ($moreSkills > 0): ?>
            <span class="emp-card__skill-more">+<?= $moreSkills ?> <?= t('more_label') ?></span>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if (!empty($e['about'])): ?>
        <div class="emp-card__about"><?= htmlspecialchars($e['about']) ?></div>
        <?php endif; ?>

        <div class="emp-card__meta">
            <div class="emp-card__meta-item">
                <i data-lucide="briefcase" width="11" height="11"></i>
                <?= $e['exp_cnt'] ?> <?= t('emp_work_places') ?>
            </div>
            <div class="emp-card__meta-item">
                <i data-lucide="file-text" width="11" height="11"></i>
                <?= $e['file_cnt'] ?> <?= t('emp_documents') ?>
            </div>
            <div class="emp-card__meta-item" style="margin-left:auto">
                <i data-lucide="calendar" width="11" height="11"></i>
                <?= t('emp_since') ?> <?= date('M Y', strtotime($e['created_at'])) ?>
            </div>
        </div>

        <div class="emp-card__footer">
            <a href="<?= BASE_URL ?>/pages/resume_view.php?id=<?= $e['id'] ?>" class="emp-card__btn emp-card__btn--primary">
                <i data-lucide="file-text" width="13" height="13"></i>
                <?= t('nav_resume') ?>
            </a>
            <a href="<?= BASE_URL ?>/pages/chat.php?with=<?= $e['id'] ?>" class="emp-card__btn emp-card__btn--ghost">
                <i data-lucide="message-square" width="13" height="13"></i>
                <?= t('btn_message') ?>
            </a>
            <a href="<?= BASE_URL ?>/pages/ratings.php?rate=<?= $e['id'] ?>" class="emp-card__btn emp-card__btn--ghost" style="flex:none;padding:8px 10px" title="<?= t('rate_tooltip') ?>">
                <i data-lucide="star" width="13" height="13"></i>
            </a>
        </div>
    </div>
    <?php endforeach; ?>
    </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
    <div class="pagination">
        <!-- Prev -->
        <a href="<?= $qStr ?>page=<?= $page - 1 ?>" class="page-btn <?= $page <= 1 ? 'disabled' : '' ?>">
            <i data-lucide="chevron-left" width="14" height="14"></i>
        </a>

        <?php
        $range = 2;
        $pages = [];
        for ($p = 1; $p <= $totalPages; $p++) {
            if ($p === 1 || $p === $totalPages || abs($p - $page) <= $range) $pages[] = $p;
        }
        $prev = null;
        foreach ($pages as $p):
            if ($prev !== null && $p - $prev > 1): ?>
            <span class="page-dots">…</span>
        <?php endif; ?>
        <a href="<?= $qStr ?>page=<?= $p ?>" class="page-btn <?= $p === $page ? 'active' : '' ?>"><?= $p ?></a>
        <?php $prev = $p; endforeach; ?>

        <!-- Next -->
        <a href="<?= $qStr ?>page=<?= $page + 1 ?>" class="page-btn <?= $page >= $totalPages ? 'disabled' : '' ?>">
            <i data-lucide="chevron-right" width="14" height="14"></i>
        </a>
    </div>
    <?php endif; ?>

    <?php endif; ?>

</div><!-- /.main -->
</div><!-- /.emp-layout -->

<script src="<?= BASE_URL ?>/assets/js/pages/employees.js?v=<?= asset_ver('assets/js/pages/employees.js') ?>"></script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
