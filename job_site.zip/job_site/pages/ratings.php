<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

$uid  = $_SESSION['user_id'];
$role = $_SESSION['user_role'];
$success = ''; $error = '';

// ── Pre-select employee (from URL) ────────────────────────────
$preEmployee = (int)($_GET['rate'] ?? 0);

// ── Employer: submit rating ───────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $role === 'employer') {
    $empId    = (int)($_POST['employee_id'] ?? 0);
    $score    = (int)($_POST['score']       ?? 0);
    $category = trim($_POST['category']     ?? '');
    $comment  = trim($_POST['comment']      ?? '');

    if (!$empId || $score < 1 || $score > 5) {
        $error = t('err_fill_all');
    } else {
        $chk = $conn->prepare("SELECT id FROM users WHERE id=? AND role='employee'");
        $chk->bind_param('i', $empId); $chk->execute(); $chk->store_result();
        if (!$chk->num_rows) { $error = t('err_employee_not_found'); }
        else {
            $ins = $conn->prepare("INSERT INTO ratings (employer_id,employee_id,score,category,comment) VALUES (?,?,?,?,?)");
            $ins->bind_param('iiiss', $uid, $empId, $score, $category, $comment);
            $ins->execute() ? $success = t('rating_saved') : $error = t('err_save_fail');
            $ins->close();
        }
        $chk->close();
    }
}

// ── Score helpers ─────────────────────────────────────────────
function scoreColor(float $s10): string {
    if ($s10 >= 9)   return '#10b981';
    if ($s10 >= 7)   return '#3b82f6';
    if ($s10 >= 5)   return '#f59e0b';
    if ($s10 >= 3)   return '#f97316';
    return '#ef4444';
}
function scoreLabel(float $s10): string {
    if ($s10 >= 9) return t('score_excellent');
    if ($s10 >= 7) return t('score_good');
    if ($s10 >= 5) return t('score_ok');
    if ($s10 >= 3) return t('score_weak');
    return t('score_bad');
}
function scoreEmoji(float $s10): string {
    if     ($s10 >= 9) $n = 'laugh';
    elseif ($s10 >= 7) $n = 'smile';
    elseif ($s10 >= 5) $n = 'meh';
    elseif ($s10 >= 3) $n = 'frown';
    else               $n = 'angry';
    return '<i data-lucide="' . $n . '" width="18" height="18" style="color:' . scoreColor($s10) . ';vertical-align:-4px"></i>';
}
function timeAgo(string $ts): string {
    $d = time() - strtotime($ts);
    if ($d < 60)     return t('time_just_now');
    if ($d < 3600)   return floor($d/60).' '.t('time_min_ago');
    if ($d < 86400)  return floor($d/3600).' '.t('time_hr_ago');
    if ($d < 604800) return floor($d/86400).' '.t('time_day_ago');
    if ($d < 2592000)return floor($d/604800).' '.t('time_week_ago');
    return date('d M Y', strtotime($ts));
}

// ── Pagination ────────────────────────────────────────────────
$ratPerPage = 10;
$ratPage    = max(1, (int)($_GET['page'] ?? 1));
$ratOffset  = ($ratPage - 1) * $ratPerPage;

// ── Load data ─────────────────────────────────────────────────
if ($role === 'employer') {
    // Total count for stats (all, unpaged)
    $cntStmt = $conn->prepare("SELECT COUNT(*) FROM ratings WHERE employer_id=?");
    $cntStmt->bind_param('i', $uid); $cntStmt->execute();
    $ratTotalCount = (int)$cntStmt->get_result()->fetch_row()[0]; $cntStmt->close();
    $ratTotalPages = (int)ceil($ratTotalCount / $ratPerPage);

    // Stats from all ratings (unpaged)
    $allStmt = $conn->prepare("SELECT score, employee_id FROM ratings WHERE employer_id=? ORDER BY created_at DESC");
    $allStmt->bind_param('i', $uid); $allStmt->execute();
    $allRatings = $allStmt->get_result()->fetch_all(MYSQLI_ASSOC); $allStmt->close();
    $statGiven = count($allRatings);
    $statAvg10 = $statGiven ? round(array_sum(array_column($allRatings,'score')) / $statGiven * 2, 1) : 0;
    $statUniq  = count(array_unique(array_column($allRatings,'employee_id')));

    // Paged ratings for display
    $stmt = $conn->prepare(
        "SELECT r.*, u.name AS employee_name, u.position, u.avatar
         FROM ratings r JOIN users u ON r.employee_id=u.id
         WHERE r.employer_id=? ORDER BY r.created_at DESC LIMIT ? OFFSET ?"
    );
    $stmt->bind_param('iii', $uid, $ratPerPage, $ratOffset); $stmt->execute();
    $ratings = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();

    $stmt = $conn->prepare("SELECT id, name, position FROM users WHERE role='employee' ORDER BY name");
    $stmt->execute();
    $employees = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();

} else {
    // Total count
    $cntStmt = $conn->prepare("SELECT COUNT(*) FROM ratings WHERE employee_id=?");
    $cntStmt->bind_param('i', $uid); $cntStmt->execute();
    $ratTotalCount = (int)$cntStmt->get_result()->fetch_row()[0]; $cntStmt->close();
    $ratTotalPages = (int)ceil($ratTotalCount / $ratPerPage);

    // Paged ratings for display
    $stmt = $conn->prepare(
        "SELECT r.*, u.name AS employer_name, u.company, u.avatar AS employer_avatar
         FROM ratings r JOIN users u ON r.employer_id=u.id
         WHERE r.employee_id=? ORDER BY r.created_at DESC LIMIT ? OFFSET ?"
    );
    $stmt->bind_param('iii', $uid, $ratPerPage, $ratOffset); $stmt->execute();
    $ratings = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();

    $stmt = $conn->prepare(
        "SELECT category, ROUND(AVG(score*2),1) AS avg10, COUNT(*) AS cnt
         FROM ratings WHERE employee_id=? GROUP BY category ORDER BY avg10 DESC"
    );
    $stmt->bind_param('i', $uid); $stmt->execute();
    $byCategory = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();

    // Overall avg from all ratings (not just this page)
    $avgStmt = $conn->prepare("SELECT IFNULL(ROUND(AVG(score)*2,1),0) FROM ratings WHERE employee_id=?");
    $avgStmt->bind_param('i', $uid); $avgStmt->execute();
    $avgOverall10 = (float)$avgStmt->get_result()->fetch_row()[0]; $avgStmt->close();

    // Best / worst category
    $bestCat  = !empty($byCategory) ? $byCategory[0] : null;
    $worstCat = !empty($byCategory) ? end($byCategory) : null;
}

$pageTitle = t('ratings_title');
include __DIR__ . '/../includes/header.php';
?>

<style>
/* ════════════════════════════════════════════════════
   RATINGS PAGE
   ════════════════════════════════════════════════════ */

/* ── Layout ──────────────────────────────────────── */
.rat-layout { display: grid; grid-template-columns: 1fr 340px; gap: 24px; align-items: start; }
.rat-layout--full { grid-template-columns: 1fr; }
@media (max-width: 900px) { .rat-layout { grid-template-columns: 1fr; } }

/* ── Hero gauge card ─────────────────────────────── */
.gauge-card {
    background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 60%, #1d4ed8 100%);
    border-radius: 22px; padding: 28px 30px; margin-bottom: 22px;
    position: relative; overflow: hidden;
}
.gauge-card::before {
    content: ''; position: absolute; top: -50px; right: -50px;
    width: 220px; height: 220px; border-radius: 50%;
    background: rgba(99,102,241,.15); pointer-events: none;
}
.gauge-card::after {
    content: ''; position: absolute; bottom: -30px; left: 20px;
    width: 140px; height: 140px; border-radius: 50%;
    background: rgba(16,185,129,.08); pointer-events: none;
}
.gauge-inner { display: flex; flex-direction: column; gap: 20px; position: relative; z-index: 1; }
.gauge-top {
    display: flex; align-items: flex-end; justify-content: space-between;
    gap: 24px; flex-wrap: wrap;
}
.gauge-info { min-width: 160px; }
.gauge-score { font-size: 52px; font-weight: 900; color: #fff; line-height: 1; margin-bottom: 6px; display: flex; align-items: baseline; gap: 4px; }
.gauge-score span { font-size: 22px; color: #93c5fd; font-weight: 600; }
.gauge-label { font-size: 15px; color: #93c5fd; font-weight: 500; }
.gauge-chips { display: flex; gap: 10px; flex-wrap: wrap; }
.gauge-chip {
    display: inline-flex; flex-direction: column;
    background: rgba(255,255,255,.10); border: 1px solid rgba(255,255,255,.15);
    border-radius: 12px; padding: 8px 14px; min-width: 80px;
}
.gauge-chip__val { font-size: 20px; font-weight: 800; color: #fff; line-height: 1; }
.gauge-chip__lbl { font-size: 11px; color: #94a3b8; margin-top: 3px; }

/* ── Horizontal score bar ────────────────────────── */
.gauge-bar-wrap { width: 100%; }
.gauge-bar-track {
    width: 100%; height: 14px;
    background: rgba(255,255,255,.10);
    border: 1px solid rgba(255,255,255,.10);
    border-radius: 100px; overflow: hidden;
    position: relative;
}
.gauge-bar-fill {
    height: 100%; border-radius: 100px;
    background: linear-gradient(90deg, #60a5fa 0%, #10b981 100%);
    box-shadow: 0 0 16px rgba(96,165,250,.45), inset 0 1px 0 rgba(255,255,255,.25);
    transition: width 1.2s cubic-bezier(.16,1,.3,1); width: 0;
}
.gauge-bar-ticks {
    display: flex; justify-content: space-between;
    margin-top: 8px; font-size: 10px; font-weight: 600;
    color: rgba(255,255,255,.5); letter-spacing: .04em;
}
.gauge-bar-tick {
    flex: 1; text-align: center; position: relative;
}
.gauge-bar-tick:first-child { text-align: left; }
.gauge-bar-tick:last-child  { text-align: right; }

/* ── Category bars ───────────────────────────────── */
.cat-section { background: var(--card-bg); border: 1.5px solid var(--border); border-radius: 20px; overflow: hidden; margin-bottom: 20px; }
.cat-section__head { display: flex; align-items: center; gap: 10px; padding: 16px 22px; border-bottom: 1px solid var(--border-light); }
.cat-section__icon { width: 32px; height: 32px; border-radius: 9px; display: flex; align-items: center; justify-content: center; }
.cat-section__title { font-size: 14.5px; font-weight: 700; color: var(--text-primary); }
.cat-section__body { padding: 20px 22px; }

.cat-row { margin-bottom: 18px; }
.cat-row:last-child { margin-bottom: 0; }
.cat-row__meta { display: flex; align-items: baseline; justify-content: space-between; margin-bottom: 7px; }
.cat-row__name { font-size: 13.5px; font-weight: 600; color: var(--text-primary); display: flex; align-items: center; gap: 7px; }
.cat-row__badge { font-size: 11px; padding: 2px 8px; border-radius: 100px; font-weight: 600; }
.cat-row__score { font-size: 13px; font-weight: 700; }
.cat-row__cnt   { font-size: 11.5px; color: var(--text-muted); margin-left: 5px; }
.cat-track { height: 10px; background: var(--border-light); border-radius: 100px; overflow: hidden; }
.cat-fill  { height: 100%; border-radius: 100px; transition: width 1s cubic-bezier(.16,1,.3,1); width: 0; }

/* ── Review cards ────────────────────────────────── */
.review-list { display: flex; flex-direction: column; gap: 14px; }
.review-card {
    background: var(--card-bg); border: 1.5px solid var(--border);
    border-radius: 18px; padding: 18px 20px;
    transition: border-color .2s, box-shadow .2s, transform .2s;
}
.review-card:hover { border-color: rgba(37,99,235,.3); box-shadow: 0 8px 28px rgba(0,0,0,.09); transform: translateY(-2px); }
[data-theme="dark"] .review-card:hover { box-shadow: 0 8px 28px rgba(0,0,0,.25); }

.review-card__top { display: flex; align-items: flex-start; gap: 14px; margin-bottom: 14px; }
.review-card__ava {
    width: 42px; height: 42px; border-radius: 12px; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center;
    font-size: 15px; font-weight: 800; color: #fff; overflow: hidden;
}
.review-card__ava img { width: 100%; height: 100%; object-fit: cover; }
.review-card__name  { font-size: 14.5px; font-weight: 700; color: var(--text-primary); margin-bottom: 2px; }
.review-card__sub   { font-size: 12.5px; color: var(--text-secondary); }
.review-card__time  { margin-left: auto; font-size: 12px; color: var(--text-muted); white-space: nowrap; display: flex; align-items: center; gap: 4px; }

.review-card__score-row { display: flex; align-items: center; gap: 14px; margin-bottom: 12px; }
.review-score-pill {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 5px 13px; border-radius: 100px; font-size: 13.5px; font-weight: 800;
    white-space: nowrap; flex-shrink: 0;
}
.review-bar-wrap { flex: 1; }
.review-bar-track { height: 8px; background: var(--border-light); border-radius: 100px; overflow: hidden; position: relative; }
.review-bar-fill  { height: 100%; border-radius: 100px; transition: width 1s cubic-bezier(.16,1,.3,1); width: 0; }
.review-bar-ticks { display: flex; justify-content: space-between; margin-top: 4px; }
.review-bar-tick  { font-size: 9px; color: var(--text-muted); }
.review-card__cat { display: inline-flex; align-items: center; gap: 5px; font-size: 11.5px; font-weight: 600; padding: 3px 10px; border-radius: 100px; margin-bottom: 10px; }
.review-card__comment { font-size: 13.5px; color: var(--text-secondary); line-height: 1.6; padding: 12px 14px; background: var(--body-bg); border-radius: 12px; border-left: 3px solid var(--border); }

/* ── Form ────────────────────────────────────────── */
.rat-form-card { background: var(--card-bg); border: 1.5px solid var(--border); border-radius: 20px; overflow: hidden; margin-bottom: 22px; }
.rat-form-card__head { padding: 18px 22px; border-bottom: 1px solid var(--border-light); display: flex; align-items: center; gap: 10px; }
.rat-form-card__icon { width: 32px; height: 32px; border-radius: 9px; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg,#f59e0b,#d97706); }
.rat-form-card__title { font-size: 15px; font-weight: 700; color: var(--text-primary); }
.rat-form-card__body { padding: 22px; }

/* ── Emoji picker ────────────────────────────────── */
.ep-wrap { display: flex; gap: 8px; flex-wrap: wrap; }
.ep-wrap input[type="radio"] { display: none; }
.ep-label {
    display: flex; flex-direction: column; align-items: center; gap: 4px;
    cursor: pointer; padding: 10px 14px; border-radius: 14px;
    border: 2px solid var(--border); background: var(--card-bg);
    transition: all .15s; user-select: none; min-width: 70px;
    flex: 1;
}
.ep-label:hover { border-color: var(--primary); transform: translateY(-2px); }
.ep-wrap input:checked + .ep-label {
    border-color: var(--primary); background: rgba(37,99,235,.07);
    transform: translateY(-3px); box-shadow: 0 6px 18px rgba(37,99,235,.2);
}
.ep-face  { font-size: 26px; line-height: 1; }
.ep-num   { font-size: 16px; font-weight: 800; color: var(--text-primary); }
.ep-lbl   { font-size: 10.5px; color: var(--text-muted); }

/* ── Stats sidebar (employer) ────────────────────── */
.rat-stat-card { background: var(--card-bg); border: 1.5px solid var(--border); border-radius: 20px; overflow: hidden; margin-bottom: 18px; }
.rat-stat-card__head { padding: 14px 18px; border-bottom: 1px solid var(--border-light); font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .08em; color: var(--text-muted); }
.rat-stat-card__body { padding: 4px 0; }
.rat-stat-row { display: flex; align-items: center; gap: 12px; padding: 12px 18px; border-bottom: 1px solid var(--border-light); }
.rat-stat-row:last-child { border-bottom: none; }
.rat-stat-icon { width: 34px; height: 34px; border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.rat-stat-label { flex: 1; font-size: 13px; color: var(--text-secondary); }
.rat-stat-val   { font-size: 15px; font-weight: 800; color: var(--text-primary); }

/* ── Empty state ─────────────────────────────────── */
.rat-empty { text-align: center; padding: 48px 24px; }
.rat-empty__icon { font-size: 44px; margin-bottom: 12px; }
.rat-empty__title { font-size: 15px; font-weight: 700; color: var(--text-primary); margin-bottom: 6px; }
.rat-empty__sub   { font-size: 13px; color: var(--text-muted); }
</style>

<?php
// ── Avatar gradient helper ────────────────────────────────────
function avatarGrad(string $name): string {
    $p = [['#3b82f6','#1d4ed8'],['#8b5cf6','#6d28d9'],['#ec4899','#be185d'],
          ['#10b981','#047857'],['#f59e0b','#b45309'],['#06b6d4','#0e7490'],
          ['#ef4444','#b91c1c'],['#6366f1','#4338ca']];
    $i = ord($name[0] ?? 'A') % count($p);
    return "linear-gradient(135deg,{$p[$i][0]},{$p[$i][1]})";
}
?>

<?php if ($error):   ?><div class="alert alert-error"  style="margin-bottom:18px"><?= htmlspecialchars($error)   ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success" style="margin-bottom:18px"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<?php /* ═══════════════════ EMPLOYEE VIEW ════════════════════ */ ?>
<?php if ($role === 'employee'): ?>

<!-- Gauge hero -->
<?php $gaugePct = max(0, min(100, ($avgOverall10 / 10) * 100)); ?>
<div class="gauge-card" style="margin-bottom:22px">
    <div class="gauge-inner">
        <div class="gauge-top">
            <div class="gauge-info">
                <div class="gauge-score"><?= $avgOverall10 ?: '—' ?><span>/10</span></div>
                <div class="gauge-label"><?= scoreEmoji((float)$avgOverall10) ?> <?= scoreLabel((float)$avgOverall10) ?></div>
            </div>
            <div class="gauge-chips">
                <div class="gauge-chip">
                    <div class="gauge-chip__val"><?= count($ratings) ?></div>
                    <div class="gauge-chip__lbl"><?= t('rat_reviews_count') ?></div>
                </div>
                <?php if ($bestCat): ?>
                <div class="gauge-chip">
                    <div class="gauge-chip__val"><?= $bestCat['avg10'] ?></div>
                    <div class="gauge-chip__lbl"><?= t('rat_best_cat') ?></div>
                </div>
                <?php endif; ?>
                <?php if (count($byCategory) > 1 && $worstCat): ?>
                <div class="gauge-chip">
                    <div class="gauge-chip__val"><?= $worstCat['avg10'] ?></div>
                    <div class="gauge-chip__lbl"><?= t('rat_worst_cat') ?></div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="gauge-bar-wrap">
            <div class="gauge-bar-track">
                <div class="gauge-bar-fill" id="gaugeBarFill" data-pct="<?= $gaugePct ?>"></div>
            </div>
            <div class="gauge-bar-ticks">
                <?php for ($t = 0; $t <= 10; $t++): ?>
                <span class="gauge-bar-tick"><?= $t ?></span>
                <?php endfor; ?>
            </div>
        </div>
    </div>
</div>

<div class="rat-layout">
<div>

<!-- Category breakdown -->
<?php if (!empty($byCategory)): ?>
<div class="cat-section" style="margin-bottom:20px">
    <div class="cat-section__head">
        <div class="cat-section__icon" style="background:rgba(37,99,235,.1)">
            <i data-lucide="activity" width="16" height="16" style="color:#2563eb"></i>
        </div>
        <div class="cat-section__title"><?= t('rat_analytics_title') ?></div>
    </div>
    <div class="cat-section__body">
        <?php
        $catColors = [
            '#3b82f6','#10b981','#8b5cf6','#f59e0b','#ec4899','#06b6d4','#ef4444','#6366f1'
        ];
        foreach ($byCategory as $ci => $cat):
            $c10   = (float)$cat['avg10'];
            $pct   = ($c10 / 10) * 100;
            $col   = $catColors[$ci % count($catColors)];
            $label = $cat['category'] ?: t('general_category');
        ?>
        <div class="cat-row" data-pct="<?= $pct ?>" data-col="<?= $col ?>">
            <div class="cat-row__meta">
                <div class="cat-row__name">
                    <span><?= htmlspecialchars($label) ?></span>
                    <span class="cat-row__badge"
                          style="background:<?= $col ?>22;color:<?= $col ?>;border:1px solid <?= $col ?>44">
                        <?= scoreLabel($c10) ?>
                    </span>
                </div>
                <div>
                    <span class="cat-row__score" style="color:<?= $col ?>"><?= $c10 ?>/10</span>
                    <span class="cat-row__cnt">(<?= $cat['cnt'] ?>)</span>
                </div>
            </div>
            <div class="cat-track">
                <div class="cat-fill" style="background:linear-gradient(90deg,<?= $col ?>99,<?= $col ?>)"></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<!-- Reviews -->
<div class="cat-section">
    <div class="cat-section__head">
        <div class="cat-section__icon" style="background:rgba(139,92,246,.1)">
            <i data-lucide="message-square" width="16" height="16" style="color:#8b5cf6"></i>
        </div>
        <div class="cat-section__title"><?= t('rat_all_reviews') ?> <span style="font-size:12px;color:var(--text-muted);font-weight:400"><?= count($ratings) ?></span></div>
    </div>
    <div class="cat-section__body">
    <?php if (empty($ratings)): ?>
        <div class="rat-empty">
            <div class="rat-empty__icon" style="color:#f59e0b"><i data-lucide="star" width="44" height="44" fill="currentColor"></i></div>
            <div class="rat-empty__title"><?= t('rat_no_reviews_title') ?></div>
            <div class="rat-empty__sub"><?= t('rat_no_reviews_sub') ?></div>
        </div>
    <?php else: ?>
        <div class="review-list">
        <?php foreach ($ratings as $r):
            $s10   = $r['score'] * 2;
            $col   = scoreColor((float)$s10);
            $pct   = $s10 * 10;
            $cat   = $r['category'] ?: t('general_category');
            $grad  = avatarGrad($r['employer_name']);
            $init  = mb_strtoupper(mb_substr($r['employer_name'], 0, 1));
        ?>
        <div class="review-card">
            <div class="review-card__top">
                <div class="review-card__ava" style="background:<?= $grad ?>">
                    <?php if (!empty($r['employer_avatar'])): ?>
                        <img src="<?= BASE_URL ?>/assets/uploads/avatars/<?= htmlspecialchars($r['employer_avatar']) ?>" alt="">
                    <?php else: ?>
                        <?= $init ?>
                    <?php endif; ?>
                </div>
                <div style="flex:1;min-width:0">
                    <div class="review-card__name"><?= htmlspecialchars($r['employer_name']) ?></div>
                    <div class="review-card__sub"><?= htmlspecialchars($r['company'] ?: '') ?></div>
                </div>
                <div class="review-card__time">
                    <i data-lucide="clock" width="11" height="11"></i>
                    <?= timeAgo($r['created_at']) ?>
                </div>
            </div>

            <div class="review-card__score-row">
                <div class="review-score-pill" style="background:<?= $col ?>18;color:<?= $col ?>;border:1.5px solid <?= $col ?>33">
                    <?= scoreEmoji((float)$s10) ?> <?= $s10 ?>/10
                </div>
                <div class="review-bar-wrap">
                    <div class="review-bar-track">
                        <div class="review-bar-fill" data-pct="<?= $pct ?>"
                             style="background:linear-gradient(90deg,<?= $col ?>88,<?= $col ?>)"></div>
                    </div>
                    <div class="review-bar-ticks">
                        <?php for($t=0;$t<=10;$t+=2): ?>
                        <span class="review-bar-tick"><?= $t ?></span>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>

            <span class="review-card__cat" style="background:<?= $col ?>14;color:<?= $col ?>;border:1px solid <?= $col ?>30">
                <i data-lucide="tag" width="11" height="11"></i>
                <?= htmlspecialchars($cat) ?>
            </span>

            <?php if ($r['comment']): ?>
            <div class="review-card__comment"><?= nl2br(htmlspecialchars($r['comment'])) ?></div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
        </div>

        <?php if ($ratTotalPages > 1): ?>
        <div style="display:flex;justify-content:center;align-items:center;gap:6px;margin-top:16px;flex-wrap:wrap">
            <?php
            $range = []; $prev = null;
            for ($i = 1; $i <= $ratTotalPages; $i++) {
                if ($i === 1 || $i === $ratTotalPages || abs($i - $ratPage) <= 2) $range[] = $i;
            }
            foreach ($range as $pg):
                if ($prev !== null && $pg - $prev > 1): ?>
                <span style="color:var(--text-muted)">…</span>
                <?php endif;
                $pgUrl = BASE_URL . '/pages/ratings.php?' . http_build_query(['page' => $pg]);
            ?>
            <a href="<?= $pgUrl ?>"
               style="display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:10px;font-size:13px;font-weight:<?= $pg===$ratPage?'700':'500' ?>;text-decoration:none;border:1.5px solid <?= $pg===$ratPage?'var(--primary)':'var(--border)' ?>;background:<?= $pg===$ratPage?'var(--primary)':'var(--card-bg)' ?>;color:<?= $pg===$ratPage?'#fff':'var(--text-primary)' ?>;transition:all .14s">
                <?= $pg ?>
            </a>
            <?php $prev = $pg; endforeach; ?>
        </div>
        <?php endif; ?>

    <?php endif; ?>
    </div>
</div>

</div><!-- end left -->

<!-- Right: best/worst highlight -->
<div>
<?php if (!empty($byCategory)): ?>
<div class="rat-stat-card">
    <div class="rat-stat-card__head"><?= t('rat_strengths') ?></div>
    <div class="rat-stat-card__body">
    <?php foreach (array_slice($byCategory, 0, 5) as $ci => $cat):
        $c10 = (float)$cat['avg10'];
        $col = $catColors[$ci % count($catColors)];
    ?>
    <div class="rat-stat-row">
        <div class="rat-stat-icon" style="background:<?= $col ?>18">
            <i data-lucide="star" width="15" height="15" fill="<?= $col ?>" style="color:<?= $col ?>"></i>
        </div>
        <div class="rat-stat-label"><?= htmlspecialchars($cat['category'] ?: t('general_category')) ?></div>
        <div class="rat-stat-val" style="color:<?= $col ?>"><?= $c10 ?></div>
    </div>
    <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<div class="rat-stat-card">
    <div class="rat-stat-card__head"><?= t('rat_stats') ?></div>
    <div class="rat-stat-card__body">
        <div class="rat-stat-row">
            <div class="rat-stat-icon" style="background:rgba(245,158,11,.1)">
                <i data-lucide="star" width="15" height="15" fill="#f59e0b" style="color:#f59e0b"></i>
            </div>
            <div class="rat-stat-label"><?= t('rat_avg_score') ?></div>
            <div class="rat-stat-val"><?= $avgOverall10 ?>/10</div>
        </div>
        <div class="rat-stat-row">
            <div class="rat-stat-icon" style="background:rgba(37,99,235,.1)">
                <i data-lucide="message-square" width="15" height="15" style="color:#2563eb"></i>
            </div>
            <div class="rat-stat-label"><?= t('rat_total_reviews') ?></div>
            <div class="rat-stat-val"><?= $ratTotalCount ?></div>
        </div>
        <div class="rat-stat-row">
            <div class="rat-stat-icon" style="background:rgba(139,92,246,.1)">
                <i data-lucide="tag" width="15" height="15" style="color:#8b5cf6"></i>
            </div>
            <div class="rat-stat-label"><?= t('rat_categories') ?></div>
            <div class="rat-stat-val"><?= count($byCategory) ?></div>
        </div>
    </div>
</div>
</div><!-- end right -->

</div><!-- rat-layout -->

<?php /* ═══════════════════ EMPLOYER VIEW ════════════════════ */ ?>
<?php else: ?>

<div class="rat-layout">

<!-- LEFT -->
<div>

<!-- Form -->
<div class="rat-form-card">
    <div class="rat-form-card__head">
        <div class="rat-form-card__icon">
            <i data-lucide="star" width="16" height="16" fill="#fff" style="color:#fff"></i>
        </div>
        <div class="rat-form-card__title"><?= t('rat_leave_rating') ?></div>
    </div>
    <div class="rat-form-card__body">
        <form method="POST" novalidate>
            <div class="form-row" style="margin-bottom:18px">
                <div class="form-group" style="margin:0">
                    <label class="form-label"><?= t('rat_employee_label') ?> <span class="req">*</span></label>
                    <?php
                    $preEmpName = '';
                    if ($preEmployee) {
                        foreach ($employees as $e) {
                            if ($e['id'] === $preEmployee) { $preEmpName = $e['name']; break; }
                        }
                    }
                    ?>
                    <div style="position:relative" id="empSearchWrap">
                        <input type="text" id="empSearchInput" autocomplete="off"
                               class="form-control" style="font-size:14px"
                               placeholder="<?= t('emp_search_placeholder') ?>"
                               value="<?= htmlspecialchars($preEmpName) ?>">
                        <input type="hidden" name="employee_id" id="empIdHidden"
                               value="<?= $preEmployee ?: ((int)($_POST['employee_id'] ?? 0)) ?>">
                        <div id="empDropdown" style="display:none;position:absolute;top:100%;left:0;right:0;z-index:200;
                             background:var(--card-bg);border:1.5px solid var(--border);border-radius:12px;
                             margin-top:4px;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,.12)">
                        </div>
                    </div>
                </div>
                <div class="form-group" style="margin:0">
                    <label class="form-label"><?= t('rat_category_label') ?></label>
                    <select class="form-control" name="category" style="font-size:14px">
                        <option value=""><?= t('rat_general_option') ?></option>
                        <?php foreach (['Technical Skills','Communication','Reliability','Teamwork','Initiative','Design Quality','Problem Solving'] as $cat): ?>
                        <option value="<?= $cat ?>" <?= ($_POST['category'] ?? '') === $cat ? 'selected' : '' ?>><?= $cat ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label"><?= t('rat_score_label') ?> <span class="req">*</span>
                    <span style="font-size:12px;color:var(--text-muted);font-weight:400"> — <?= t('rat_score_range') ?></span>
                </label>
                <div class="ep-wrap">
                    <?php
                    $emap = [1=>'angry',2=>'frown',3=>'meh',4=>'smile',5=>'laugh'];
                    $elbl = [1=>t('score_bad'),2=>t('score_weak'),3=>t('score_ok'),4=>t('score_good'),5=>t('score_excellent')];
                    foreach ($emap as $v => $face):
                    ?>
                    <input type="radio" name="score" id="sc_<?= $v ?>" value="<?= $v ?>"
                           <?= (int)($_POST['score'] ?? 0) === $v ? 'checked' : '' ?>>
                    <label class="ep-label" for="sc_<?= $v ?>">
                        <span class="ep-face"><i data-lucide="<?= $face ?>" width="26" height="26" style="color:<?= scoreColor((float)($v*2)) ?>"></i></span>
                        <span class="ep-num"><?= $v*2 ?></span>
                        <span class="ep-lbl"><?= $elbl[$v] ?></span>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="form-group" style="margin-bottom:18px">
                <label class="form-label"><?= t('col_comment') ?></label>
                <textarea class="form-control" name="comment" rows="3"
                          placeholder="<?= t('comment_placeholder') ?>"
                          style="resize:vertical;font-size:14px"><?= htmlspecialchars($_POST['comment'] ?? '') ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary" style="gap:8px">
                <i data-lucide="star" width="14" height="14"></i>
                <?= t('submit_rating') ?>
            </button>
        </form>
    </div>
</div>

<!-- Given ratings -->
<div class="cat-section">
    <div class="cat-section__head">
        <div class="cat-section__icon" style="background:rgba(16,185,129,.1)">
            <i data-lucide="square-check" width="16" height="16" style="color:#10b981"></i>
        </div>
        <div class="cat-section__title"><?= t('rat_my_ratings') ?> <span style="font-size:12px;color:var(--text-muted);font-weight:400"><?= $statGiven ?></span></div>
    </div>
    <div class="cat-section__body">
    <?php if (empty($ratings)): ?>
        <div class="rat-empty">
            <div class="rat-empty__icon" style="color:var(--text-muted)"><i data-lucide="clipboard-list" width="44" height="44" stroke-width="1.5"></i></div>
            <div class="rat-empty__title"><?= t('rat_no_given_title') ?></div>
            <div class="rat-empty__sub"><?= t('rat_no_given_sub') ?></div>
        </div>
    <?php else: ?>
        <div class="review-list">
        <?php foreach ($ratings as $r):
            $s10  = $r['score'] * 2;
            $col  = scoreColor((float)$s10);
            $pct  = $s10 * 10;
            $cat  = $r['category'] ?: t('general_category');
            $grad = avatarGrad($r['employee_name']);
            $init = mb_strtoupper(mb_substr($r['employee_name'], 0, 1));
        ?>
        <div class="review-card">
            <div class="review-card__top">
                <div class="review-card__ava" style="background:<?= $grad ?>">
                    <?php if (!empty($r['avatar'])): ?>
                        <img src="<?= BASE_URL ?>/assets/uploads/avatars/<?= htmlspecialchars($r['avatar']) ?>" alt="">
                    <?php else: ?>
                        <?= $init ?>
                    <?php endif; ?>
                </div>
                <div style="flex:1;min-width:0">
                    <div class="review-card__name"><?= htmlspecialchars($r['employee_name']) ?></div>
                    <div class="review-card__sub"><?= htmlspecialchars($r['position'] ?: '') ?></div>
                </div>
                <div class="review-card__time">
                    <i data-lucide="clock" width="11" height="11"></i>
                    <?= timeAgo($r['created_at']) ?>
                </div>
            </div>

            <div class="review-card__score-row">
                <div class="review-score-pill" style="background:<?= $col ?>18;color:<?= $col ?>;border:1.5px solid <?= $col ?>33">
                    <?= scoreEmoji((float)$s10) ?> <?= $s10 ?>/10
                </div>
                <div class="review-bar-wrap">
                    <div class="review-bar-track">
                        <div class="review-bar-fill" data-pct="<?= $pct ?>"
                             style="background:linear-gradient(90deg,<?= $col ?>88,<?= $col ?>)"></div>
                    </div>
                    <div class="review-bar-ticks">
                        <?php for($t=0;$t<=10;$t+=2): ?>
                        <span class="review-bar-tick"><?= $t ?></span>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>

            <span class="review-card__cat" style="background:<?= $col ?>14;color:<?= $col ?>;border:1px solid <?= $col ?>30">
                <i data-lucide="tag" width="11" height="11"></i>
                <?= htmlspecialchars($cat) ?>
            </span>

            <?php if ($r['comment']): ?>
            <div class="review-card__comment"><?= nl2br(htmlspecialchars($r['comment'])) ?></div>
            <?php endif; ?>

            <div style="margin-top:10px">
                <a href="<?= BASE_URL ?>/pages/resume_view.php?id=<?= $r['employee_id'] ?>"
                   style="display:inline-flex;align-items:center;gap:4px;font-size:12px;color:var(--primary);text-decoration:none;font-weight:500;padding:3px 8px;border-radius:8px;border:1px solid rgba(37,99,235,.2);background:rgba(37,99,235,.06)">
                    <i data-lucide="file-text" width="11" height="11"></i>
                    <?= t('nav_resume') ?>
                </a>
            </div>
        </div>
        <?php endforeach; ?>
        </div>

        <?php if ($ratTotalPages > 1): ?>
        <div style="display:flex;justify-content:center;align-items:center;gap:6px;margin-top:16px;flex-wrap:wrap">
            <?php
            $range2 = []; $prev2 = null;
            for ($i = 1; $i <= $ratTotalPages; $i++) {
                if ($i === 1 || $i === $ratTotalPages || abs($i - $ratPage) <= 2) $range2[] = $i;
            }
            foreach ($range2 as $pg):
                if ($prev2 !== null && $pg - $prev2 > 1): ?>
                <span style="color:var(--text-muted)">…</span>
                <?php endif;
                $pgUrl2 = BASE_URL . '/pages/ratings.php?' . http_build_query(['page' => $pg]);
            ?>
            <a href="<?= $pgUrl2 ?>"
               style="display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:10px;font-size:13px;font-weight:<?= $pg===$ratPage?'700':'500' ?>;text-decoration:none;border:1.5px solid <?= $pg===$ratPage?'var(--primary)':'var(--border)' ?>;background:<?= $pg===$ratPage?'var(--primary)':'var(--card-bg)' ?>;color:<?= $pg===$ratPage?'#fff':'var(--text-primary)' ?>;transition:all .14s">
                <?= $pg ?>
            </a>
            <?php $prev2 = $pg; endforeach; ?>
        </div>
        <?php endif; ?>

    <?php endif; ?>
    </div>
</div>

</div><!-- end left -->

<!-- RIGHT: sidebar stats -->
<div>
<div class="rat-stat-card">
    <div class="rat-stat-card__head"><?= t('rat_my_stats') ?></div>
    <div class="rat-stat-card__body">
        <div class="rat-stat-row">
            <div class="rat-stat-icon" style="background:rgba(37,99,235,.1)">
                <i data-lucide="star" width="15" height="15" fill="#2563eb" style="color:#2563eb"></i>
            </div>
            <div class="rat-stat-label"><?= t('rat_given_count') ?></div>
            <div class="rat-stat-val"><?= $statGiven ?></div>
        </div>
        <div class="rat-stat-row">
            <div class="rat-stat-icon" style="background:rgba(16,185,129,.1)">
                <i data-lucide="users" width="15" height="15" style="color:#10b981"></i>
            </div>
            <div class="rat-stat-label"><?= t('rat_unique_emps') ?></div>
            <div class="rat-stat-val"><?= $statUniq ?></div>
        </div>
        <div class="rat-stat-row">
            <div class="rat-stat-icon" style="background:rgba(245,158,11,.1)">
                <i data-lucide="activity" width="15" height="15" style="color:#f59e0b"></i>
            </div>
            <div class="rat-stat-label"><?= t('rat_avg_given') ?></div>
            <div class="rat-stat-val" style="color:<?= scoreColor((float)$statAvg10) ?>"><?= $statAvg10 ?>/10</div>
        </div>
    </div>
</div>

<?php if ($statGiven > 0): ?>
<div class="rat-stat-card">
    <div class="rat-stat-card__head"><?= t('rat_distribution') ?></div>
    <div class="rat-stat-card__body" style="padding:16px 18px">
    <?php
    $dist = array_fill(1, 5, 0);
    foreach ($allRatings as $r) $dist[$r['score']] = ($dist[$r['score']] ?? 0) + 1;
    $emap2 = [1=>'angry',2=>'frown',3=>'meh',4=>'smile',5=>'laugh'];
    foreach (array_reverse(array_keys($dist), true) as $sc):
        $cnt = $dist[$sc];
        $pct2 = $statGiven ? round(($cnt/$statGiven)*100) : 0;
        $c   = scoreColor((float)($sc*2));
    ?>
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
        <span style="display:inline-flex;color:<?= $c ?>"><i data-lucide="<?= $emap2[$sc] ?>" width="18" height="18"></i></span>
        <div style="flex:1">
            <div style="height:7px;background:var(--border-light);border-radius:100px;overflow:hidden">
                <div style="height:100%;width:<?= $pct2 ?>%;background:<?= $c ?>;border-radius:100px;transition:width .8s"></div>
            </div>
        </div>
        <span style="font-size:12px;font-weight:700;color:var(--text-muted);min-width:24px;text-align:right"><?= $cnt ?></span>
    </div>
    <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>
</div><!-- end right -->

</div><!-- rat-layout -->
<?php endif; ?>

<script>
// ── Employee search autocomplete ──────────────────────────────
(function () {
    const input   = document.getElementById('empSearchInput');
    const hidden  = document.getElementById('empIdHidden');
    const dropdown = document.getElementById('empDropdown');
    if (!input) return;

    let timer;

    input.addEventListener('input', function () {
        clearTimeout(timer);
        hidden.value = '';
        const q = this.value.trim();
        if (q.length < 1) { dropdown.style.display = 'none'; dropdown.innerHTML = ''; return; }
        timer = setTimeout(() => fetchEmployees(q), 220);
    });

    input.addEventListener('keydown', function (e) {
        const items = dropdown.querySelectorAll('.emp-dd-item');
        const active = dropdown.querySelector('.emp-dd-item.active');
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            const next = active ? (active.nextElementSibling || items[0]) : items[0];
            if (active) active.classList.remove('active');
            if (next) next.classList.add('active');
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            const prev = active ? (active.previousElementSibling || items[items.length-1]) : items[items.length-1];
            if (active) active.classList.remove('active');
            if (prev) prev.classList.add('active');
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (active) active.click();
        } else if (e.key === 'Escape') {
            dropdown.style.display = 'none';
        }
    });

    document.addEventListener('click', function (e) {
        if (!document.getElementById('empSearchWrap').contains(e.target)) {
            dropdown.style.display = 'none';
        }
    });

    async function fetchEmployees(q) {
        try {
            const res = await fetch('<?= BASE_URL ?>/pages/api/search_employees.php?q=' + encodeURIComponent(q));
            const data = await res.json();
            renderDropdown(data);
        } catch(e) {}
    }

    function renderDropdown(items) {
        if (!items.length) {
            dropdown.innerHTML = '<div style="padding:12px 16px;font-size:13px;color:var(--text-muted)"><?= t('rat_no_employees') ?></div>';
            dropdown.style.display = 'block';
            return;
        }
        dropdown.innerHTML = items.map(e => `
            <div class="emp-dd-item" data-id="${e.id}" data-name="${escHtml(e.name)}"
                 style="display:flex;align-items:center;gap:10px;padding:10px 14px;cursor:pointer;transition:background .12s">
                <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,#3b82f6,#1d4ed8);
                            display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;color:#fff;flex-shrink:0">
                    ${e.avatar
                        ? `<img src="<?= BASE_URL ?>/assets/uploads/avatars/${escHtml(e.avatar)}" style="width:32px;height:32px;border-radius:50%;object-fit:cover">`
                        : escHtml(e.name.charAt(0).toUpperCase())}
                </div>
                <div>
                    <div style="font-size:13px;font-weight:600;color:var(--text-primary)">${escHtml(e.name)}</div>
                    ${e.position ? `<div style="font-size:11px;color:var(--text-muted)">${escHtml(e.position)}</div>` : ''}
                </div>
            </div>
        `).join('');
        dropdown.querySelectorAll('.emp-dd-item').forEach(item => {
            item.addEventListener('mouseenter', () => {
                dropdown.querySelectorAll('.emp-dd-item').forEach(i => i.classList.remove('active'));
                item.classList.add('active');
            });
            item.addEventListener('click', () => {
                hidden.value = item.dataset.id;
                input.value  = item.dataset.name;
                dropdown.style.display = 'none';
            });
        });
        dropdown.style.display = 'block';
    }

    function escHtml(s) {
        return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }
})();

// Highlight active dropdown item
document.addEventListener('DOMContentLoaded', () => {
    const style = document.createElement('style');
    style.textContent = '.emp-dd-item:hover,.emp-dd-item.active{background:var(--border-light)}';
    document.head.appendChild(style);
});

// Animate bars on page load
document.addEventListener('DOMContentLoaded', () => {
    // Category bars
    document.querySelectorAll('.cat-row').forEach(row => {
        const fill = row.querySelector('.cat-fill');
        if (fill) {
            const pct = parseFloat(row.dataset.pct) || 0;
            requestAnimationFrame(() => setTimeout(() => fill.style.width = pct + '%', 80));
        }
    });
    // Review bars
    document.querySelectorAll('.review-bar-fill').forEach(bar => {
        const pct = parseFloat(bar.dataset.pct) || 0;
        requestAnimationFrame(() => setTimeout(() => bar.style.width = pct + '%', 120));
    });
    // Hero gauge bar
    const gaugeBar = document.getElementById('gaugeBarFill');
    if (gaugeBar) {
        const pct = parseFloat(gaugeBar.dataset.pct) || 0;
        requestAnimationFrame(() => setTimeout(() => gaugeBar.style.width = pct + '%', 100));
    }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
