<?php
function getCoverMap(): array {
    return [
        'tech'        => ['Tech',        'https://images.unsplash.com/photo-1461749280684-dccba630e2f6'],
        'design'      => ['Дизайн',      'https://images.unsplash.com/photo-1561070791-2526d30994b5'],
        'marketing'   => ['Маркетинг',   'https://images.unsplash.com/photo-1460925895917-afdab827c52f'],
        'management'  => ['Менеджмент',  'https://images.unsplash.com/photo-1552664730-d307ca884978'],
        'hr'          => ['HR',          'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2'],
        'sales'       => ['Продажи',     'https://images.unsplash.com/photo-1521737604893-d14cc237f11d'],
        'finance'     => ['Финансы',     'https://images.unsplash.com/photo-1554224155-6726b3ff858f'],
        'data'        => ['Аналитика',   'https://images.unsplash.com/photo-1551288049-bebda4e38f71'],
        'engineering' => ['Инженерия',   'https://images.unsplash.com/photo-1581094794329-c8112a89af12'],
        'remote'      => ['Удалённо',    'https://images.unsplash.com/photo-1593642532559-2f6e84b96b8b'],
        'startup'     => ['Стартап',     'https://images.unsplash.com/photo-1519389950473-47ba0277781c'],
        'medical'     => ['Медицина',    'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d'],
        'education'   => ['Образование', 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655'],
        'creative'    => ['Креатив',     'https://images.unsplash.com/photo-1558618666-fcd25c85cd64'],
        'customer'    => ['Поддержка',   'https://images.unsplash.com/photo-1557804506-669a67965ba0'],
        'default'     => ['Другое',      'https://images.unsplash.com/photo-1497366216548-37526070297c'],
    ];
}

function vacancyCoverCat(string $title, string $stored): string {
    if ($stored && $stored !== 'default') return $stored;
    $lower = strtolower($title);
    $keywords = [
        'tech'        => ['php','javascript',' js','python','react','angular','vue','developer','backend','frontend','devops','java','kotlin','swift','программист','разработчик','nodejs','ruby','golang','typescript','c++','c#'],
        'design'      => ['design','дизайн','ux','figma','photoshop','illustrator','арт-директор'],
        'marketing'   => ['marketing','маркетинг','seo','smm','реклам','контент-менеджер'],
        'management'  => ['manager','менеджер','director','директор','ceo','lead','руководитель','начальник'],
        'hr'          => [' hr','рекрутер','рекрутинг','подбор персонала','кадров'],
        'sales'       => ['sales','продаж','продавец','торговый'],
        'finance'     => ['финансов','бухгалтер','accountant','экономист','аудитор','finance'],
        'data'        => ['data','аналитик','analyst',' bi ',' ml ','machine learning','data science'],
        'engineering' => ['engineer','инженер','техник','механик','электрик','сварщик'],
        'remote'      => ['remote','удаленн','фриланс'],
        'startup'     => ['startup','стартап'],
        'medical'     => ['медицин','врач','медсестр','фармацевт','хирург'],
        'education'   => ['учитель','преподаватель','teacher','тренер','педагог','репетитор'],
        'creative'    => ['copywriter','копирайтер','writer','автор','редактор','журналист'],
        'customer'    => ['support','поддержк','оператор','call center','колл-центр'],
    ];
    foreach ($keywords as $cat => $kws) {
        foreach ($kws as $kw) {
            if (str_contains($lower, $kw)) return $cat;
        }
    }
    return 'default';
}

function vacancyCoverUrl(string $cover, int $w = 176, int $h = 0): string {
    // Uploaded file — contains a dot (e.g. cover_1_abc.jpg)
    if ($cover && str_contains($cover, '.')) {
        return BASE_URL . '/assets/uploads/covers/' . rawurlencode($cover);
    }
    // Category key → Unsplash fallback
    $map = getCoverMap();
    $base = $map[$cover][1] ?? $map['default'][1];
    $q = "auto=format&fit=crop&w=$w&q=80";
    if ($h > 0) $q .= "&h=$h";
    return $base . '?' . $q;
}
