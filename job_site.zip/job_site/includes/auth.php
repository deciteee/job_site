<?php
// ================================================================
// Authentication helpers
// ================================================================
require_once __DIR__ . '/i18n.php';

function requireLogin(): void {
    if (!isset($_SESSION['user_id'])) {
        header('Location: ' . BASE_URL . '/pages/login.php');
        exit;
    }
}

function requireRole(string $role): void {
    requireLogin();
    if ($_SESSION['user_role'] !== $role) {
        header('Location: ' . BASE_URL . '/pages/dashboard.php');
        exit;
    }
}

function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}

function currentUser(): array {
    return [
        'id'     => $_SESSION['user_id']     ?? null,
        'name'   => $_SESSION['user_name']   ?? null,
        'role'   => $_SESSION['user_role']   ?? null,
        'email'  => $_SESSION['user_email']  ?? null,
        'avatar' => $_SESSION['user_avatar'] ?? null,
    ];
}

function isEmployer(): bool {
    return ($_SESSION['user_role'] ?? '') === 'employer';
}

function isEmployee(): bool {
    return ($_SESSION['user_role'] ?? '') === 'employee';
}

function isAdmin(): bool {
    return ($_SESSION['user_role'] ?? '') === 'admin';
}

function requireAdmin(): void {
    requireLogin();
    if (!isAdmin()) {
        header('Location: ' . BASE_URL . '/pages/dashboard.php');
        exit;
    }
}

function getUserInitials(string $name): string {
    $parts = explode(' ', trim($name));
    $initials = '';
    foreach ($parts as $p) {
        $initials .= mb_strtoupper(mb_substr($p, 0, 1));
        if (mb_strlen($initials) >= 2) break;
    }
    return $initials ?: 'U';
}

function csrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrf(): void {
    $token = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(403);
        die('CSRF validation failed. Please go back and try again.');
    }
}
