<?php
// ================================================================
// Internationalization — i18n helper
// Languages: ru (Русский), kz (Қазақша), en (English)
// ================================================================

function setLanguage(): void {
    if (isset($_GET['setlang']) && in_array($_GET['setlang'], ['ru', 'kz', 'en'])) {
        $_SESSION['lang'] = $_GET['setlang'];
        $params = $_GET;
        unset($params['setlang']);
        $base = strtok($_SERVER['REQUEST_URI'], '?');
        $redirect = $base . ($params ? '?' . http_build_query($params) : '');
        header('Location: ' . $redirect);
        exit;
    }
}

function loadTranslations(): array {
    $lang = $_SESSION['lang'] ?? 'ru';
    $file = __DIR__ . '/../lang/' . $lang . '.php';
    return file_exists($file) ? require $file : require __DIR__ . '/../lang/ru.php';
}

function t(string $key): string {
    return $GLOBALS['_t'][$key] ?? $key;
}

function currentLang(): string {
    return $_SESSION['lang'] ?? 'ru';
}

// Run on include
setLanguage();
$GLOBALS['_t'] = loadTranslations();
