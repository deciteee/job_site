<?php require_once __DIR__ . '/i18n.php'; ?>
<!DOCTYPE html>
<html lang="<?= currentLang() === 'kz' ? 'kk' : 'ru' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) . ' — ' . SITE_NAME : SITE_NAME . ' — ' . t('site_tagline') ?></title>
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>/assets/favicon.png?v=2">
    <link rel="shortcut icon" type="image/png" href="<?= BASE_URL ?>/assets/favicon.png?v=2">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css?v=<?= filemtime(__DIR__ . '/../assets/css/style.css') ?>">
    <!-- Prevent flash of wrong theme -->
    <script>(function(){var t=localStorage.getItem('nexio-theme')||'light';document.documentElement.setAttribute('data-theme',t);})()</script>
    <!-- Prevent flash of wrong sidebar state: class is added inline on the element itself -->
</head>
<body class="app-body">

<div class="app-layout">
    <!-- ===== Sidebar ===== -->
    <aside class="app-sidebar" id="sidebar"><script>(function(){var c=localStorage.getItem('nexio-sb-pinned');if(c==='0'){var el=document.getElementById('sidebar');el.classList.add('collapsed','no-sb-transition');setTimeout(function(){el.classList.remove('no-sb-transition');},50);}})();</script>

        <!-- Brand / Logo -->
        <div class="sidebar-brand">
            <a href="<?= BASE_URL ?>/" class="sidebar-brand__logo">
                <svg class="nexio-logo" viewBox="0 0 28 32" fill="none" height="28">
                    <defs>
                        <linearGradient id="nexio-g-sb" x1="0" y1="0" x2="1" y2="1">
                            <stop offset="0%" stop-color="#60a5fa"/>
                            <stop offset="100%" stop-color="#2563eb"/>
                        </linearGradient>
                    </defs>
                    <path d="M4 27V7L22 27V7" stroke="url(#nexio-g-sb)" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
                    <circle cx="22" cy="2.5" r="3" fill="#3b82f6"/>
                </svg>
                <span class="sidebar-brand__text">exio</span>
            </a>
            <button class="sidebar-pin-btn" id="sidebarPin" type="button" title="<?= t('sidebar_toggle') ?>">
                <i class="sb-icon-collapse" data-lucide="chevrons-left" width="14" height="14"></i>
                <i class="sb-icon-expand" data-lucide="chevrons-right" width="14" height="14" style="display:none"></i>
            </button>
        </div>

        <?php $user = currentUser(); ?>

        <nav class="sidebar-nav">
            <div class="sidebar-nav__section-label"><?= t('nav_main') ?></div>

            <a href="<?= BASE_URL ?>/pages/dashboard.php"
               data-tip="<?= t('nav_dashboard') ?>"
               class="sidebar-nav__item <?= basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : '' ?>">
                <i class="nav-icon" data-lucide="layout-grid"></i>
                <span class="nav-label"><?= t('nav_dashboard') ?></span>
            </a>

            <a href="<?= BASE_URL ?>/pages/vacancies.php"
               data-tip="<?= t('nav_vacancies') ?>"
               class="sidebar-nav__item <?= in_array(basename($_SERVER['PHP_SELF']), ['vacancies.php','vacancy_create.php','vacancy_detail.php']) ? 'active' : '' ?>">
                <i class="nav-icon" data-lucide="briefcase"></i>
             <img src="<?= BASE_URL ?>assets/uploads/house.svg" alt="">
                <span class="nav-label"><?= t('nav_vacancies') ?></span>
            </a>

            <a href="<?= BASE_URL ?>/pages/ratings.php"
               data-tip="<?= t('nav_ratings') ?>"
               class="sidebar-nav__item <?= in_array(basename($_SERVER['PHP_SELF']), ['ratings.php']) ? 'active' : '' ?>">
                <i class="nav-icon" data-lucide="star"></i>
                <span class="nav-label"><?= t('nav_ratings') ?></span>
            </a>


<?php if (isEmployee()): ?>
            <a href="<?= BASE_URL ?>/pages/resume.php"
               data-tip="<?= t('nav_resume') ?>"
               class="sidebar-nav__item <?= in_array(basename($_SERVER['PHP_SELF']), ['resume.php','resume_view.php']) ? 'active' : '' ?>">
                <i class="nav-icon" data-lucide="file-text"></i>
                <span class="nav-label"><?= t('nav_resume') ?></span>
            </a>
            <?php endif; ?>

            <?php if (isAdmin() || isEmployer()): ?>
            <div class="sidebar-nav__section-label"><?= t('nav_account') ?></div>
            <?php endif; ?>

            <?php if (isAdmin()): ?>
            <a href="<?= BASE_URL ?>/pages/admin.php"
               data-tip="<?= t('nav_admin') ?>"
               class="sidebar-nav__item <?= basename($_SERVER['PHP_SELF']) === 'admin.php' ? 'active' : '' ?>">
                <i class="nav-icon" data-lucide="shield"></i>
                <span class="nav-label"><?= t('nav_admin') ?></span>
            </a>
            <?php endif; ?>

            <?php if (isEmployer()): ?>
            <a href="<?= BASE_URL ?>/pages/employees.php"
               data-tip="<?= t('nav_employees') ?>"
               class="sidebar-nav__item <?= basename($_SERVER['PHP_SELF']) === 'employees.php' ? 'active' : '' ?>">
                <i class="nav-icon" data-lucide="users"></i>
                <span class="nav-label"><?= t('nav_employees') ?></span>
            </a>
            <a href="<?= BASE_URL ?>/pages/vacancy_create.php"
               data-tip="<?= t('nav_post_vacancy') ?>"
               class="sidebar-nav__item sidebar-nav__item--cta">
                <i class="nav-icon" data-lucide="circle-plus"></i>
                <span class="nav-label"><?= t('nav_post_vacancy') ?></span>
            </a>
            <?php endif; ?>
        </nav>

        <div class="sidebar-user">
            <a href="<?= BASE_URL ?>/pages/profile.php"
               class="sidebar-user__link <?= basename($_SERVER['PHP_SELF']) === 'profile.php' ? 'active' : '' ?>"
               title="<?= t('nav_profile') ?>">
                <div class="sidebar-user__avatar">
                    <?php if (!empty($user['avatar'])): ?>
                        <img src="<?= BASE_URL ?>/assets/uploads/avatars/<?= htmlspecialchars($user['avatar']) ?>" alt="">
                    <?php else: ?>
                        <?= getUserInitials($user['name']) ?>
                    <?php endif; ?>
                </div>
                <div class="sidebar-user__info">
                    <div class="sidebar-user__name"><?= htmlspecialchars($user['name']) ?></div>
                    <div class="sidebar-user__role"><?= $user['role'] === 'employer' ? t('employer') : t('employee') ?></div>
                </div>
            </a>
            <a href="<?= BASE_URL ?>/pages/logout.php" class="sidebar-user__logout" title="<?= t('sign_out') ?>">
                <i data-lucide="log-out" width="16" height="16"></i>
            </a>
        </div>
    </aside>

    <!-- ===== Main ===== -->
    <div class="app-main">
        <header class="app-topbar">
            <button class="topbar-menu-btn" id="menuToggle" aria-label="Menu">
                <i data-lucide="menu" width="20" height="20"></i>
            </button>
            <div class="topbar-title"><?= isset($pageTitle) ? htmlspecialchars($pageTitle) : t('dashboard') ?></div>

            <div class="topbar-controls">
                <!-- Language dropdown -->
                <?php
                $langNames = ['ru' => 'Русский', 'kz' => 'Қазақша', 'en' => 'English'];
                $langCodes = ['ru' => 'РУ', 'kz' => 'ҚЗ', 'en' => 'EN'];
                $curLang   = currentLang();
                $langQuery = http_build_query(array_diff_key($_GET, ['setlang' => '']));
                $langQ     = $langQuery ? '&' . $langQuery : '';
                ?>
                <div class="lang-dropdown" id="langDropdownMain">
                    <button class="lang-dropdown__trigger" type="button"
                            onclick="document.getElementById('langDropdownMain').classList.toggle('open')">
                        <i data-lucide="globe" width="13" height="13"></i>
                        <?= $langCodes[$curLang] ?>
                        <i data-lucide="chevron-down" width="10" height="10"></i>
                    </button>
                    <div class="lang-dropdown__menu">
                        <?php foreach ($langNames as $code => $name): ?>
                        <a href="?setlang=<?= $code ?><?= $langQ ?>"
                           class="lang-dropdown__item <?= $curLang === $code ? 'active' : '' ?>">
                            <?= $name ?>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Theme toggle -->
                <button class="theme-btn" data-action="theme" title="Toggle theme">
                    <i data-lucide="moon" width="15" height="15"></i>
                </button>

                <span class="topbar-role-badge topbar-role-badge--<?= $user['role'] ?>">
                    <?= $user['role'] === 'employer' ? t('employer') : t('employee') ?>
                </span>
            </div>
        </header>

        <main class="app-content">
