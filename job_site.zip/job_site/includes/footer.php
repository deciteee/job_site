        </main><!-- /.app-content -->

    </div><!-- /.app-main -->
</div><!-- /.app-layout -->

<?php if (isset($_SESSION['user_id']) && isset($conn)):
    $fw_uid      = (int)$_SESSION['user_id'];
    $fw_contacts = [];
    $fw_unread   = 0;

    // Unread count
    $fw_q = $conn->prepare("SELECT COUNT(*) FROM messages WHERE receiver_id=? AND is_read=0");
    if ($fw_q) {
        $fw_q->bind_param('i', $fw_uid);
        $fw_q->execute();
        $fw_q->bind_result($fw_unread);
        $fw_q->fetch();
        $fw_q->close();
    }

    // Recent conversations — same query as chat.php
    $fw_q2 = $conn->prepare("
        SELECT DISTINCT u.id, u.name, u.role, u.company, u.position,
            (SELECT COUNT(*) FROM messages m2
             WHERE m2.sender_id=u.id AND m2.receiver_id=? AND m2.is_read=0) AS unread,
            (SELECT m3.sent_at FROM messages m3
             WHERE (m3.sender_id=u.id AND m3.receiver_id=?)
                OR (m3.sender_id=? AND m3.receiver_id=u.id)
             ORDER BY m3.sent_at DESC LIMIT 1) AS last_msg_at
        FROM messages m
        JOIN users u ON (m.sender_id=u.id OR m.receiver_id=u.id)
        WHERE (m.sender_id=? OR m.receiver_id=?) AND u.id != ?
        GROUP BY u.id
        ORDER BY last_msg_at DESC
        LIMIT 30
    ");
    if ($fw_q2) {
        $fw_q2->bind_param('iiiiii', $fw_uid, $fw_uid, $fw_uid, $fw_uid, $fw_uid, $fw_uid);
        $fw_q2->execute();
        $fw_contacts = $fw_q2->get_result()->fetch_all(MYSQLI_ASSOC);
        $fw_q2->close();
    }
?>
<!-- ===== Floating Chat Widget ===== -->
<div class="fchat" id="fchatWidget">
    <button class="fchat__btn" id="fchatBtn" title="Сообщения">
        <i data-lucide="message-square" width="22" height="22"></i>
        <?php if ($fw_unread > 0): ?>
            <span class="fchat__badge"><?= $fw_unread > 99 ? '99+' : $fw_unread ?></span>
        <?php endif; ?>
    </button>

    <div class="fchat__panel" id="fchatPanel">
        <div class="fchat__header">
            <span class="fchat__title">Чаты</span>
            <div class="fchat__header-actions">
                <a href="<?= BASE_URL ?>/pages/chat.php" class="fchat__icon-btn" title="Открыть переписку">
                    <i data-lucide="external-link" width="16" height="16"></i>
                </a>
                <button class="fchat__icon-btn" id="fchatClose" title="Закрыть">
                    <i data-lucide="x" width="16" height="16"></i>
                </button>
            </div>
        </div>

        <div class="fchat__list">
            <?php if (empty($fw_contacts)): ?>
                <div class="fchat__empty">
                    <i data-lucide="message-square" width="44" height="44" stroke-width="1.5"></i>
                    <p>Начните общаться с работодателями</p>
                    <a href="<?= BASE_URL ?>/pages/chat.php"
                       class="btn btn-primary"
                       style="margin-top:12px;font-size:13px;padding:8px 16px">
                        Открыть чаты
                    </a>
                </div>
            <?php else: ?>
                <?php foreach ($fw_contacts as $fc):
                    $isActive = basename($_SERVER['PHP_SELF']) === 'chat.php'
                                && isset($_GET['with'])
                                && (int)$_GET['with'] === (int)$fc['id'];
                ?>
                <a href="<?= BASE_URL ?>/pages/chat.php?with=<?= $fc['id'] ?>"
                   class="fchat__item<?= $isActive ? ' fchat__item--active' : '' ?>">
                    <div class="fchat__avatar"><?= getUserInitials($fc['name']) ?></div>
                    <div class="fchat__info">
                        <div class="fchat__name"><?= htmlspecialchars($fc['name']) ?></div>
                        <div class="fchat__preview">
                            <?= htmlspecialchars(ucfirst($fc['role']))
                                . ($fc['company'] ? ' · ' . htmlspecialchars($fc['company']) : '') ?>
                        </div>
                    </div>
                    <div class="fchat__meta">
                        <?php if ($fc['last_msg_at']): ?>
                            <div class="fchat__time"><?= date('d.m', strtotime($fc['last_msg_at'])) ?></div>
                        <?php endif; ?>
                        <?php if ($fc['unread'] > 0): ?>
                            <span class="fchat__unread-badge"><?= $fc['unread'] ?></span>
                        <?php endif; ?>
                    </div>
                </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<script src="<?= BASE_URL ?>/assets/js/lucide.min.js?v=<?= asset_ver('assets/js/lucide.min.js') ?>"></script>
<script src="<?= BASE_URL ?>/assets/js/app.js?v=<?= asset_ver('assets/js/app.js') ?>"></script>
</body>
</html>
