<?php
// ================================================================
// Mailer — PHPMailer wrapper for Gmail SMTP
// ================================================================
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../lib/phpmailer/src/Exception.php';
require_once __DIR__ . '/../lib/phpmailer/src/PHPMailer.php';
require_once __DIR__ . '/../lib/phpmailer/src/SMTP.php';

// Mailer credentials are defined in config.php

function _buildMailer(): PHPMailer
{
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = GMAIL_USER;
    $mail->Password   = GMAIL_PASS;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;
    $mail->CharSet    = 'UTF-8';
    $mail->setFrom(MAIL_FROM, MAIL_FROM_NAME);
    return $mail;
}

function sendVerificationEmail(string $toEmail, string $toName, string $token): bool
{
    $link = BASE_URL . '/pages/verify.php?token=' . urlencode($token);
    $firstName = explode(' ', $toName)[0];

    $html = <<<HTML
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif">
<div style="max-width:540px;margin:40px auto;background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 4px 32px rgba(0,0,0,.10)">
  <div style="background:linear-gradient(135deg,#1e40af 0%,#2563eb 100%);padding:30px 40px 28px">
    <div style="color:#fff;font-size:26px;font-weight:800;letter-spacing:-0.5px">Nexio</div>
    <div style="color:rgba(255,255,255,.65);font-size:13px;margin-top:3px">HR-платформа нового поколения</div>
  </div>
  <div style="padding:36px 40px 40px">
    <h1 style="font-size:21px;font-weight:700;color:#1e293b;margin:0 0 10px">Подтвердите ваш email</h1>
    <p style="color:#475569;font-size:15px;line-height:1.65;margin:0 0 28px">
      Привет, <strong>{$firstName}</strong>! Рады видеть тебя в Nexio.<br>
      Нажмите кнопку ниже, чтобы активировать аккаунт и начать работу.
    </p>
    <a href="{$link}"
       style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;
              padding:14px 32px;border-radius:9px;font-weight:600;font-size:15px;
              letter-spacing:.01em">
      ✉ Подтвердить email
    </a>
    <p style="margin:28px 0 0;font-size:12px;color:#94a3b8;line-height:1.6">
      Ссылка действует 24 часа. Если вы не регистрировались на Nexio — просто проигнорируйте это письмо.
      <br>Или скопируйте ссылку вручную:<br>
      <span style="color:#2563eb;word-break:break-all">{$link}</span>
    </p>
  </div>
  <div style="background:#f8fafc;padding:16px 40px;border-top:1px solid #e2e8f0;font-size:12px;color:#94a3b8">
    © Nexio HR Platform — Дипломная работа
  </div>
</div>
</body>
</html>
HTML;

    try {
        $mail = _buildMailer();
        $mail->addAddress($toEmail, $toName);
        $mail->isHTML(true);
        $mail->Subject = 'Подтвердите ваш email — Nexio';
        $mail->Body    = $html;
        $mail->AltBody = "Привет, {$firstName}!\n\nПодтвердите email по ссылке:\n{$link}\n\nСсылка действует 24 часа.";
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Mailer error: ' . $e->getMessage());
        return false;
    }
}

function sendPasswordResetEmail(string $toEmail, string $toName, string $token): bool
{
    $link      = BASE_URL . '/pages/reset_password.php?token=' . urlencode($token);
    $firstName = explode(' ', $toName)[0];

    $html = <<<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif">
<div style="max-width:540px;margin:40px auto;background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 4px 32px rgba(0,0,0,.10)">
  <div style="background:linear-gradient(135deg,#1e40af 0%,#2563eb 100%);padding:30px 40px 28px">
    <div style="color:#fff;font-size:26px;font-weight:800;letter-spacing:-0.5px">Nexio</div>
    <div style="color:rgba(255,255,255,.65);font-size:13px;margin-top:3px">HR-платформа нового поколения</div>
  </div>
  <div style="padding:36px 40px 40px">
    <h1 style="font-size:21px;font-weight:700;color:#1e293b;margin:0 0 10px">Сброс пароля</h1>
    <p style="color:#475569;font-size:15px;line-height:1.65;margin:0 0 28px">
      Привет, <strong>{$firstName}</strong>!<br>
      Вы запросили сброс пароля на Nexio. Нажмите кнопку ниже — ссылка действует 1 час.
    </p>
    <a href="{$link}" style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;
       padding:14px 32px;border-radius:9px;font-weight:600;font-size:15px">
      🔑 Сбросить пароль
    </a>
    <p style="margin:28px 0 0;font-size:12px;color:#94a3b8;line-height:1.6">
      Если вы не запрашивали сброс — просто проигнорируйте это письмо.<br>
      <span style="color:#2563eb;word-break:break-all">{$link}</span>
    </p>
  </div>
  <div style="background:#f8fafc;padding:16px 40px;border-top:1px solid #e2e8f0;font-size:12px;color:#94a3b8">
    © Nexio HR Platform — Дипломная работа
  </div>
</div>
</body></html>
HTML;

    try {
        $mail = _buildMailer();
        $mail->addAddress($toEmail, $toName);
        $mail->isHTML(true);
        $mail->Subject = 'Сброс пароля — Nexio';
        $mail->Body    = $html;
        $mail->AltBody = "Привет, {$firstName}!\n\nСбросьте пароль по ссылке:\n{$link}\n\nСсылка действует 1 час.";
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Mailer error: ' . $e->getMessage());
        return false;
    }
}

function sendApplicationNotification(
    string $employerEmail, string $employerName,
    string $applicantName, string $vacancyTitle, string $vacancyUrl
): bool {
    $firstName = explode(' ', $employerName)[0];
    $html = <<<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif">
<div style="max-width:540px;margin:40px auto;background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 4px 32px rgba(0,0,0,.10)">
  <div style="background:linear-gradient(135deg,#1e40af 0%,#2563eb 100%);padding:30px 40px 28px">
    <div style="color:#fff;font-size:26px;font-weight:800;letter-spacing:-0.5px">Nexio</div>
    <div style="color:rgba(255,255,255,.65);font-size:13px;margin-top:3px">Новый отклик на вакансию</div>
  </div>
  <div style="padding:36px 40px 40px">
    <h1 style="font-size:21px;font-weight:700;color:#1e293b;margin:0 0 10px">Новый отклик!</h1>
    <p style="color:#475569;font-size:15px;line-height:1.65;margin:0 0 6px">
      Здравствуйте, <strong>{$firstName}</strong>!
    </p>
    <p style="color:#475569;font-size:15px;line-height:1.65;margin:0 0 28px">
      Соискатель <strong>{$applicantName}</strong> откликнулся на вашу вакансию<br>
      <strong>«{$vacancyTitle}»</strong>.
    </p>
    <a href="{$vacancyUrl}" style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;
       padding:14px 32px;border-radius:9px;font-weight:600;font-size:15px">
      Просмотреть отклик →
    </a>
  </div>
  <div style="background:#f8fafc;padding:16px 40px;border-top:1px solid #e2e8f0;font-size:12px;color:#94a3b8">
    © Nexio HR Platform — Дипломная работа
  </div>
</div>
</body></html>
HTML;

    try {
        $mail = _buildMailer();
        $mail->addAddress($employerEmail, $employerName);
        $mail->isHTML(true);
        $mail->Subject = "Новый отклик на «{$vacancyTitle}» — Nexio";
        $mail->Body    = $html;
        $mail->AltBody = "Соискатель {$applicantName} откликнулся на вакансию «{$vacancyTitle}».\n\n{$vacancyUrl}";
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Mailer error: ' . $e->getMessage());
        return false;
    }
}

function sendStatusUpdateNotification(
    string $employeeEmail, string $employeeName,
    string $vacancyTitle, string $newStatus, string $vacancyUrl
): bool {
    $firstName = explode(' ', $employeeName)[0];
    $statusMap = [
        'accepted' => ['Поздравляем! Ваш отклик принят', '#059669', '🎉'],
        'rejected' => ['К сожалению, ваш отклик отклонён', '#dc2626', '😔'],
        'reviewed' => ['Ваш отклик рассматривается', '#2563eb', '👁'],
        'pending'  => ['Статус вашего отклика изменён', '#d97706', 'ℹ'],
    ];
    [$subjectText, $color, $icon] = $statusMap[$newStatus] ?? $statusMap['pending'];

    $html = <<<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif">
<div style="max-width:540px;margin:40px auto;background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 4px 32px rgba(0,0,0,.10)">
  <div style="background:linear-gradient(135deg,#1e40af 0%,#2563eb 100%);padding:30px 40px 28px">
    <div style="color:#fff;font-size:26px;font-weight:800;letter-spacing:-0.5px">Nexio</div>
    <div style="color:rgba(255,255,255,.65);font-size:13px;margin-top:3px">Обновление статуса отклика</div>
  </div>
  <div style="padding:36px 40px 40px">
    <div style="font-size:32px;margin-bottom:12px">{$icon}</div>
    <h1 style="font-size:21px;font-weight:700;color:#1e293b;margin:0 0 10px">{$subjectText}</h1>
    <p style="color:#475569;font-size:15px;line-height:1.65;margin:0 0 28px">
      Здравствуйте, <strong>{$firstName}</strong>!<br>
      Статус вашего отклика на вакансию <strong>«{$vacancyTitle}»</strong> был обновлён.
    </p>
    <a href="{$vacancyUrl}" style="display:inline-block;background:{$color};color:#fff;text-decoration:none;
       padding:14px 32px;border-radius:9px;font-weight:600;font-size:15px">
      Открыть вакансию →
    </a>
  </div>
  <div style="background:#f8fafc;padding:16px 40px;border-top:1px solid #e2e8f0;font-size:12px;color:#94a3b8">
    © Nexio HR Platform — Дипломная работа
  </div>
</div>
</body></html>
HTML;

    try {
        $mail = _buildMailer();
        $mail->addAddress($employeeEmail, $employeeName);
        $mail->isHTML(true);
        $mail->Subject = "{$subjectText} — Nexio";
        $mail->Body    = $html;
        $mail->AltBody = "{$subjectText}\nВакансия: «{$vacancyTitle}»\n\n{$vacancyUrl}";
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Mailer error: ' . $e->getMessage());
        return false;
    }
}
